﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Question2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Employee164 employee = new Employee164();
            // code to get data from text boxes and store in prod class object
            employee.Id = Convert.ToInt32( txtId.Text);
            employee.ModuleName = txtModule.Text;
            employee.BatchName = txtBatchName.Text;
            employee.Comments = txtComments.Text;
            dbContext.Employee164.Add(employee);
            dbContext.SaveChanges();
            MessageBox.Show("Inserted");
            PopulateUI();
        }

        //Method to Display Module Details for .net batch in Datagrid
        public void PopulateUI()
        {
            List<Employee164> empList = dbContext.Employee164.ToList();
            //Linq query to display module details .net batch
            var res = from p in empList
                      where p.BatchName.Equals(".net")|| p.BatchName.Equals(".NET")
                     select p;
            dgEmp.ItemsSource = res;
           
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }
    }
}
