﻿/*-----------------------------------------------------------------
///   Namespace:      <EmployeeDetails.EntityLayer>
///   Class:          <Employee>
///   Description:    <To define the required Properties of an Employee>
///   Author:         <Aishwarya K. Deshpande(164277)>                    
///   Creation Date:  <14 Dec 2018>
///-----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails.EntityLayer
{
    public class Employee
    {
        public int EmpId { get; set; }

        public string ModuleName { get; set; }

        public string BatchName { get; set; }

        public string Comments { get; set; }


    }
}
