﻿/*-----------------------------------------------------------------
///   Namespace:      <EmployeeDetails.PresentationLayer>
///   Class:          <MainWindow>
///   Description:    <It is Presentation Layer which handles the Events that occurs on User Interface>
///   Author:         <Aishwarya K. Deshpande(164277)>                    
///   Creation Date:  <14 Dec 2018>
///-----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeDetails.EntityLayer;
using EmployeeDetails.BusinessLayer;
using EmployeeDetails.ExceptionLayer;

namespace EmployeeDetails.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Employee employee = null;
        public MainWindow()
        {
            InitializeComponent();
        }

        private bool IsValid()
        {
           

            bool isValid = true;
            if (txtId.Text == string.Empty)
            {
                isValid = false;
                
            }
            if (txtModule.Text == string.Empty)
            {
                isValid = false;
                
            }
            if (txtBatchName.Text == string.Empty)
            {
                isValid = false;
                
            }

            if (txtComments.Text == string.Empty)
            {
                isValid = false;
                
            }

            if (isValid == false)
            {
                MessageBox.Show("All fields are Manadatory");
            }

            return isValid;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    employee = new Employee();
                    employee.EmpId = Convert.ToInt32(txtId.Text);
                    employee.ModuleName = txtModule.Text;
                    employee.BatchName = txtBatchName.Text;
                    employee.Comments = txtComments.Text;
                    status = EmployeeBL.AddEmpBL(employee);
                    
                }
                if (status == true)
                    MessageBox.Show("Inserted");

            }
            catch (UDExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
