﻿/*-----------------------------------------------------------------
///   Namespace:      <EmployeeDetails.ExceptionLayer>
///   Class:          <UDExceptions>
///   Description:    <It is user Define Exception class Inherited from Application Exception>
///   Author:         <Aishwarya K. Deshpande(164277)>                    
///   Creation Date:  <14 Dec 2018>
///-----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails.ExceptionLayer
{
    public class UDExceptions : ApplicationException
    {
        public UDExceptions() : base()
        {

        }

        public UDExceptions(string message) : base(message)
        {

        }

        public UDExceptions(string message, Exception objEx) : base(message, objEx)
        {

        }
    }
}
