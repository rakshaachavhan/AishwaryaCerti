﻿/*-----------------------------------------------------------------
///   Namespace:      <EmployeeDetails.BusinessLayer>
///   Class:          <EmployeeBL>
///   Description:    <To apply validations>
///   Author:         <Aishwarya K. Deshpande(164277)>                    
///   Creation Date:  <14 Dec 2018>
///-----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDetails.DataAccessLayer;
using EmployeeDetails.EntityLayer;
using EmployeeDetails.ExceptionLayer;

namespace EmployeeDetails.BusinessLayer
{
    public class EmployeeBL
    {
        private static bool ValidateEmp(Employee empBL)
        {
            StringBuilder sb = new StringBuilder();

            bool validEmp = true;

            if (empBL.EmpId < 0)
            {
                validEmp = false;
                sb.Append(Environment.NewLine + "Enter valid EmpID");
            }
            if (empBL.ModuleName == string.Empty || empBL.ModuleName.Length>50)
            {
                validEmp = false;
                sb.Append(Environment.NewLine + "Employee Name Required");
            }
            if (empBL.BatchName==string.Empty || empBL.BatchName.Length > 50)
            {
                validEmp = false;
                sb.Append(Environment.NewLine + "Enter valid Date");
            }
            if (empBL.Comments == string.Empty || empBL.Comments.Length>200)
            {
                validEmp = false;
                sb.Append(Environment.NewLine + "Enter valid Date");
            }


            if (validEmp == false)
            {
                throw new UDExceptions(sb.ToString());
            }

            return validEmp;
        }

        public static bool AddEmpBL(Employee empBL)
        {
            bool empAdded = false;

            try
            {
                if (ValidateEmp(empBL))
                {
                    EmployeeDAL empDAL = new EmployeeDAL();
                    empAdded = empDAL.InsertDAL(empBL);
                }
            }
            catch (UDExceptions ex)
            {
                throw ex;
            }
            

            return empAdded;
        }
    }
}
