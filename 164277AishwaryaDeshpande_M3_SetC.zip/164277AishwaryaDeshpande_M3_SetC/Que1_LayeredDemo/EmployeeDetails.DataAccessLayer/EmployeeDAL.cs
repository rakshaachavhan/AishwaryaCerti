﻿/*-----------------------------------------------------------------
///   Namespace:      <EmployeeDetails.DataAccessLayer>
///   Class:          <EmployeeDAL>
///   Description:    <To establish connection with database and to check data is inserted or not>
///   Author:         <Aishwarya K. Deshpande(164277)>                    
///   Creation Date:  <14 Dec 2018>
///-----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using EmployeeDetails.EntityLayer;
using EmployeeDetails.ExceptionLayer;

namespace EmployeeDetails.DataAccessLayer
{
    public class EmployeeDAL
    {
        SqlConnection conn = null;
        SqlCommand cmd = null;
        //SqlDataReader dr = null;

        public EmployeeDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public bool InsertDAL(Employee empDAL)
        {
            bool empAdded = false;
            try
            {
                cmd = new SqlCommand("aish164277.USP_AddEmpoyees", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", empDAL.EmpId);
                cmd.Parameters.AddWithValue("@modname", empDAL.ModuleName);
                cmd.Parameters.AddWithValue("@batchname", empDAL.BatchName);
                cmd.Parameters.AddWithValue("@comments", empDAL.Comments);
                conn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    empAdded = true;
            }
            catch (Exception ex)
            {
                throw new UDExceptions(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return empAdded;
        }


    }
}
