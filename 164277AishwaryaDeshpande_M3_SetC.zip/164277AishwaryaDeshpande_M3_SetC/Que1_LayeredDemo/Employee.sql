﻿create table aish164277.Employee164(
[Id] int Primary key not null ,[ModuleName] varchar(50) null, [BatchName] varchar(50) null,[Comments] varchar(200) null);

select * from aish164277.Employee164 --To test whether 

insert into aish164277.Employee164 values(101,'Module3','.NET','WPF is Great'); --To test whether table is properly created and data is inserting

--Stored procedure for inserting data into table
create Proc aish164277.USP_AddEmpoyees
@id int,
@modname varchar(50),
@batchname varchar(50),
@comments varchar(200)
as
	insert into aish164277.Employee164 values(@id,@modname,@batchname,@comments);