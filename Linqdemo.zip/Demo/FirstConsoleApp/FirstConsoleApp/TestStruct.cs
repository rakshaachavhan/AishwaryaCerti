﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstConsoleApp
{
    class TestStruct
    {
        static void Main(string[] args)
        {
            customer objCustomer = new customer();
            objCustomer.getCustomerDetails(101, "Raj", "Pune", "1234567891");
            Console.WriteLine("ID:" + objCustomer.id + "\n" + "Name:" + objCustomer.name + "\n" + "Address:" + objCustomer.address + "\n" + "Contact" + objCustomer.contacNo);
            Console.ReadLine();
        }
    }
}
