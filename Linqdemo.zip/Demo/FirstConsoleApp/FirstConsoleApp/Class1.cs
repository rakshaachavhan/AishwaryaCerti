﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstConsoleApp
{
    class Class1
    {
        static void Main(string[] args)
        {
            SingleDArray();
            MultiDArray();
            Console.ReadLine();
        }

        static void SingleDArray()
        {
            string[] strCountries = new string[5];
            strCountries[0] = "America";
            strCountries[1] = "Autralia";
            strCountries[2] = "India";
            strCountries[3] = "Russia";
            strCountries[4] = "China";

            for (int i = 0; i < strCountries.Length; i++)
            {
                Console.WriteLine(strCountries[i]);
            }

            foreach (string strCountry in strCountries)
            {
                Console.WriteLine(strCountry);
            }
        }
        static void MultiDArray()
        {
            int[,] numbers = new int[2, 2];
            numbers[0, 0] = 100;
            numbers[0, 1] = 200;
            numbers[1, 0] = 300;
            numbers[1, 1] = 400;

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.Write(numbers[i, j] + "    ");
                }
                Console.Write("\n");
            }
        }
    }
}
