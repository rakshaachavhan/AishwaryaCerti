﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstConsoleApp
{
    struct customer
    {
        internal int id;
        internal string name;
        internal string address;
        internal string contacNo;

        internal void getCustomerDetails(int id, string name, string address, string contacNo)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.contacNo = contacNo;
        }
    }
}