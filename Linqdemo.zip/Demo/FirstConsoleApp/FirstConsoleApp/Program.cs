﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculatorLib;

namespace FirstConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("******************Calculator Appliction********************");
            char flag;
            do
            {

                Console.WriteLine("Press 1.for Addition.\n2.for Subtarction.\n3.for Multiplication.\n4.for Division");
                int operation;
                operation =Convert.ToInt32(Console.ReadLine());
                int firstNo, secondNo,result;
                Console.WriteLine("Enter first no:");
                 firstNo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter second no:");
                secondNo = Convert.ToInt32(Console.ReadLine());
                claculator calcobj = new claculator();

                switch (operation)
                {
                    case 1:
                        //logic for add
                        result = calcobj.addition(firstNo, secondNo);
                        Console.WriteLine("Addititon of\t" + firstNo + "\tand\t" + secondNo + "\tis\t" + result);
                        break;
                    case 2:
                        //logic for sub
                        result = calcobj.subtraction(firstNo, secondNo);
                        Console.WriteLine("Subtraction of\t" + firstNo + "\tand\t" + secondNo + "\tis\t" + result);
                        break;

                    case 3:
                        //logic for mul
                        result = calcobj.multiplication(firstNo, secondNo);
                        Console.WriteLine("Multiplication of\t" + firstNo + "\tand\t" + secondNo + "\tis\t" + result);
                        break;
                    case 4:
                        //logic for div
                        result = calcobj.division(firstNo, secondNo);
                        Console.WriteLine("division of\t" + firstNo + "\tand\t" + secondNo + "\tis\t" + result);
                        break;

                    default:
                        Console.WriteLine("Enter valid choice");
                        break;
                }
                Console.WriteLine("Do you want to continue Y/N");
                flag = Convert.ToChar(Console.ReadLine());
            } while (flag=='y' || flag=='Y');
            Console.ReadLine();    
        }

       /* static int addition(int num1,int num2)
        {
            int result;
            result = num1 + num2;
            return result;
        }

        static int subtraction(int num1, int num2)
        {
            int result;
            result = num1 - num2;
            return result;
        }

        static int multiplication(int num1, int num2)
        {
            int result;
            result = num1 * num2;
            return result;
        }

        static int division(int num1, int num2)
        {
            int result;
            result = num1 / num2;
            return result;
        }*/
    }
}

