﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorLib
{
    public class claculator
    {
        public int addition(int num1, int num2)
        {
            int result;
            result = num1 + num2;
            return result;
        }

        public int subtraction(int num1, int num2)
        {
            int result;
            result = num1 - num2;
            return result;
        }

        public int multiplication(int num1, int num2)
        {
            int result;
            result = num1 * num2;
            return result;
        }

        public int division(int num1, int num2)
        {
            int result;
            result = num1 / num2;
            return result;
        }
    }
}
