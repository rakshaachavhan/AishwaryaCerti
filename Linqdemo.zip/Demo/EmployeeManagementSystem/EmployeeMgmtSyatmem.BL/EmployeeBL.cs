﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeMgmtSyatmem.Entities;
using EmployeeMgmtSyatmem.Exceptions;
using EmployeeMgmtSyatmem.DAL;


namespace EmployeeMgmtSyatmem.BL
{
    public class EmployeeBL
    {
        private static bool validateEmployee(Employee objEmployee)
        {
            StringBuilder objSB = new StringBuilder();
            bool vaildEmployee = true;
            if(objEmployee.Id<=0)
            {
                vaildEmployee = false;
                objSB.Append(Environment.NewLine + "Invalid Employee ID");
            }
            if(objEmployee.Name==string.Empty)
            {
                vaildEmployee = false;
                objSB.Append(Environment.NewLine + "Employee Name Required");
            }
            if(objEmployee.DesignationId.ToString().Length<4)
            {
                vaildEmployee = false;
                objSB.Append(Environment.NewLine + "Required 4 Digit Designation Id");
            }

            if (objEmployee.DepartmentId.ToString().Length < 4)
            {
                vaildEmployee = false;
                objSB.Append(Environment.NewLine + "Required 4 Digit Department Id");
            }
            if (vaildEmployee == false)
                throw new EmployeeMgmtSystemException(objSB.ToString());
            return vaildEmployee;

        }

        public static bool AddEmployeeBL(Employee objEmployee)
        {
            bool employeeAdded = false;
            try
            {
                if(validateEmployee(objEmployee))
                {
                    EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                    employeeAdded= objEmployeeDAL.AddEmployeeDAL(objEmployee);

                }
            }
            catch(EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch(Exception objEx)
            {
                throw objEx;
            }
            return employeeAdded;
        }

        public static Employee SearchEmployeeBL(int id)
        {
            Employee objEmployee;
            try
            {
                EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                objEmployee = objEmployeeDAL.SearchEmployeeDAL(id);
            }
            catch(EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch(Exception objEx)
            {
                throw objEx;
            }
            return objEmployee;
        }

        public static bool UpdateEmployeeBL(Employee objEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                if (validateEmployee(objEmployee))
                {
                    EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                    employeeUpdated = objEmployeeDAL.UpdateEmployeeDAL(objEmployee);

                }
            }
            catch (EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return employeeUpdated;
        }

        public static bool DeleteEmployeeBL(int id)
        {
            bool employeeDeleted = false;
            try
            {
                if(id>0)
                {
                    EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                    employeeDeleted = objEmployeeDAL.DeleteEmployeeDAL(id);
                }
                else
                {
                    throw new EmployeeMgmtSystemException("Invalid id");
                }

            }
            catch(EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch(Exception objEx)
            {
                throw objEx;
            }
            return employeeDeleted;
        }

        public static List<Employee> GetAllEmployeeBL()
        {
            List<Employee> objEmployeeList;
            try
            {
                EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                objEmployeeList= objEmployeeDAL.GetAllEmployeeDAL();
            }
            catch(EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                throw objEmpMgmtSysExp;
            }
            catch(Exception objEx)
            {
                throw objEx;
            }
            return objEmployeeList;
        }
    }
}
