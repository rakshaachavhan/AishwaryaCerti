﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeMgmtSyatmem.Entities;
using EmployeeMgmtSyatmem.Exceptions;
using EmployeeMgmtSyatmem.BL;

namespace EmployeeMgmtSyatmem.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            char choice;
            do
            {
                printMenu();
                Console.WriteLine("Enter your choice");
                int taskFlag;
                taskFlag = Convert.ToInt32(Console.ReadLine());
                switch(taskFlag)
                {
                    case 1:
                        //Add Employee
                        AddEmployee();
                        break;
                    case 2:
                        //Search Employee
                        SearchEmployeeById();
                        break;
                    case 3:
                        //Update Employee
                        UpdateEmployee();
                        break;
                    case 4:
                        //delete Employee
                        DeleteEmployee();
                        break;
                    case 5:
                        //List Employee
                        ListEmployee();
                        break;
                    default:
                        Console.WriteLine("Enter correct choice");
                        break;


                }
                Console.WriteLine("Do you want to continue? Press'y' to continue to continue or any other button to exit");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice=='y'||choice=='Y');

            Console.ReadLine();
        }

        static void printMenu()
        {
            Console.WriteLine("----------------Employee Management System-------------------");
            Console.WriteLine("Press 1 to Add Employee");
            Console.WriteLine("Press 2 to Search Employee");
            Console.WriteLine("Press 3 to Update Employee");
            Console.WriteLine("Press 4 to Delete Employee");
            Console.WriteLine("Press 5 to List All Employee");
            Console.WriteLine("-------------------------------------------------------------------------");
        }

        static void AddEmployee()
        {
            
            try
            {
                Employee objEmployee = new Employee();
                Console.WriteLine("Enter Employee Details:");
                Console.WriteLine("Enter Id:");
                objEmployee.Id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Name:");
                objEmployee.Name = Console.ReadLine();
                Console.WriteLine("Enter Designation Id:");
                objEmployee.DesignationId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Department Id:");
                objEmployee.DepartmentId = Convert.ToInt32(Console.ReadLine());
                bool employeeAdded;
                employeeAdded = EmployeeBL.AddEmployeeBL(objEmployee);
                if(employeeAdded)
                {
                    Console.WriteLine("Data Added Successfully");
                }
                else
                {
                    Console.WriteLine("Employee Couldn't be added");
                }
            }
            catch(EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                Console.WriteLine(objEmpMgmtSysExp.Message);
            }
            
        }

        static void SearchEmployeeById()
        {
           try
            {
                int id;
                Console.WriteLine("Enter tihe Employee ID to Search");
                id = Convert.ToInt32(Console.ReadLine());
                Employee objEmployee;
                objEmployee = EmployeeBL.SearchEmployeeBL(id);
                if(objEmployee!=null)
                {
                    Console.WriteLine("--------------Employee Details-------------");
                    Console.WriteLine("Id:" + objEmployee.Id);
                    Console.WriteLine("Name:" + objEmployee.Name);
                    Console.WriteLine("Designation ID:" + objEmployee.DesignationId);
                    Console.WriteLine("Department Id:" + objEmployee.DepartmentId);

                }
                else
                {
                    Console.WriteLine("Employee data not found");
                }
            }
            catch(EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                Console.WriteLine(objEmpMgmtSysExp.Message);
            }

        }

        static void UpdateEmployee()
        {
            try
            {
                int Id;
                Employee objEmployee;
                Console.WriteLine("Enter Id:");
                Id = Convert.ToInt32(Console.ReadLine());
                objEmployee = EmployeeBL.SearchEmployeeBL(Id);
                if(objEmployee!=null)
                {
                    Console.WriteLine("Enter Employee Details:");
                    Console.WriteLine("Enter Name:");
                    objEmployee.Name = Console.ReadLine();
                    Console.WriteLine("Enter Designation Id:");
                    objEmployee.DesignationId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Department Id:");
                    objEmployee.DepartmentId = Convert.ToInt32(Console.ReadLine());
                    bool employeeUpdated;
                    employeeUpdated = EmployeeBL.UpdateEmployeeBL(objEmployee);
                    if (employeeUpdated)
                    {
                        Console.WriteLine("Data Updated Successfully");
                    }
                    else
                    {
                        Console.WriteLine("Employee Couldn't be Updated");
                    }
                }
                else
                {
                    Console.WriteLine("Employee with this id is not available");
                }

               
            }
            catch (EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                Console.WriteLine(objEmpMgmtSysExp.Message);
            }
        }

        static void DeleteEmployee()
        {
            
            try
            {
                bool employeeDeleted;
                int id;
                Console.WriteLine("Enter id");
                id = Convert.ToInt32(Console.ReadLine());
                Employee objEmployee = EmployeeBL.SearchEmployeeBL(id);
                if(objEmployee!=null)
                {
                    employeeDeleted= EmployeeBL.DeleteEmployeeBL(id);
                    if(employeeDeleted)
                    {
                        Console.WriteLine("Employee Data Deleted Successfully");
                    }
                    else
                    {
                        Console.WriteLine("Employee data Could not be deleted");
                    }

                }
                else
                {
                    Console.WriteLine("Employee not found");
                }
            }
            catch(EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                Console.WriteLine(objEmpMgmtSysExp.Message);
            }
        }

        static void ListEmployee()
        {
            try
            {
                List<Employee> objEmployeeList;
                objEmployeeList= EmployeeBL.GetAllEmployeeBL();
                if(objEmployeeList!=null)
                {
                    Console.WriteLine("*******************List of Employees******************");
                    Console.WriteLine("ID\tName\tDesignationID\tDepatementID\n");
                    foreach (Employee objEmployee in objEmployeeList)
                    {
                       
                        Console.WriteLine(objEmployee.Id + "\t" + objEmployee.Name + "\t" + objEmployee.DesignationId +"\t"+ objEmployee.DepartmentId);
                    }
                    Console.WriteLine("********************************************************************");
                }
                else
                {
                    Console.WriteLine("No Employee Records Are present");
                }
            }
            catch(EmployeeMgmtSystemException objEmpMgmtSysExp)
            {
                Console.WriteLine(objEmpMgmtSysExp.Message);
            }
        }


    }
}
