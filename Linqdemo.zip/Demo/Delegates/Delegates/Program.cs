﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    class Program
    {
        delegate int myDelegate(int a, int b);
        static void Main(string[] args)
        {
            myDelegate objmyDel = new myDelegate(Add);
            int resultAdd = objmyDel.Invoke(10, 10);
            Console.WriteLine("Addition" +resultAdd);
            Console.ReadLine();

            myDelegate objmyDel1 = new myDelegate(Sub);
            int resultSub = objmyDel.Invoke(20, 10);
            Console.WriteLine("Sub" + resultSub);
            Console.ReadLine();

            //Multicast Delegate
            myDelegate objMutlidel;
            objMutlidel = objmyDel;
            objMutlidel += objmyDel1;
            int res = objMutlidel.Invoke(30, 20);


        }

        static int Add(int a,int b)
        {
            int result = a + b;
            return result;
        }

        static int Sub(int a,int b)
        {
            int result = a - b;
            return result;
        }

        
    }
}
