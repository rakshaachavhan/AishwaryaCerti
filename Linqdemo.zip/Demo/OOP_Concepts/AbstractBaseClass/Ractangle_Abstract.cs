﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractBaseClass
{
    public class Ractangle_Abstract : Shape
    {
        private float _height;
        private float _width;

        public float Height
        {
            get
            {
                return _height;
            }
            set
            {
                _height = value;
            }
        }

        public float Width
        {
            get
            {
                return _width;
            }
            set
            {
                _width = value;
            }
        }

        public Ractangle_Abstract()
        {

        }

        public Ractangle_Abstract(float height, float width)
        {
            _height = height;
            _width = width;

        }

        public override void CalculateArea()
        {
            //base.CalculateArea();
            Area = _height * _width;
        }

        public override void CalculatePerimeter()
        {
            // base.CalculatePerimeter();
            Perimeter = 2 * (_height + _width);
        }

        public new void display()
        {

        }

    }
}
