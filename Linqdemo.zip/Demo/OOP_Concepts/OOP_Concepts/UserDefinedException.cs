﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Concepts
{
    class UserDefinedException : ApplicationException
    {
        public UserDefinedException(string str):base(str)
        {
            Console.WriteLine("User Define Exception");
        }
    }

    class MyClient
    {
        public static void Main()
        {
            try
            {
                throw new UserDefinedException("Some Error Occur");
            }
            catch(UserDefinedException e)
            {
                Console.WriteLine("Exception caught here" + e.ToString());
            }

            Console.ReadLine();
        }
    }
}
