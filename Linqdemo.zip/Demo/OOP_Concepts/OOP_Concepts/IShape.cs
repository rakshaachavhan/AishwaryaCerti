﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseInterface
{
    public interface IShape
    {
        float Area { get; set; }
        float Perimeter { get; set; }
        void CalculateArea();
        void CalculatePerimeter();

    }
}
