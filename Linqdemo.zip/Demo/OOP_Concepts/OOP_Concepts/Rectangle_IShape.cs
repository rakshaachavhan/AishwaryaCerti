﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseInterface
{
    class Rectangle : IShape
    {
        float _height, _width;
        public float Area { get; set; }

        public float Perimeter { get; set; }

        public  float Height { get; set; }
        public float Width { get; set; }

        public Rectangle(float height,float width)
        {
            Height = height;
            Width = width;
        }

        public void CalculateArea()
        {
            this.Area = Height * Width;
        }

        public void CalculatePerimeter()
        {
            this.Perimeter = 2 * (Height * Width);
        }
        
    }
}
