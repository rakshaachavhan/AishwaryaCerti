﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace OOP_Concepts
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {


                ///----------Instance_Base_Class-----(1)
                Instance_Base_Class.Rectangle objRectangle = new Instance_Base_Class.Rectangle(100.0f, 50.0f);
                objRectangle.CalculateArea();
                Console.WriteLine("Area of rectangle using instance base class" + objRectangle.Area);
                // Console.ReadLine();

                ///----------Abstract_Base_Class-----(1)
                Abstract_Base_Class.Rectangle objRectangle2 = new Abstract_Base_Class.Rectangle(100.0f, 50.0f);
                objRectangle2.CalculateArea();
                Console.WriteLine("Area of rectangle using Abstract base class" + objRectangle2.Area);
                //Console.ReadLine();

                BaseInterface.Rectangle objRectangle3 = new BaseInterface.Rectangle(100.0f, 50.0f);
                objRectangle3.CalculateArea();
                Console.WriteLine("Area using Interface:" + objRectangle3.Area);
                objRectangle3.CalculatePerimeter();
                Console.WriteLine("Primeter using Interface:" + objRectangle3.Perimeter);
                Console.ReadLine();
            }
            catch(Exception ex)
            {
                throw ex;
            }


        }
    }
}
