﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace CollectionAndGenerics
{
    class Program
    {
        static void Main(string[] args)
        {
            //DemoArrayList();
            //DemoStack();
            //DemoQueue();
            //DemoHashtable();
            //DemoList();
            //DemoGenericStack();
            //DemoGenericQueue();
            DemoGenericDictonary();
            Console.ReadLine();
        }
        static void DemoArrayList()
        {

            ArrayList objAl = new ArrayList();
            objAl.Add("America");
            objAl.Add("India");
            objAl.Add("Russia");
            objAl.Add("China");

            Console.WriteLine("Capacity:" + objAl.Capacity);
            Console.WriteLine("Count:" + objAl.Count);
            Console.WriteLine("Contains a country named as India" + objAl.Contains("India"));

            //objAl.Add("Japan");

            Object[] objCountries = new Object[objAl.Count];
            objAl.CopyTo(objCountries);
            Console.WriteLine("\n\nItems for object Array");
            foreach(var item in objCountries)
            {
                Console.WriteLine(item);
            }

            objAl.Insert(2, "West Indies");
            objAl.Remove("West Indies");

            Console.WriteLine("\n\nList of Countries using for loop");
            for(int i=0;i<objAl.Count;i++)
            {
                Console.WriteLine(objAl[i]);
            }

            Console.WriteLine("\n\nList of countries using for each loop");
            foreach(var item in objAl)
            {
                Console.WriteLine(item);
            }

           
        }
        static void DemoStack()
        {
            Stack objStack = new Stack();
            objStack.Push("Jan");
            objStack.Push("Feb");
            objStack.Push("March");
            objStack.Push("April");
            objStack.Push("May");
            objStack.Push("June");
            objStack.Push("July");
            objStack.Push("August");
            objStack.Push("September");
            Console.WriteLine("List of Months");
            foreach(var item in objStack)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Item Poped:" + objStack.Pop());
            Console.WriteLine("Item Poped:" + objStack.Pop());
            Console.WriteLine("Item Peek:" + objStack.Peek());
            Console.WriteLine("List of elements months after calling Peek function");
            foreach(var item in objStack)
            {
                Console.WriteLine(item);
            }


        }
        static void DemoQueue()
        {
            Queue objQueue = new Queue();
            objQueue.Enqueue("Jan");
            objQueue.Enqueue("Feb");
            objQueue.Enqueue("March");

            Console.WriteLine("List of Months");
            foreach(var item in objQueue)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\n\nDequeue:" + objQueue.Dequeue());

            Console.WriteLine("\n\nList of Object after calling Dequeue:\n");
            foreach(var item in objQueue)
            {
                Console.WriteLine(item);
            }
        }
        static void DemoHashtable()
        {
            Hashtable objHashtable = new Hashtable();
            objHashtable.Add(0, "Ranbir");
            objHashtable.Add(1, "Arjun");
            objHashtable.Add(2, "Aishwarya");
            IDictionaryEnumerator objIDE = objHashtable.GetEnumerator();
            while(objIDE.MoveNext())
            {
                Console.WriteLine(objIDE.Value);
            }

            foreach(DictionaryEntry obj in objHashtable)
            {
                Console.WriteLine("key:" + obj.Key);
            }
           
        }
        static void DemoList()
        {
            List<string> objAl = new List<string>();
            objAl.Add("America");
            objAl.Add("India");
            objAl.Add("Russia");
            objAl.Add("China");

           
            //objAl.Add("Japan");

          
            Console.WriteLine("\n\nList of Countries using for loop");
             
            Console.WriteLine("\n\nList of countries using for each loop");
            foreach (var item in objAl)
            {
                Console.WriteLine(item);
            }
        }
        static void DemoGenericStack()
        {
            Stack<string> objStack = new Stack<string>();
            objStack.Push("Jan");
            objStack.Push("Feb");
            objStack.Push("March");
            objStack.Push("April");
            objStack.Push("May");
            objStack.Push("June");
            objStack.Push("July");
            objStack.Push("August");
            objStack.Push("September");
            Console.WriteLine("List of Months");
            foreach (var item in objStack)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Item Poped:" + objStack.Pop());
            Console.WriteLine("Item Poped:" + objStack.Pop());
            Console.WriteLine("Item Peek:" + objStack.Peek());
            Console.WriteLine("List of elements months after calling Peek function");
            foreach (var item in objStack)
            {
                Console.WriteLine(item);
            }

        }
        static void DemoGenericQueue()
        {
            Queue<string> objQueue = new Queue<string>();
            objQueue.Enqueue("Jan");
            objQueue.Enqueue("Feb");
            objQueue.Enqueue("March");

            Console.WriteLine("List of Months");
            foreach (var item in objQueue)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\n\nDequeue:" + objQueue.Dequeue());

            Console.WriteLine("\n\nList of Object after calling Dequeue:\n");
            foreach (var item in objQueue)
            {
                Console.WriteLine(item);
            }
        }
        static void DemoGenericDictonary()
        {
            Dictionary<int,string> objDic = new Dictionary<int, string>();
            objDic.Add(0, "Ranbir");
            objDic.Add(1, "Arjun");
            objDic.Add(2, "Aishwarya");
            
            foreach (KeyValuePair<int,string> objKVP in objDic)
            {
                Console.WriteLine("key:" + objKVP.Key+"Value"+objKVP.Value);
            }

        }
    }
}
