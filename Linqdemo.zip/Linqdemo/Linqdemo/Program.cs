﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linqdemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] number = { 01,20,22,56,77,88,66,48};

            //Declarative Query Syntax
            /* var res = from n in number
                       where (n % 2 == 0)
                       select n;*/
            //using Extension Method
            /*var res = number.Where(n => n % 2 == 0);

            foreach( var i in res)
            {
                Console.WriteLine(i);
            }
            number[1] = 9;
            foreach (var i in res)
            {
                Console.WriteLine("\n\n"+ i);
            }*/


            /*var res1 = from s in studs
                       select new { s.RollNo, s.Name };
            foreach( var r in res1)
            {
                Console.WriteLine(r.RollNo + "  " + r.Name);
            }*/

            /*var res1 = from s in studs
                       from m in s.Marks
                       select m;*/
            //var res1 = studs.SelectMany(s => s.Marks);
            /*foreach(var r in res1)
            {
                Console.Write(r+" ");
            }*/

            List<Student> studs = Student.GetAll();
            //var res1 = from s in studs
            //          orderby s.Name
            //       select s;
            //var res2 = studs.OrderBy(s => s.Name);

            /*var res3 = from s in studs
                       orderby s.Name, s.age
                       select s;

            //var res4 = studs.OrderBy(s => s.Name).ThenBy(s => s.Marks.Average());
            foreach(var item in res3)
            {
                Console.WriteLine(item.RollNo+" "+item.Name+" "+item.Marks.Average());
            }*/

            //var res7 = studs.Where(s => s.Name.StartsWith("P")).Select(s=> new { s.RollNo, s.Name });
            var res8 = from s in studs
                       where s.Name.StartsWith("P")
                       select s;
            foreach(var item in res8)
            {
                Console.WriteLine(item.RollNo+","+item.Name);
            }
            
            var mrk = from n in studs
                      select new { n.Name, n.Marks };
            foreach(var item in mrk)
            {
                Console.WriteLine(item.Name + item.Marks.Average());
            }

           /* var res5 = from s in studs
                       group s by s.age;
            var res6 = studs.GroupBy(s => s.age);
            foreach(var grp in res6)
            {
                Console.WriteLine("Age "+grp.Key+"Group");
                foreach(var s in grp)
                {
                    Console.WriteLine(s.RollNo + "," + s.age+","+s.Name);
                }
            }*/
            
            //int[] arr1 = {1,4,6,9,1 };
           // int[] arr2 = {2,1,7,8,7 };
           /* //Set OPerators
            var res1 = arr1.Union(arr2);
            Console.WriteLine("Union");
            foreach(var item in res1)
            {
                Console.WriteLine( item);
            }
            var res2 = arr1.Intersect(arr2);
            Console.WriteLine("Intersect");
            foreach (var item in res2)
            {
                Console.WriteLine( item);
            }
            var res3 = arr1.Except(arr2);
            Console.WriteLine("Except");
            foreach (var item in res3)
            {
                Console.WriteLine( item);
            }

            //Conversion Operators
            List<int> res4 = arr1.ToList();
            int[] arr3 = res4.ToArray();

            IEnumerable<int> nos = arr3;
            //int[] nos_1 = nos;
            IQueryable<int> nos_2 = arr3.AsQueryable();*/

            /*object[] arr4 = { 1,'C',"Hello",1.5,5,"Hi"};
            var elms = arr4.OfType<int>();
            foreach(var item in elms)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Max:" + arr1.Max() + "Min:"+arr1.Min());*/

            //int[] arr5 = { 1, 2, 3, 4, 5 };
           //int[] arr6 = { }; //int [] arr6 = new int[0];
            //Console.WriteLine("First:" + arr5.First());
            //Console.WriteLine("First:" + arr6.FirstOrDefault());
            //Console.WriteLine("Single:" + arr5.Single());

            Console.ReadLine();
        }
    }
}
