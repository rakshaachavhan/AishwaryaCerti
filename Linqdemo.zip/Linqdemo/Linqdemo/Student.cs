﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linqdemo
{
    public class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }
        public int[] Marks { get; set; }
        public int age { get; set; }

        public static List<Student> GetAll()
        {
            List<Student> studs = new List<Student>
            {
                new Student{RollNo=101, Name="Aishwarya", Marks=new int[] {70,70,60,70},age=19},
                new Student{RollNo=102, Name="Aishwarya", Marks=new int[] {70,70,60,70},age=18},
                new Student{RollNo=103, Name="Vidhya" , Marks=new int[] {70,70,60,70},age=17},
                new Student{RollNo=103, Name="Anagha" , Marks=new int[] {60,70,80,90},age=17},
                new Student{RollNo=103, Name="Ambika" , Marks=new int[] {50,70,40,80},age=17},
                new Student{RollNo=103, Name="Pratiksha" , Marks=new int[] {50,70,40,80},age=17}
            };
            return studs;
        }
    }

      
}
