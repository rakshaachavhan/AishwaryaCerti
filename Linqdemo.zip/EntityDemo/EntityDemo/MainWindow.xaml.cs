﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EntityDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        Training_24Oct18_PuneEntities dbContext = null;
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            Product prod = new Product();
            //Write code to get data from text boxes and store in prod class object
            prod.ProductName = comboname.Text;
            prod.ExpDate = Convert.ToDateTime(datepicker.Text);
            prod.Price = Convert.ToDecimal( txtPrice.Text);
           
            dbContext.Products.Add(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Inserted");
            PopulateUI();
        }
        
        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Product prod = dbContext.Products.Single(p => p.Id==id);
            dbContext.SaveChanges();
            MessageBox.Show("Updated");
            PopulateUI();

        }

        private void Btndelete_Click(object sender, RoutedEventArgs e)
        {
            // List<Product> prodList = dbContext.Products.ToList();
            //Product prod =(Product) comboname.SelectedItem;
            
            int id = ((Product)comboname.SelectedItem).Id;
            Product prod = dbContext.Products.Single(p => p.Id == id);
            dbContext.Products.Remove(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Deleted");
            PopulateUI();
        }

        private void Comboname_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        public void PopulateUI()
        {
            List<Product>prodList= dbContext.Products.ToList();
            var res = from p in prodList
                      where p.Price > 2000
                      select p;
            dgProducts.ItemsSource = res;
            comboname.ItemsSource = prodList;
            comboname.DisplayMemberPath = "ProductName";
        }
        int id;
        private void Btn_Edit_Click(object sender, RoutedEventArgs e)
        {
            id = ((Product)comboname.SelectedItem).Id;
        }
    }
}
