﻿/*/*********************************************************************
 * Project              : Lab7_2
 * File                 : Product.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Product Class Containg PRoperties of Products.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7_2
{
    public class Product
    {
        public int ProductNo { get; set; }
        public string ProductName { get; set; }
        public int Rate { get; set; }
        public int Stock { get; set; }
    }
}
