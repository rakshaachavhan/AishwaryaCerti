﻿/*********************************************************************
 * Project              : Lab7_2
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Progrm to introduce use of Arraylist, In Arraylst we are storing Prodect Details and perfroming Operations like Add and Delete. 
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Lab7_2
{
    class Program
    {
        static void Main(string[] args)
        {
            char select;
            int numberOfElements;
            ArrayList arrList = new ArrayList();
            
            
            do
            {
                Console.WriteLine(" Select Option 1)ADD \n 2)Delete \n 3) Search \n 4)Save \n ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:

                        Console.WriteLine("How many numbers ?:");
                        numberOfElements = Convert.ToInt32(Console.ReadLine());
                        for (int index = 0; index < numberOfElements; index++)
                        {
                            Product objProduct = new Product();
                            Console.WriteLine(" Product details");
                            Console.WriteLine("Enter Product No:");
                            objProduct.ProductNo = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Product Name:");
                            objProduct.ProductName = Console.ReadLine();
                            Console.WriteLine("Enter Product Rate:");
                            objProduct.Rate = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter Product Stock:");
                            objProduct.Stock = int.Parse(Console.ReadLine());

                            arrList.Add(objProduct);

                        }
                        break;
                    case 2:

                        Console.WriteLine(" Enter Product ID to delete");
                        int dltNumber = int.Parse(Console.ReadLine());

                        if (arrList.Contains(dltNumber))
                        {
                            for (int i = 0; i < arrList.Count; i++)
                            {
                                Product objProduct = arrList[i] as Product;
                                if (objProduct.ProductNo == dltNumber)
                                {
                                    arrList.RemoveAt(i);
                                }
                                else
                                {
                                    Console.WriteLine(" Name not found");

                                }
                            }
                        }


                       
                        
                        break;
                    case 3:
                        Console.WriteLine(" Product numbeeeer you want to edit details of");
                        int searchNumber = int.Parse(Console.ReadLine());
                        
                            for (int i = 0; i < arrList.Count; i++)
                        {
                            Product objProduct = arrList[i] as Product;

                            if (objProduct.ProductNo == searchNumber)
                            {
                                Console.WriteLine(objProduct.ProductNo + objProduct.ProductName);
                            }
                            else
                            {
                                Console.WriteLine(" Name not found");
                            }
                        }
                               




                
                break;
                    case 4:
                        arrList.Sort();
                        break;



            }
                Console.WriteLine(" Want to continue?");
                select = char.Parse( Console.ReadLine());
            } while (select == 'Y' || select == 'y');
        }   }  }
