﻿/*********************************************************************
 * Project              : Lab7_1
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program To maintain Directory of Customer That contains Contact ID,Cell No,Name
 *                        And to perfrom operations like Add,Display and Update.
 * Version              : 1.0
 * Last Modified Date   : 04/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contact;

namespace Lab7_1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Contacts> Contacts = new List<Contacts>(2);
            Console.WriteLine(" Select Option 1)ADD \n 2)Diplay ALL \n 3) Display ALL \n 4)EDIT \n ");
            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:

                    Console.WriteLine("Enter number of contacts");
                    int n = int.Parse(Console.ReadLine());

                    for (int index = 0; index < n; index++)
                    {
                        Contacts objContact = new Contacts();
                        Console.WriteLine(" contact details");
                        objContact.ContactNo = int.Parse(Console.ReadLine());
                        objContact.ContactName = Console.ReadLine();
                        objContact.CellNo = Console.ReadLine();
                        Contacts.Add(objContact);

                    }
                    break;
                case 2:

                    foreach (Contacts c in Contacts)
                    {
                        Console.WriteLine("ContactNo={0}, ContactName={1}, CellNo={2}", c.ContactNo, c.ContactName, c.CellNo);
                    }
                    break;
                case 3:

                    Console.WriteLine(" contact name you want to display");
                    string searchName = Console.ReadLine();

                    for (int index = 0; index < Contacts.Count; index++)
                    {
                        if (Contacts[index].ContactName == searchName)
                        {
                            Console.WriteLine("ContactNo={0}, ContactName={1}, CellNo={2}", Contacts[index].ContactNo, Contacts[index].ContactName, Contacts[index].CellNo);
                        }
                        else
                        {
                            Console.WriteLine(" Name not found");

                        }
                    }
                    break;
                case 4:
                    Console.WriteLine(" contact name you want to edit details of");
                    string editName = Console.ReadLine();
                    for (int index = 0; index < Contacts.Count; index++)
                    {
                        if (Contacts[index].ContactName == editName)
                        {
                            Console.WriteLine(" contact details");
                            Contacts[index].ContactNo = int.Parse(Console.ReadLine());
                            Contacts[index].ContactName = Console.ReadLine();
                            Contacts[index].CellNo = Console.ReadLine();
                        }
                        else
                        {
                            Console.WriteLine(" Name not found");
                        }




                    }
                    break;
                    
            }
            Console.ReadLine();
        }
    }
}
