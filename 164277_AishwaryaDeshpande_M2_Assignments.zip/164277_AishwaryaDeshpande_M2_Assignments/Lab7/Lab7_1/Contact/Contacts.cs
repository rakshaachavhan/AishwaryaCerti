﻿/*********************************************************************
 * Project              : Contact
 * File                 : Contacts.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Contact DLL conatining Serializable Class Contacts
 * Version              : 1.0
 * Last Modified Date   : 04/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact
{
    [Serializable]
    public class Contacts
    {
        public int ContactNo { get; set; }
        public string ContactName { get; set; }
        public string CellNo { get; set; }
    }
}
