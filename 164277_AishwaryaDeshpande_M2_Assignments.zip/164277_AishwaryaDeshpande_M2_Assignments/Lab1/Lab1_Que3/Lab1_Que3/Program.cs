﻿/*********************************************************************
 * Project              : Lab1_Qu3
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to calculate and print no on command line .
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_Que3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
           // Console.WriteLine("Enter Number");
            num = Convert.ToInt32(args[0]);

            switch(num)
            {
                case 1: Console.Write("Entered No is:" + num);
                    break;
                case 2:
                    Console.Write("Entered No is:" + num);
                    break;
                case 3:
                    Console.Write("Entered No is:" + num);
                    break;

                case 4:
                    Console.Write("Entered No is:" + num);
                    break;

                case 5:
                    Console.Write("Entered No is:" + num);
                    break;

                default:
                    Console.WriteLine("Enter Valid No");
                    break;



            }
            Console.ReadLine();

        }
    }
}
