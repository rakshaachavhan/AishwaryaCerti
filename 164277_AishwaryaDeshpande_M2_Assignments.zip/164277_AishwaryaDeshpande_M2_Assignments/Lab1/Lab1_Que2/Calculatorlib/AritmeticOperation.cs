﻿/*********************************************************************
 * Project              : Calculatorlib
 * File                 : ArithmeticOperation.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : An Dll containg definition of the methods present in Program.cs
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculatorlib
{
    public class AritmeticOperation
    {
        public double addition(double num1, double num2)
        {
            double result;
            result = num1 + num2;
            return result;
        }

        public double subtraction(double num1, double num2)
        {
            double result;
            result = num1 - num2;
            return result;
        }

        public double multiplication(double num1, double num2)
        {
            double result;
            result = num1 * num2;
            return result;
        }

        public double division(double num1, double num2)
        {
            double result;
            result = num1 / num2;
            return result;
        }

        public double moddulus(double num1, double num2)
        {
            double result;
            result = num1 % num2;
            return result;
        }
    }
}
