﻿/*********************************************************************
 * Project              : Lab1_Que2
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : An console Application named as calculator which performs addition,
 *                        subtraction,mul,divand mod of two numbers.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculatorlib;

namespace Lab1_Que2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("******************Calculator Appliction********************");


            Console.WriteLine("Press 1.for Addition.\n2.for Subtarction.\n3.for Multiplication.\n4.for Division\n5.for Modulus");
            int operation;
            operation = Convert.ToInt32(Console.ReadLine());
            double firstNo, secondNo, result;
            Console.WriteLine("Enter first no:");
            firstNo = Convert.ToDouble (Console.ReadLine());
            Console.WriteLine("Enter second no:");
            secondNo = Convert.ToDouble (Console.ReadLine());
            AritmeticOperation calcobj = new AritmeticOperation();

            switch (operation)
            {
                case 1:
                    //logic for add
                    result = calcobj.addition(firstNo, secondNo);
                    Console.WriteLine("Addititon of\t" + firstNo + "\tand\t" + secondNo + "\tis\t" + result);
                    break;
                case 2:
                    //logic for sub
                    result = calcobj.subtraction(firstNo, secondNo);
                    Console.WriteLine("Subtraction of\t" + firstNo + "\tand\t" + secondNo + "\tis\t" + result);
                    break;

                case 3:
                    //logic for mul
                    result = calcobj.multiplication(firstNo, secondNo);
                    Console.WriteLine("Multiplication of\t" + firstNo + "\tand\t" + secondNo + "\tis\t" + result);
                    break;
                case 4:
                    //logic for div
                    result = calcobj.division(firstNo, secondNo);
                    Console.WriteLine("division of\t" + firstNo + "\tand\t" + secondNo + "\tis\t" + result);
                    break;
                case 5:
                    //logic for mod
                    result = calcobj.moddulus(firstNo, secondNo);
                    Console.WriteLine("Modulus of\t" + firstNo + "\tand\t" + secondNo + "\tis\t" + result);
                    break;
                default:
                    Console.WriteLine("Enter valid choice");
                    break;
            }

            Console.ReadLine();
        }
    }
}
