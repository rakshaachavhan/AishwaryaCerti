﻿/*********************************************************************
 * Project              : Lab1_Que4
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to accept and print the details of the student.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolDemo;

namespace Lab1_Que4
{
    class Program
    {
        static void Main(string[] args)
        {
            Student objStudent = new Student();
            Console.WriteLine("****************Accept Details********************");
            Console.WriteLine("Enter student details");

            Console.WriteLine("Enter Roll Number");
            objStudent.Roll = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Name");
            objStudent.Name = Console.ReadLine();

            Console.WriteLine("Enter Age");
            objStudent.Age = Convert.ToByte(Console.ReadLine());

            Console.WriteLine("Enter Gender");
            objStudent.Gender = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("Enter Date of Birth");
            objStudent.BirthDate = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter Address");
            objStudent.Address = Console.ReadLine();

            Console.WriteLine("Enter Percentage");
            objStudent.Percentage = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("\n***************Display Details * ********************");
            Console.WriteLine("Roll Number:" + objStudent.Roll);
            Console.WriteLine("Name:" + objStudent.Name);
            Console.WriteLine("Age:" + objStudent.Age);
            Console.WriteLine("Gender:" + objStudent.Gender);
            Console.WriteLine("Date of Birth:" + objStudent.BirthDate);
            Console.WriteLine("Address:" + objStudent.Address);
            Console.WriteLine("Percentage:" + objStudent.Percentage);
            Console.ReadLine();
        }
    }
}
