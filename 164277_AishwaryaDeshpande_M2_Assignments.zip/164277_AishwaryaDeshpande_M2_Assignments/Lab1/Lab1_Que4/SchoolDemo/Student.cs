﻿/*********************************************************************
 * Project              : School Demo
 * File                 : Student.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : DLL that conatins properties of the Student.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolDemo
{
    public class Student
    {
        int rollNo;
        string studentName;
        byte age;
        char gender;
        DateTime dateOfBirth;
        string address;
        double percentage;

        public string Name //Creating Name property
        {
            get //get method for returning value
            {
                return studentName;
            }
            set // set method for storing value in name field.
            {
                studentName = value;
            }
        }

        public int Roll //Creating RollNo property
        {
            get //get method for returning value
            {
                return rollNo;
            }
            set // set method for storing value in RollNo field.
            {
                rollNo = value;
            }
        }

        public byte Age //Creating Age property
        {
            get //get method for returning value
            {
                return age;
            }
            set // set method for storing value in age field.
            {
                age = value;
            }
        }

        public char Gender //Creating Age property
        {
            get //get method for returning value
            {
                return gender;
            }
            set // set method for storing value in age field.
            {
                gender = value;
            }
        }

        public DateTime BirthDate //Creating Birthdate property
        {
            get //get method for returning value
            {
                return dateOfBirth;
            }
            set // set method for storing value in dateOfBirth field.
            {
                dateOfBirth = value;
            }
        }

        public string Address //Creating Age property
        {
            get //get method for returning value
            {
                return address;
            }
            set // set method for storing value in age field.
            {
                address = value;
            }
        }

        public double Percentage //Creating percentage property
        {
            get //get method for returning value
            {
                return percentage;
            }
            set // set method for storing value in percentage field.
            {
                percentage = value;
            }
        }




    }
}
