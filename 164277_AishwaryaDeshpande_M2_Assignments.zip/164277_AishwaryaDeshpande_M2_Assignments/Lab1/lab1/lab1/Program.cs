﻿/*********************************************************************
 * Project              : Lab1
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to accept and display Employee Details.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;
namespace lab1
{
    class Program
    {
        static void Main(string[] args)
        {
           

            Emp_lib[] objEmplib = new Emp_lib[10]; //To create array of objects.
            /*Modify the console application to use the get set properties*/
            for (int index=0;index<objEmplib.Length; index++)
            {
                objEmplib[index] = new Emp_lib();

                Console.WriteLine("Enter Employee Details");

                Console.WriteLine("Enter Employee Id");
                objEmplib[index].id = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Employee Name");
                objEmplib[index].Name = Console.ReadLine();

                Console.WriteLine("Enter Employee Address");
                objEmplib[index].Address= Console.ReadLine();

                Console.WriteLine("Enter City");
                objEmplib[index].City = Console.ReadLine();

                Console.WriteLine("Enter Department");
                objEmplib[index].Department = Console.ReadLine();

                Console.WriteLine("Enter Salary");
                objEmplib[index].Salary= Convert.ToDouble(Console.ReadLine());

            }

            /*Modify the console application to define an array of objects to hold 10 records of Employee. Accept
              the details of 10 employees from the user using a loop. Display the Employee Name and Salary of all the
              employees.*/
            /*for(int index=0;index<objEmplib.Length;index++)
            {
                objEmplib[index] = new Emp_lib();
                Console.WriteLine("Enter Employee Details");

                Console.WriteLine("Enter Employee Id");
                objEmplib[index].emp_Id =Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Employee Name");
                objEmplib[index].emp_Name = Console.ReadLine();

                Console.WriteLine("Enter Employee Address");
                objEmplib[index].emp_Address = Console.ReadLine();

                Console.WriteLine("Enter City");
                objEmplib[index].emp_City = Console.ReadLine();

                Console.WriteLine("Enter Department");
                objEmplib[index].emp_Department = Console.ReadLine();

                Console.WriteLine("Enter Salary");
                objEmplib[index].salary = Convert.ToDouble(Console.ReadLine());
            }*/


            //Create an object of this class. Accept the values from the user and assign the members.
            /*
              Emp_lib objEmplib = new Emp_lib();
              Console.WriteLine("Enter Employee Details");

              Console.WriteLine("Enter Employee Id");
              objEmplib.emp_Id =Convert.ToInt32(Console.ReadLine());

              Console.WriteLine("Enter Employee Name");
              objEmplib.emp_Name = Console.ReadLine();

              Console.WriteLine("Enter Employee Address");
              objEmplib.emp_Address = Console.ReadLine();

              Console.WriteLine("Enter City");
              objEmplib.emp_City = Console.ReadLine();

              Console.WriteLine("Enter Department");
              objEmplib.emp_Department = Console.ReadLine();

              Console.WriteLine("Enter Salary");
              objEmplib.salary = Convert.ToDouble(Console.ReadLine());
              */


            Console.WriteLine("Employee Details are:");
            for (int index = 0; index < objEmplib.Length; index++)
            {
                Console.WriteLine(objEmplib[index].emp_Id +"\t"+ objEmplib[index].emp_Name +"\t"+ objEmplib[index].emp_Address +"\t"+ objEmplib[index].emp_City +"\t"+objEmplib[index].emp_Department+"\t"+objEmplib[index].salary);
            }
           

            Console.ReadLine();

        }

        
    }
}
