﻿/*********************************************************************
 * Project              : Lab1
 * File                 : Emplib.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : This is an Dll containing An Employee which is used in Program .cs.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Define a class called “Employee” with the following fields:
EmployeeId, Employee Name, Address, City, Department, Salary
Define the functions to set the values of each property and to get the value of the Salary in the class: Compile
the class to generate a DLL.*/
namespace Employee
{
    public class Emp_lib
    {
        public int emp_Id;
        public string emp_Name;
        public string emp_Address;
        public string emp_City;
        public string emp_Department;
        public double salary;
        /*Modify the class to add properties using get, set blocks. Modify the console application to use the
          properties.*/
        public int id //Creating id property
        {
            get //get method for returning value
            {
                return emp_Id;
            }
            set // set method for storing value in emp_Id field.
            {
                emp_Id = value;
            }
        }

        public string Name //Creating Name property
        {
            get //get method for returning value
            {
                return emp_Name;
            }
            set // set method for storing value in emp_Name field.
            {
                emp_Name = value;
            }
        }

        public string Address //Creating Address property
        {
            get //get method for returning value
            {
                return emp_Address;
            }
            set // set method for storing value in emp_Address field.
            {
                emp_Address = value;
            }
        }

        public string City //Creating City property
        {
            get //get method for returning value
            {
                return emp_City;
            }
            set // set method for storing value in emp_City field.
            {
                emp_City = value;
            }
        }

        public string Department //Creating Department property
        {
            get //get method for returning value
            {
                return emp_Department;
            }
            set // set method for storing value in emp_Department field.
            {
                emp_Department = value;
            }
        }

        public double Salary //Creating Salary property
        {
            get //get method for returning value
            {
                return salary;
            }
            set // set method for storing value in salary field.
            {
                salary = value;
            }
        }

    }
}
