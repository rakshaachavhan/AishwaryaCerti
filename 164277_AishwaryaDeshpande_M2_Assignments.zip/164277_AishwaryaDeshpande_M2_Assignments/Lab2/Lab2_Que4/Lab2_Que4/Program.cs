﻿/*********************************************************************
 * Project              : Lab2_Que4.
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to accept Product details and to calculate Total bill amount.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductDemo;
namespace Lab2_Que4
{
    class Program
    {
        static void Main(string[] args)
        {
            int prodId;
            string prodName;
            double price;
            int quantity;
            double totalAmount;

            Product objProduct = new Product();

            Console.WriteLine("Enter Product ID :");
            prodId=Convert.ToInt32( Console.ReadLine());

            Console.WriteLine("Enter Product Name :");
            prodName = Console.ReadLine();

            Console.WriteLine("Enter Product Price :");
            price = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Quantity :");
            quantity = Convert.ToInt32(Console.ReadLine());

            totalAmount = objProduct.calculateAmount(prodId, prodName, price, quantity);

            objProduct.displayProd();

            Console.ReadLine();

        }
    }
}
