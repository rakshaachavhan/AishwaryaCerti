﻿/*********************************************************************
 * Project              : Lab2_Que4.
 * File                 : Product.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : DLL conating definition of the methods that will assign values to product properties and 
 *                        Claculate total payable Amount which will be retuen to main method and will display product details
 *                        boxin and unboxing concept is used here.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDemo
{
    public class Product
    {
        object objProductId;
        object objProductName;
        object objPrice;
        object objQuantity;
        object amountPayable;

        public double calculateAmount(int prodId, string prodName, double price, int quantity)
        {
            // Boxing
            objProductId = prodId;
            objProductName = prodName;
            objPrice = price;
            objQuantity = quantity;
            amountPayable = (int)objQuantity * (double)price;
            return (double)amountPayable;
        }

        public void displayProd()
        {
            Console.WriteLine("Product Details Are:");
            Console.WriteLine("Product Id : " + (int)objProductId);
            Console.WriteLine("Product Name :" + (string)objProductName);
            Console.WriteLine("Price :" + (double)objPrice);
            Console.WriteLine("Amt Payable :" +(double) amountPayable);
        }




    }
}
