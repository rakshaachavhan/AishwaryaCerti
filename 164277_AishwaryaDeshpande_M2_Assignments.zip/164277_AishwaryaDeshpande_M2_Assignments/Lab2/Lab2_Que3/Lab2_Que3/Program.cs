﻿/*********************************************************************
 * Project              : Lab2_Que3
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to accept and print values of Single Dimensional Array.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_Que3
{
    class Program
    {
        static void Main(string[] args)
        {
            SingleDArray();
            Console.ReadLine();
        }
        static void SingleDArray()
        {
            string[] strCountries = new string[5];
            Console.WriteLine("***Accept Array***");
            for (int i = 0; i < strCountries.Length; i++)
            {
                strCountries[i]=Console.ReadLine();
            }
            Console.WriteLine("***Display Array***");
            for (int i = 0; i < strCountries.Length; i++)
            {
                Console.WriteLine(strCountries[i]);
            }

           /* foreach (string strCountry in strCountries)
            {
                Console.WriteLine(strCountry);
            }*/
        }
    }
}
