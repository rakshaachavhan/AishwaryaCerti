﻿/*********************************************************************
 * Project              : Lab1_Que1
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to calculate square and cube of the number.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_Que1
{
    class Program
    {
        static void Main(string[] args)
        {

            int choice, square, cube;
            Console.WriteLine("Press..........\n1.For Square\n2.For Cube");
            choice = Convert.ToInt32(Console.ReadLine());

            Numbers objNum = new Numbers();
            Console.Write("Enter Number whose squre or cube you want to find");
            objNum.number = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    square = objNum.getSquare(objNum.number);
                    objNum.displaySquare(square);
                    break;
                case 2:
                    cube = objNum.getCube(objNum.number);
                    objNum.displayCube(cube);
                    break;


            }
            Console.ReadLine();
        }

    }
}
