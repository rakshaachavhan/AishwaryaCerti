﻿/*********************************************************************
 * Project              : Lab1_Que1
 * File                 : Number.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Contains the definition of the methods which are used to calcute square and cube.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_Que1
{
   struct Numbers
    {
       internal int number;

        public int getSquare(int num)
        {
            return num * num;
        }

        public int getCube(int num)
        {
            return num * num*num;
        }

        public void displaySquare( int num)
        {
            Console.WriteLine("Square of the Number is:" + num);
        }

        public void displayCube(int num)
        {
            Console.WriteLine("Cube of the Number is:" + num);
        }
    }
}
