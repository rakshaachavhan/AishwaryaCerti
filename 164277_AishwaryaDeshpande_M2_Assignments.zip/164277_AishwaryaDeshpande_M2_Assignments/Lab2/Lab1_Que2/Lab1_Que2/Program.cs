﻿/*********************************************************************
 * Project              : Lab1_Que2
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : To Accept values of Multidimensional Array and to print it.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_Que2
{
    class Program
    {
        static void Main(string[] args)
        {
            MultiDArray();
            Console.ReadLine();
        }

        static void MultiDArray()
        {
            Console.WriteLine("***Accept Multidimensional Array******");
           int[,] numbers = new int[5, 6];
            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                   numbers[i,j]=Convert.ToInt32(Console.ReadLine());
                }
                
            }
            Console.WriteLine("*****Display Multidimensional Array*********");
            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.Write(numbers[i, j] + "    ");
                }
                Console.Write("\n");
            }
        }


    }
}
