﻿/*********************************************************************
 * Project              : Lab2_Que5
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to accept and print book details using arrya concept.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_Que5
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string[] colName = new string[4];
            colName[0] = "Book Title";
            colName[1] = "Author";
            colName[2] = "Publisher";
            colName[3] = "Price";
            string[,] bookDetails = new string[2, 4];
            Console.WriteLine("Enter Book detials");
            for(int row=0;row<bookDetails.GetLength(0);row++)
            {
                for(int col=0;col<bookDetails.GetLength(1);col++)
                {
                    if(row==0)
                    {
                        bookDetails[0, 0] = colName[0];
                        bookDetails[0, 1] = colName[1];
                        bookDetails[0, 2] = colName[2];
                        bookDetails[0, 3] = colName[3];
                    }
                    else
                    {
                        bookDetails[row,col] = Console.ReadLine();
                    }
                }
                Console.WriteLine("\n");
            }

            for(int row=0;row<bookDetails.GetLength(0);row++)
            {
                for (int col = 0; col < bookDetails.GetLength(1);col++)
                {
                    Console.Write(bookDetails[row,col]+"  ");
                }
                Console.WriteLine("\n"); 
            }
            Console.ReadLine();
        }
    }
}
