﻿/*/*********************************************************************
 * Project              : Lab9
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Dictionary<> Demo with operations like Add, Update ,Display.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            char flag;
            Dictionary<string,string> objDictonary = new Dictionary<string, string>();

            do
            {
                
                Console.WriteLine("Press 1 to add object \n Press 2 to update \n Press 3 to print dictionary");
                choice = Convert.ToInt32(Console.ReadLine());
                
                switch (choice)
                {
                    case 1: //Add
                        string key;
                        string value;
                        
                        Console.WriteLine("Enter Key");
                        key = Console.ReadLine();
                        Console.WriteLine("Enter Value");
                        value = Console.ReadLine();
                        if (objDictonary.ContainsKey(key))
                        {
                            Console.WriteLine("Key already Exists");
                        }
                        else
                        {
                            objDictonary.Add(key, value);
                        }
                        break;
                    case 2:
                        //update
                        Console.WriteLine("Enter the key to update value");
                        string key1;
                        key1 =Console.ReadLine();
                        bool containsKey = objDictonary.ContainsKey(key1);
                        if(containsKey == true)
                        {
                            Console.WriteLine("Enter the value to update");
                            string value1;
                            value1 = Console.ReadLine();
                            objDictonary[key1] = value1;
                            //
                            objDictonary.Add(key1, value1);
                        }
                        else
                        {
                            Console.WriteLine("Key not found");
                        }
                        

                        break;
                    case 3:
                        //display
                        foreach (KeyValuePair<string, string> pair in objDictonary)
                        {
                            Console.WriteLine("{0} {1}", pair.Key, pair.Value);
                        }
                        break;
                    default:
                        Console.WriteLine("Enter correct choice");
                        break;


                }
                Console.WriteLine("Press y to continue and any other button to exit");
                flag = Convert.ToChar(Console.ReadLine());
            } while(flag == 'Y'||flag=='y');
            Dictionary<int, string> dictionaryobj = new Dictionary<int, string>();

           
        }

        
    }
}
