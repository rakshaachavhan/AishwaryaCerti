﻿/*********************************************************************
 * Project              : Lab3_Que4
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to accept and print details of the supplierSS.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que4
{
    class Program
    {
        static void Main(string[] args)
        {
            SupplierTest supplier = new SupplierTest();
            Console.WriteLine("*************Accept Details*************");
            supplier.acceptDetails();
            Console.WriteLine("\n\n************Display Details**************");
            supplier.displayDetails();
            Console.ReadLine();

        }
    }
}
