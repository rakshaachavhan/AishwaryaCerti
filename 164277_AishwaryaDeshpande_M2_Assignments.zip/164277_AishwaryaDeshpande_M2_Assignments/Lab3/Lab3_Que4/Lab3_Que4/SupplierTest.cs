﻿/*********************************************************************
 * Project              : Lab3_Que4
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : SupplierTest Class.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que4
{
    class SupplierTest
    {
        int supplierId;
        string supplierName;
        string city;
        string phoneNo;
        string email;

        public void acceptDetails()
        {
            Console.WriteLine("Enter Supplier Id:");
            supplierId = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Supplier Name:");
            supplierName = Console.ReadLine();

            Console.WriteLine("Enter City:");
            city = Console.ReadLine();

            Console.WriteLine("Enter Phone No:");
            phoneNo = Console.ReadLine();

            Console.WriteLine("Enter Emial:");
            email = Console.ReadLine();
        }

        public void displayDetails()
        {
            Console.WriteLine("Supplier Id:" + supplierId);
            Console.WriteLine("Supplier Name:" + supplierName);
            Console.WriteLine("Supplier City:" + city);
            Console.WriteLine("Phone No:" + phoneNo);
            Console.WriteLine("Email:" + email);

        }
    }
}
