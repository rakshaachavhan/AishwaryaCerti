﻿/*********************************************************************
 * Project              : Lab3_Que1
 * File                 : Participant.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Contains Properties of Student and method to calculate percentage of student.
 * Version              : 1.0
 * Last Modified Date   : 26/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que1
{
    class Participant
    {
        private int empId;
        private string name;
        private string comapnyName;
        private int foundationMarks;
        private int webBasicMarks;
        private int dotNetMarks;
        private double totalMarks = 300;
        private double obtainedMarks;
        private double percentage;

        public int EmpId
        {
            get
            {
                return empId;
            }
            set
            {
                empId = value;
            }
        }
        public string CompName
        {
            get
            {
                return comapnyName;
            }
            set
            {
                comapnyName = value;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name=value;
            }
        }

        public int FoundationMarks
        {
            get
            {
                return foundationMarks;
            }
            set
            {
                foundationMarks = value;
            }
        }

        public int webMarks
        {
            get
            {
                return webBasicMarks;
            }
            set
            {
                webBasicMarks = value;
            }
        }

        public int dotMarks
        {
            get
            {
                return dotNetMarks;
            }
            set
            {
                dotNetMarks = value;
            }
        }

        public Participant()
        {

        }

        public Participant(int empId,string name,int fmarks,int wmarks,int dmarks)
        {
            if((fmarks>=0 && fmarks<100) &&(wmarks>=0 && wmarks<100)&&(dmarks>=0&&dotMarks<100))
            {
                EmpId = empId;
                Name = name;
                FoundationMarks = fmarks;
                webMarks = wmarks;
                dotMarks = dmarks;
                CompName = "Corporate Unniversity";
            }
            else
            {
                EmpId = 0;
                Name = "0";
                FoundationMarks = 0;
                webMarks = 0;
                dotMarks = 0;
                CompName = "0";
            }
            
        }

        public void calculateObtainedMarks()
        {
            obtainedMarks = FoundationMarks + webMarks + dotMarks;
            //return obtainedMarks;
        }
         
        public void CalculatePercentage()
        {
            percentage = Convert.ToDouble((obtainedMarks / totalMarks) * 100);
        }
        
        public void display()
        {
            Console.WriteLine("Employee Id:" + EmpId);
            Console.WriteLine("Emplyee Name:" + Name);
            Console.WriteLine("Company Name:" + CompName);
            Console.WriteLine("Foundation Marks" + FoundationMarks);
            Console.WriteLine("Web Basics Marks" + webMarks);
            Console.WriteLine("Dot Net Marks" + dotMarks);
            Console.WriteLine("Total Marks:" + totalMarks);
            Console.WriteLine("Obtained Marks:" + obtainedMarks);
            Console.WriteLine("Percentage:" + percentage);


        }

    }
}
