﻿/*********************************************************************
 * Project              : Lab3_Que1
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to accept details,marks and calculate percentage of student.
 * Version              : 1.0
 * Last Modified Date   : 27/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que1
{
    class Program
    {
        static void Main(string[] args)
        {
            int id;
            int found_marks;
            int web_marks;
            int dot_marks;
            string stu_name;
            //int obtain_marks;
            Console.WriteLine("*************Accept Details****************");
            Console.WriteLine("Enter id");
            id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Name:");
            stu_name = Console.ReadLine();

            Console.WriteLine("Enter Foundation Marks:");
            found_marks = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Web Basics Marks:");
            web_marks = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter DotnetMarks Marks:");
            dot_marks = Convert.ToInt32(Console.ReadLine());

            Participant objParticipant = new Participant(id, stu_name, found_marks, web_marks, dot_marks);
            //obtain_marks = objParticipant.calculateObtainedMarks();
             objParticipant.calculateObtainedMarks();
             objParticipant.CalculatePercentage();
            Console.WriteLine("\n\n*************Print Detials****************");
            objParticipant.display();
            Console.ReadLine();
             

     



        }
    }
}
