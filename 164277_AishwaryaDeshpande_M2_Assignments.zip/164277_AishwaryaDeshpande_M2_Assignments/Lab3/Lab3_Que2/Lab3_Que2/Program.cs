﻿/*********************************************************************
 * Project              : Lab3_Que2
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to understand Concept of method overloading.
 * Version              : 1.0
 * Last Modified Date   : 28/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que2
{
    class Program
    {
        static void Main(string[] args)
        {
            Bird b1 = new Bird();
            Bird b = new Bird("Eagle", 200);
            b.fly();
            b.fly(300);
            Console.ReadLine();
        }
    }
}
