﻿/*********************************************************************
 * Project              : Lab3_Que3
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : It is class.
 * Version              : 1.0
 * Last Modified Date   : 28/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace Lab3_Que3
{
    class Car 
    {
        string carsMake;
         public string carModel;
        int manufactYear;
        double salePrice;

       public Car()
        {

        }

        public Car(string make, string model, int year ,double price)
        {
            carsMake = make;
            carModel = model;
            manufactYear = year;
            salePrice = price;

            //Console.WriteLine(carsMake);
        }

        public void Print()
        {
            Console.WriteLine(carsMake + "\t" + carModel + "\t" + manufactYear + "\t" + salePrice);
        }

        
    }
}
