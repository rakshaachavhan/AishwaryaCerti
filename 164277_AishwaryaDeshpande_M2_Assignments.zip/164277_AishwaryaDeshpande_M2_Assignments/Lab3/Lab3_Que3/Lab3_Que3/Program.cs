﻿/*********************************************************************
 * Project              : Lab3_Que3
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to maintain Car catalog.
 * Version              : 1.0
 * Last Modified Date   : 28/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Lab3_Que3
{
    class Program
    {
        static void Main(string[] args)
        {
            char flag;

            do
            {
                int choice, manufactYear;
                string carsMake, carModel;
                double salePrice;
                
                Console.WriteLine("1.Add new Car\n2.Modify Car details\n3.Search Car\n4.Display all cars\n5.Delete Car\n6.Quit");

                Console.WriteLine("Enter choice");
                choice = Convert.ToInt32(Console.ReadLine());

                List<Car> carList = new List<Car>();

                switch (choice)
                {
                    case 1:
                        //Adding new car
                  
                        Console.WriteLine("Enter Cars Make");
                        carsMake = Console.ReadLine();

                        Console.WriteLine("Enter Car Model");
                        carModel = Console.ReadLine();

                        Console.WriteLine("Enter Car Manufacture Year");
                        manufactYear = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("Enter Sale Price");
                        salePrice = Convert.ToDouble(Console.ReadLine());

                        carList.Add(new Car(carsMake, carModel, manufactYear, salePrice));
                        break;

                    case 2:
                        //Modify car details

                        break;
                    case 3:
                        //search car
                        Console.WriteLine("Enter the car model to search car");
                        string find = Console.ReadLine();
                        Console.WriteLine("The" + find + "is present:" + carList.Exists(x=>x.carModel==find));
                        break;

                    case 4:
                        //list all cars
                        Console.WriteLine("The Cars in catalog Are:");
                        for(int i=0;i<carList.Count;i++)
                        {
                            carList[i].Print();
                        }
                        break;
                    case 5:
                        //del car
                        Console.WriteLine("Enter the model of car which you want to remove");
                        string carmodel1 = Console.ReadLine();
                        int result = Convert.ToInt32(carList.Find(x => x.carModel.Contains(carmodel1)));
                        carList.RemoveAt(result);

                        break;
                    case 6:
                        //quit
                        break;
                    default:
                        Console.WriteLine("Enter valid choice");
                        break;

                }
                Console.WriteLine("Do you want to continue Y/N");
                flag = Convert.ToChar(Console.ReadLine());
            } while (flag == 'y' || flag == 'Y');
        }
    }
}
