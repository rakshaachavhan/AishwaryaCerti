﻿/*********************************************************************
 * Project              : Lab5_Que1
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Class ICICI inherited from Abstract base Class BankAccount.
 * Version              : 1.0
 * Last Modified Date   : 30/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_Que1
{
    class ICICI :BankAccount
    {
        //bool result;
        public override bool Withdraw(double amount)
        {
            if ((balance - amount) >= 0)
            {
                balance = balance - amount;
                return true;
            }
            else
            {
                return false;
            }
            
            //throw new NotImplementedException();

        }

        public override bool Transfer(IBankAccount toAccount, double amount)
        {
            
            if (Withdraw(amount)&&balance >= 1000)
            {
                toAccount.Deposit(amount);
                
            }
            return true;


            //throw new NotImplementedException();
        }

        public override double GetBalance()
        {
            return balance;
            //throw new NotImplementedException();
        }

      

        public override BankAccountType _AccountType
        {
            //get => throw new NotImplementedException();
            //set => throw new NotImplementedException();
            get
            {
                return AccountType;
            }
            set
            {
                AccountType = value;
            }
        }
    }
}
