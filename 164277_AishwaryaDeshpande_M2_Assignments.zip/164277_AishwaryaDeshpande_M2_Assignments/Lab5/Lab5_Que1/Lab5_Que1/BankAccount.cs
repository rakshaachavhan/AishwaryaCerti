﻿/*********************************************************************
 * Project              : Lab5_Que1
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Abstract Class BankAccount Implementing Interface IBankAccount.
 * Version              : 1.0
 * Last Modified Date   : 30/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_Que1
{
    abstract class BankAccount : IBankAccount
    {
        protected double balance=0.0;
        public BankAccountType AccountType;
        public double Balance
        {
            get
            {
                return balance;
            }
            set
            {
                balance = value;
            }

        }

        public abstract double GetBalance();

        public abstract bool Withdraw(double amount);
        public abstract bool Transfer(IBankAccount toAccount, double amount);
        public abstract BankAccountType _AccountType { get; set; }

        public void Deposit(double amount)
        {
            balance = balance + amount;
        }
    }
}
