﻿/*********************************************************************
 * Project              : Lab5_Que1
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to perfrom Various operations on Objects of classe of ICICI and HSBC class.
 * Version              : 1.0
 * Last Modified Date   : 30/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_Que1
{
    class Program
    {
        static void Main(string[] args)
        {
           
            ICICI objICICI1 = new ICICI();
            ICICI objICICI2 = new ICICI();

           
            objICICI1.AccountType=BankAccountType.Saving;
            Console.WriteLine("Account Type of object1:" + objICICI1.AccountType);
            objICICI1.Deposit(50000);
            Console.WriteLine("The Balance object1 is:" + objICICI1.GetBalance());       
                
            objICICI2.AccountType = BankAccountType.Current;
            Console.WriteLine("\n\nAccount Type: object 2" + objICICI2.AccountType);
            objICICI2.Deposit(20000);
            Console.WriteLine("The Balance of Object2 is:" + objICICI2.GetBalance());

            objICICI1.Transfer(objICICI2, 5000);

            Console.WriteLine("\n\nThe Amount After Transfer");
            Console.WriteLine("The Balance object1 is:" + objICICI1.GetBalance());

            Console.WriteLine("The Balance of Object2 is:" + objICICI2.GetBalance());

            HSBC objHSBC1 = new HSBC();
            objHSBC1.AccountType = BankAccountType.Saving;
            Console.WriteLine("\n\n\nAccount Type of object1:" + objHSBC1.AccountType);
            objHSBC1.Deposit(50000);
            Console.WriteLine("The Balance object1 is:" + objHSBC1.GetBalance());

            HSBC objHSBC2 = new HSBC();
            objHSBC2.AccountType = BankAccountType.Current;
            Console.WriteLine("Account Type of object2:" + objHSBC2.AccountType);
            objHSBC2.Deposit(50000);
            Console.WriteLine("The Balance object2 is:" + objHSBC2.GetBalance());

            objHSBC1.Transfer(objHSBC2, 30000);

            Console.WriteLine("\n\nThe Amount After Transfer");
            Console.WriteLine("The Balance object1 is:" + objHSBC1.GetBalance());

            Console.WriteLine("The Balance of Object2 is:" + objHSBC2.GetBalance());


            Console.ReadLine();

        }
    }
}
