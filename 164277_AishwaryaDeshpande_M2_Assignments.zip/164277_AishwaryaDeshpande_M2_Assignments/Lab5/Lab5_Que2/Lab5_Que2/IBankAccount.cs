﻿/*********************************************************************
 * Project              : Lab5_Que2
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Interface IBankAccount.
 * Version              : 1.0
 * Last Modified Date   : 30/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_Que2
{
    public enum BankAccountType
    {
        Current = 1,
        Saving = 2
    }
    public interface IBankAccount
    {
       
            double GetBalance();
            void calculateInterest();
            void Deposit(double amount);
            bool Withdraw(double amount);
            bool Transfer(IBankAccount toAccount, double amount);
            BankAccountType _AccountType { get; set; }
        
    }
}
