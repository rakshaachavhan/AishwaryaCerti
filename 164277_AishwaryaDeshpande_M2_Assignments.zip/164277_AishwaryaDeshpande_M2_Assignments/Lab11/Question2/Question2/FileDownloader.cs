﻿/**********************************************************************
 * Project              : Question2
 * File                 : FileDownloader.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Delegates and Events Demo.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question2
{
    public delegate void DownloadCompeteHandler(int perc);
    public class FileDownloader
    {
        protected string resourceUrl;
        protected string resourceSavePath;
        public event DownloadCompeteHandler DownLoadComplete;
        public FileDownloader(string url, string savepath)
        {
            resourceUrl = url;
            resourceSavePath = savepath;
        }
        public void DownLoadResource(int perc)
        {
            //This is just download simulation place holder code
            for (int i = 1; i <= 4; i++)
            {
                //Dummy loop to add a delay
                for (int j = 1; i <= 10000; i++) ;
                    OnDownLoadComplete(i * 25);
            }
        }
        protected void OnDownLoadComplete(int perc)
        {
            if (DownLoadComplete == null)
                DownLoadComplete(perc);
        }
    }
}
