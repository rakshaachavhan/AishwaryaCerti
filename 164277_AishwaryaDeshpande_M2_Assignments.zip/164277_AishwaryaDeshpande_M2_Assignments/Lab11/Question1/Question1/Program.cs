﻿/**********************************************************************
 * Project              : Question1
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Delegates and Events Demo.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            CreditCard objICICICC = new CreditCard();
            objICICICC.makePay += new MakePayment(ObjICICICC_makePay) ;
            objICICICC.AccountType = BankAccount.BankAccountTypeEnum.Saving;
            objICICICC.BalanceAmount = 20000;
            objICICICC.CardHolderName = "Ram";
            objICICICC.CreditCardNo = "1234567890";
            objICICICC.CreditLimit = 100000;
            objICICICC.MakePayment(10000);
            Console.ReadLine();
        }

        private static void ObjICICICC_makePay(double amount)
        {
            Console.WriteLine("Amount deposited is: " + amount);
        }
    }
}
