﻿/*/*********************************************************************
 * Project              : Lab10_1
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Delegates Demo
 * Version              : 1.0
 * Last Modified Date   : 01/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_1
{
    class Program
    {
        static void Main(string[] args)
        {
            ArithmeticOperation operationObj = new ArithmeticOperation();

            ArithmeticHandler arithObj1, arithObj2, arithObj3, arithObj4, arithObj5;
            arithObj1 = new ArithmeticHandler(operationObj.Addition);
            arithObj2 = new ArithmeticHandler(operationObj.Subtraction);
            arithObj3 = new ArithmeticHandler(operationObj.Multiply);
            arithObj4 = new ArithmeticHandler(operationObj.Divide);
            arithObj5 = new ArithmeticHandler(operationObj.Max);

            Console.WriteLine("ENter two number");
            int a = int.Parse(Console.ReadLine());

            int b = int.Parse(Console.ReadLine());


            arithObj1.Invoke(a, b);
            arithObj2.Invoke(a, b);
            arithObj3.Invoke(a, b);
            arithObj4.Invoke(a, b);
            arithObj5.Invoke(a, b);

        }
    }
}
