﻿/*/*********************************************************************
 * Project              : Lab10_2
 * File                 : ArithmeticOperation.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_2
{
    public delegate void ArithmeticHandler(int firstNumber, int secondNumber);
    class ArithmeticOperation
    {
        public void Addition(int firstNumber, int secondNumber)
        {
            Console.WriteLine("Addtion of {0} and {1} is {2}", firstNumber, secondNumber, firstNumber + secondNumber);

        }
        public static void PerformArithmeticOperation(int num1, int num2, ArithmeticHandler arOperation)
        {
            arOperation.Invoke(num1, num2);
        }
    }
}
