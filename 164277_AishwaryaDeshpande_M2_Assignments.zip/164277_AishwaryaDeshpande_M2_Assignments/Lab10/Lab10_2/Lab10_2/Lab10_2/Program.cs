﻿/*/*********************************************************************
 * Project              : Lab10_2
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Delegtes Demo
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_2
{
    class Program
    {
        static void Main(string[] args)
        {
            ArithmeticOperation operationObj = new ArithmeticOperation();
            Console.WriteLine("ENter two number");
            int a = int.Parse(Console.ReadLine());

            int b = int.Parse(Console.ReadLine());
            ArithmeticOperation.PerformArithmeticOperation(a, b, new ArithmeticHandler(operationObj.Addition));
        }
    }
}
