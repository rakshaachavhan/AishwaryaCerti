﻿/*********************************************************************
 * Project              : Lab4_Que1
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Version              : 1.0
 * Last Modified Date   : 29/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que3
{
    class Shape
    {
        public virtual void WhoamI()
        {
            Console.WriteLine("I m Shape");
        }
    }
}
