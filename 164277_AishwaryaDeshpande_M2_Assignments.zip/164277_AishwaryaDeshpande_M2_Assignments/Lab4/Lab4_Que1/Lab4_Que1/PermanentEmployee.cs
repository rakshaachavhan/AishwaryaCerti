﻿/*********************************************************************
 * Project              : Lab4_Que1
 * File                 : PermanentEmployee.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Class Inherited from Abstract Class Employee.
 * Version              : 1.0
 * Last Modified Date   : 29/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que1
{
    class PermanentEmployee:Employee
    {
        int noOfLeaves;
        double providendFund;

        public int Leaves
        {
            get
            {
                return noOfLeaves;
            }
            set
            {
                noOfLeaves = value;
            }
        }

        public double Fund
        {
            get
            {
                return providendFund;
            }
            set
            {
                providendFund = value;
            }
        }



        public override double getSal(double providenedFunds)
        {
            return sal - providenedFunds;
        }

        public void acceptDetails()
        {
            //throw new NotImplementedException();

            Console.WriteLine("Enter Employee Id");
            id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Employee Name");
            Name = Console.ReadLine();

            Console.WriteLine("Enter Employee Address");
            Address = Console.ReadLine();

            Console.WriteLine("Enter Employee City");
            City = Console.ReadLine();

            Console.WriteLine("Enter Employee Department");
            Department = Console.ReadLine();

            Console.WriteLine("Enter No of Leaves");
            Leaves = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Employee Salary");
            sal = Convert.ToInt32(Console.ReadLine());

        }

        public void display()
        {
            Console.WriteLine("Employee Id:" + id + "\nEmployee Name:" + Name + "\nEmployee Address:" + Address + "\nEmployee City:" + City + "\nDepartment:"+Department+"\nLeaves:"+Leaves+"\nEmployee Salary:" + sal);
        }
    }
}
