﻿/*********************************************************************
 * Project              : Lab4_Que1
 * File                 : ContractEmployee.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Class Inherited from Abstract Class Employee.
 * Version              : 1.0
 * Last Modified Date   : 29/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que1
{
    class ContractEmployee : Employee
    {
        double perks;

        public double Perks
        {
            get
            {
                return perks;
            }
            set
            {
                perks = value;
            }
        }

        public override double getSal(double perks)
        {
            return sal+perks;
        }

        public  void acceptDetails()
        {
            //throw new NotImplementedException();

            Console.WriteLine("Enter Employee Id");
            id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Employee Name");
            Name = Console.ReadLine();

            Console.WriteLine("Enter Employee Address");
            Address = Console.ReadLine();

            Console.WriteLine("Enter Employee City");
            City = Console.ReadLine();

            Console.WriteLine("Enter Employee Department");
            Department = Console.ReadLine();

           
            Console.WriteLine("Enter Employee Salary");
            sal = Convert.ToInt32(Console.ReadLine());


        }

        public void display()
        {
            Console.WriteLine("Employee Id:" + id + "\nEmployee Name:" + Name + "\nEmployee Address:"+Address+"\nEmployee City:"+City+ "\n Depaetment:"+Department+"\nEmployee Salary:" +sal);
        }
    }
}
