﻿/*********************************************************************
 * Project              : Lab4_Que1
 * File                 : Employee.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : It is An Abstract class Employee.
 * Version              : 1.0
 * Last Modified Date   : 29/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que1
{
    abstract class Employee
    {
        public int emp_Id;
        public string emp_Name;
        public string emp_Address;
        public string emp_City;
        public string emp_Department;
        public double salary;

        public int id //Creating id property
        {
            get //get method for returning value
            {
                return emp_Id;
            }
            set // set method for storing value in emp_Id field.
            {
                emp_Id = value;
            }
        }

        public string Name //Creating Name property
        {
            get //get method for returning value
            {
                return emp_Name;
            }
            set // set method for storing value in emp_Name field.
            {
                emp_Name = value;
            }
        }

        public string Address //Creating Address property
        {
            get //get method for returning value
            {
                return emp_Address;
            }
            set // set method for storing value in emp_Address field.
            {
                emp_Address = value;
            }
        }

        public string City //Creating City property
        {
            get //get method for returning value
            {
                return emp_City;
            }
            set // set method for storing value in emp_City field.
            {
                emp_City = value;
            }
        }

        public string Department //Creating Department property
        {
            get //get method for returning value
            {
                return emp_Department;
            }
            set // set method for storing value in emp_Department field.
            {
                emp_Department = value;
            }
        }

        public double sal //Creating id property
        {
            get //get method for returning value
            {
                return salary;
            }
            set // set method for storing value in emp_Id field.
            {
                salary = value;
            }
        }

        
        public abstract double getSal(double salary);
        
    }
}
