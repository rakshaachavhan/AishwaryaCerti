﻿/*********************************************************************
 * Project              : Lab4_Que1
 * File                 : Proram.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program to Display Type of eMployee and Based on type other info of an Employee.
 * Version              : 1.0
 * Last Modified Date   : 29/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que1
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
           
            Console.WriteLine("Enter the Which type of Emplyee you are");
            Console.WriteLine("1.Contract Based Employee\n2.Permanent Emplloyee");
            choice = Convert.ToInt32(Console.ReadLine());

            switch(choice)
            {
                case 1:
                    ContractEmployee objContract = new ContractEmployee();
                    objContract.acceptDetails();
                    Console.WriteLine("Enter the perks to calculate total salary");
                    objContract.Perks = Convert.ToDouble(Console.ReadLine());
                    objContract.salary = objContract.getSal(objContract.Perks);
                    objContract.display();
                    break;
                case 2:
                    PermanentEmployee objPermanent = new PermanentEmployee();
                    objPermanent.acceptDetails();
                    Console.WriteLine("Enter the providened Fund to calculate total salary");
                    objPermanent.Fund = Convert.ToDouble(Console.ReadLine());
                    objPermanent.salary = objPermanent.getSal(objPermanent.Fund);
                    objPermanent.display();
                    break;
                default:
                    Console.WriteLine("Enter valid Type");
                    break;
            }

            Console.ReadLine();
        }
    }
}
