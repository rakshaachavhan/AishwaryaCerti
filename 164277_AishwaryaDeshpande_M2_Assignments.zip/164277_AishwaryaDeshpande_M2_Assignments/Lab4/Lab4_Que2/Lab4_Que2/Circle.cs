﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que2
{
    class Circle : Shape
    {
        public override void WhoamI()
        {
            Console.WriteLine("I m Circle");
        }
    }
}
