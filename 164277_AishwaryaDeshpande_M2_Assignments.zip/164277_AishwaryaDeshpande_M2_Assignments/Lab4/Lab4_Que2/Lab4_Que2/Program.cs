﻿/*********************************************************************
 * Project              : Lab4_Que2
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Version              : 1.0
 * Last Modified Date   : 29/11/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que2
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape s;
            s = new Triangle();
            s.WhoamI();
            s = new Circle();
            s.WhoamI();
            Console.ReadKey();
        }
    }
}
