﻿/*********************************************************************
 * Project              : Lab6_Que1
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Program ro Introduce Demo of Customize Exceptions.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Que1
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer customer;
            try
            {
                //handle exception if occured
                customer = new Customer(1, "Vidya", "Pune", "Aurangabad", "9876543214", 70000);
                customer.printCustDetails();
            }
            catch (InvalidCreditLimit e)
            {
                //print error 
                Console.WriteLine(e.Message);
            }
            Console.ReadLine();
        }
    }
}
