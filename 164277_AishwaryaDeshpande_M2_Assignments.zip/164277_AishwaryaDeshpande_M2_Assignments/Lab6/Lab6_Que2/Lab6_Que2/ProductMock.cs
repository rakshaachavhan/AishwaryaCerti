﻿/*********************************************************************
 * Project              : Lab6_Que2
 * File                 : ProductMock.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : ProductMock Class.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Que2
{
    class ProductMock
    {
        private int productID;
        private string productName;
        private double price;

        public int _productID
        {
            get
            {
                return productID;
            }
            set
            {
                productID = value;
            }
        }
        public string _productName
        {
            get
            {
                return productName;
            }
            set
            {
                productName = value;
            }
        }
        public double _price
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }

        public ProductMock()
        { }

        public ProductMock(int productID, string productName, double price)
        {
            /*
             * check if product id >= 0 then only initialization is possible else throw a exception 
             */
            if (productID >= 0)
                this.productID = productID;
            else
                throw new DataEntryException("Product ID must be greater than zero");


            /*
            * check if product name != "" then only initialization is possible else throw a exception 
            */
            if (productName != "")
                this.productName = productName;
            else
                throw new DataEntryException("Product Name cannot be left blank");

            /*
            * check if product price >= 0 then only initialization is possible else throw a exception 
            */
            if (price >= 0)
                this.price = price;
            else
                throw new DataEntryException("Price of product must be greater than zero.");

        }
    }
}
