﻿/*********************************************************************
 * Project              : Lab6_Que2
 * File                 : DataEntryException.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Userdefined Exception Class DataEntryException.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Que2
{
    class DataEntryException : ApplicationException
    {
        //default constructor
        public DataEntryException()
        { }

        //parameterized constructor
        public DataEntryException(string s) : base(s)
        {
        }
    }
}
