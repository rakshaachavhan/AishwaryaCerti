﻿/**********************************************************************
 * Project              : Lab13_1
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Serialization on objects of Contacts class created in lab 7_1.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Contact;


namespace Lab13_1
{
    class Program
    {
        static void Main(string[] args)
        {
            SerializeData();
            Console.ReadLine();

        }
        private static void SerializeData()
        {
            try
            {
                Contacts objContact = new Contacts();
                objContact.ContactNo = 1;
                objContact.ContactName = "a";
                objContact.CellNo = "9876543210";

                FileStream fileStream = new FileStream("C:\\Users\\aishwade\\Desktop\\text_files\\ser1.dat", FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, objContact);
                fileStream.Close();
                Console.Write("Suceessful!!!!!!");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
