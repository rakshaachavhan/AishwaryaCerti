﻿/**********************************************************************
 * Project              : Lab 13_Que3
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Serialization and Deserialization using Soap Formatter.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contact;
using System.Runtime.Serialization.Formatters.Soap;
using System.IO;

namespace Lab13_Que3
{
    class Program
    {
        static void Main(string[] args)
        {
            SerializeData();
            DeserializeData();
            Console.ReadLine();
        }

        private static void SerializeData()
        {
            ArrayList ContactList = new ArrayList();
            try
            {
                Console.WriteLine("Enter number of contacts");
                int n = int.Parse(Console.ReadLine());

                for (int index = 0; index < n; index++)
                {
                    Contacts objContact = new Contacts();
                    Console.WriteLine(" contact details");
                    Console.WriteLine("Enter Contact id:");
                    objContact.ContactNo = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Name:");
                    objContact.ContactName = Console.ReadLine();
                    Console.WriteLine("Enter Contact Number:");
                    objContact.CellNo = Console.ReadLine();
                    ContactList.Add(objContact);
                }
                string fileName;
                Console.WriteLine("Enter File Location");
                fileName = Console.ReadLine();
                FileStream fileStream = new FileStream(fileName, FileMode.Create);
                SoapFormatter formatter = new SoapFormatter();
                formatter.Serialize(fileStream, ContactList);
                fileStream.Close();
                Console.Write("Suceessful!!!!!!");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DeserializeData()
        {
            try
            {
                string fileName;
                Console.WriteLine("Enter File Location");
                fileName = Console.ReadLine();
                FileStream fileStream = new FileStream(fileName, FileMode.Open);
                SoapFormatter formatter = new SoapFormatter();
                ArrayList obj = (ArrayList)formatter.Deserialize(fileStream);
                fileStream.Close();
                foreach (Contacts c in obj)
                {
                    Console.WriteLine("Cell No:" + c.CellNo + "Name:" + c.ContactName);
                }



            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
