﻿/**********************************************************************
 * Project              : Lab13_2
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : Serialization and Desrialization on Objects of Contacts Class Created in Lab 7_1.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Contact;

namespace LAb13_2
{
    class Program
    {
        static void Main(string[] args)
        {

            SerializeData();
           DeserializeData();
            Console.ReadLine();

        }
        private static void SerializeData()
        {
            List<Contacts> ContactList = new List<Contacts>();
            try
            {
                Console.WriteLine("Enter number of contacts");
                int n = int.Parse(Console.ReadLine());

                for (int index = 0; index < n; index++)
                {
                    Contacts objContact = new Contacts();
                    Console.WriteLine(" contact details");
                    Console.WriteLine("Enter Contact id:");
                    objContact.ContactNo = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Contact Name:");
                    objContact.ContactName = Console.ReadLine();
                    Console.WriteLine("Enter Contact No:");
                    objContact.CellNo = Console.ReadLine();
                    ContactList.Add(objContact);
                }
                string fileName;
                Console.WriteLine("Enter File Location");
                fileName = Console.ReadLine();

                FileStream fileStream = new FileStream(fileName, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, ContactList);
                fileStream.Close();
                Console.Write("Suceessful!!!!!!");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void DeserializeData()
        {
            try
            {
                string fileName;
                Console.WriteLine("Enter File Location");
                fileName = Console.ReadLine();
                FileStream fileStream = new FileStream(fileName, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                List<Contacts> obj = (List<Contacts>)binaryFormatter.Deserialize(fileStream);
                fileStream.Close();
                foreach (Contacts c in obj)
                {
                    Console.WriteLine("Cell No:" + c.CellNo + "Name:" + c.ContactName);
                }

             

            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
    }

