﻿/**********************************************************************
 * Project              : Lab12_3
 * File                 : Program.cs
 * Author Name          : Aishwarya K. Deshpande(164277)
 * Desc                 : File Handling.
 * Version              : 1.0
 * Last Modified Date   : 03/12/2018
 *********************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lab12_3
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                char choice;
                
                Console.WriteLine("1. Create Directory");
                Console.WriteLine("2. Enter the Batch Details");
                Console.WriteLine("3. Copy directory to other directory");
                Console.WriteLine("4. View the Batch Details");
                Console.WriteLine("Enter your Choice:");
                int num;
                num = Convert.ToInt32(Console.ReadLine());

                switch (num)
                {
                    case 1:
                        createDirectory();
                        break;

                    case 2:
                        batchDetails();
                        break;

                    case 3:
                        copy();
                        break;

                    case 4:
                        viewdetails();
                        break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("Do you want to continue?(y/n)");
                choice = Convert.ToChar(Console.ReadLine());

            } while (true);
        }

        static void createDirectory()
        {
            Console.WriteLine("Enter the path of Directory:");
            string strDirectoryName = Console.ReadLine();
            Directory.CreateDirectory(Path.GetDirectoryName(strDirectoryName));
            
        }
        static void batchDetails()
        {
            Console.WriteLine("Enter the path:");
            string strDirectoryName = Console.ReadLine();
            FileStream filestream1 = new FileStream(strDirectoryName, FileMode.CreateNew, FileAccess.Write);
            StreamWriter streamWriter = new StreamWriter(filestream1);
            StringBuilder output = new StringBuilder();

            Console.WriteLine("Please enter first name: ");
            output.Append(Console.ReadLine() + " ");
            Console.WriteLine("Please enter last name: ");
            output.Append(Console.ReadLine() + " ");
            Console.WriteLine("Please enter age: ");
            output.Append(Console.ReadLine());
            streamWriter.WriteLine(output.ToString());
            output.Clear();

            streamWriter.Close();
        }
        static void copy()
        {
            Console.WriteLine("Enter the Source path");
            string sourceDir = Console.ReadLine();
            Console.WriteLine("Enter the Destination path");
            string backupDir = Console.ReadLine();
            try
            {

                string[] txtList = Directory.GetFiles(sourceDir, "*.txt");


                // Copy text files.
                foreach (string f in txtList)
                {

                    // Remove path from the file name.
                    string fName = f.Substring(sourceDir.Length + 1);

                    try
                    {
                        // Will not overwrite if the destination file already exists.
                        File.Copy(Path.Combine(sourceDir, fName), Path.Combine(backupDir, fName));
                    }

                    // Catch exception if the file was already copied.
                    catch (IOException copyError)
                    {
                        Console.WriteLine(copyError.Message);
                    }
                }



            }

            catch (DirectoryNotFoundException dirNotFound)
            {
                Console.WriteLine(dirNotFound.Message);
            }
        }
        static void viewdetails()
        {
            Console.WriteLine("View Details");
            Console.WriteLine("Enter the path:");
            string strDirectoryName = Console.ReadLine();
            FileStream fileStream2 = new FileStream(strDirectoryName, FileMode.Open, FileAccess.Read);
            StreamReader streamReader = new StreamReader(fileStream2);
            int ch = streamReader.Read();
            while (ch > 0)
            {
                Console.Write((char)ch);
                ch = streamReader.Read();
            }
            streamReader.Read();
            streamReader.Close();
            fileStream2.Close();

            Console.ReadKey();
        }
    }
}
