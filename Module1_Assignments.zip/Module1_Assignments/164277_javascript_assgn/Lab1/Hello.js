function dispHello()
{
//TODO:return the string “Hello World“
document.write("Hello World");
}