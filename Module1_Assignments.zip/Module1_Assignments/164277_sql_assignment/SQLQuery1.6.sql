--1.6 Indexes and Views

--1. Create a Unique index on Department Name for Department master Table
select * from department_master
select * from sys.indexes where object_id =object_id('department_master');
create unique index IXDepartment on Department_master(dept_name);


--2. Try inserting the following values and observe the output
insert into department_master values(100,'HomeScience');
insert into department_master values(200,'HomeScience');
insert into department_master values(300,null);
insert into department_master values(400,null);

--3. Create a non-clustered index for Book_Trans table on the following columns 
--Boo_code, Staff_name, student name, date of issue. 
--Try adding some values.Do you experience any difficulties?
select * from book_transaction
create index ix_book_transaction on book_transaction(book_code,staff_code,student_code,book_issue_date);
insert into book_transaction values (100,45,56,getdate(),getdate(),getdate(),100);

--4. List the indexes created in the previous questions, from the sysindexes table.
select * from sys.indexes where object_id =object_id('department_master');
select * from sys.indexes where object_id =object_id('book_transaction');

--5. Create a View with the name StaffDetails_view with the following column name 
--Staff Code, Staff Name, Department Name, Desig Name salary
use Training;
select * from staff_master
create view StaffDetails_view_103  as
(select staff_master.staff_code,staff_master.staff_name,staff_master.staff_sal,department_master.Dept_Name from 
 staff_master inner join department_master on(staff_master.dept_code = department_master.dept_code));

 select * from StaffDetails_view_103

 --6. Try inserting some records in the view; Are you able to add records? Why not? Write
--your answers here.

insert into StaffDetails_view_103 values(1000,'abc',50000,'HR');
--Ans:View or function 'StaffDetails_view_103' is not updatable because the modification affects multiple base tables.

--7. Working with Filtered Index � The following Filtered Index created on
--Production.BillOfMaterials table, cover queries that return the columns defined in
--The index and that select only rows with a non-NULL value for EndDate.

USE Adventure_work
GO
CREATE NONCLUSTERED INDEX FIBillOfMaterialsWithEndDate
ON Production.BillOfMaterials (ComponentID, StartDate)
WHERE EndDate IS NOT NULL;

--8. View the definition of the view using the following syntax. Sp_helptext <viewname>
exec sp_helptext StaffDetails_view_103;


--9. Using the view , List out all the staffs who have joined in the month of June
select* from staff_master
select * from StaffDetails_view_103 sview inner join staff_master s1 
on(sview.staff_code=s1.staff_code) where datename(month,s1.Hire_date)='june'

--10. Create a non-clustered column store index on EmployeeID of Employees table
create nonclustered columnstore index emp_col_store_index123 on Employee(Employee_number)
select * from employee