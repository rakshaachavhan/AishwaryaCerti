use Training;

--2.2 Data Retrieval - Joins, Subqueries, SET Operators and DML

--1.Write a query that displays Staff Name, Salary, and Grade of all staff. Grade depends
--on the following table.
--Salary Grade
--Salary >=50000 A
--Salary >= 25000 < 50000 B
--Salary>=10000 < 25000 C

SELECT STAFF_NAME,STAFF_SAL,
	CASE 
	WHEN STAFF_SAL >=50000 THEN 'A'  
	WHEN STAFF_SAL  >25000 AND  STAFF_SAL<50000 THEN 'B' 
	WHEN STAFF_SAL  >10000 AND  STAFF_SAL<25000 THEN 'C' 
	ELSE 'D' 
	END 
	AS Grade
	FROM STAFF_MASTER;

--2.Generate a report which contains the following information.
--Staff Code, Staff Name, Designation, Department, Book Code, Book Name,
--Author, Fine
select * from book_master
select * from book_transaction
select * from staff_master
select * from desig_master

select staff_master.staff_code,staff_master.staff_name,desig_master.design_name,staff_master.dept_code,
book_master.book_code,book_master.book_name,
book_master.book_pub_year, datediff(day,book_transaction.book_expected_return_date,getdate())*5 as fine from
(book_transaction full outer join staff_master on (book_transaction.staff_code=staff_master.staff_code))
full outer join
book_master on(book_transaction.book_code=book_master.book_code)
full outer join desig_master on (staff_master.design_code = desig_master.Design_code);


--3. List out all the staffs who are reporting to the same manager to whom staff 100060 reports to.
select * from staff_master;
select * from staff_master where mgr_code=(select mgr_code from staff_master where staff_code=100060);

--4. List out all the students along with the department who reads the same books which the professors read
select * from book_transaction
select * from student_master
select book_transaction.student_code, student_master.student_name,student_master.dept_code
from book_transaction inner join student_master on(book_transaction.student_code = student_master.student_code) 
where( book_transaction.student_code is not null and book_transaction.staff_code is not null);


--5. List out all the authors who have written books on same category as written by Author David Gladstone.
select * from book_master
insert into book_master values (124 ,'Anapple',2014,'Author David Gladstone','Physics',900);
insert into book_master values (125 ,'Laws of motion',2014,'Newton','Physics',900);
select book_pub_author from book_master 
where book_category = (select book_category from book_master where book_pub_author = 'Author David Gladstone');


--6. Display the Student report Card for this year. The report Card should contain the following information.
--Student Code Student Name Department Name Total Marks Grade

select * from student_master 
select * from student_marks
select * from department_master

insert into student_marks values(101,2018,70,75,80,null),(102,2018,70,75,80,null),
(116,2018,70,75,80,null),(115,2018,70,75,80,null),(112,2018,70,75,80,null);

select student_master.student_code,department_master.dept_name,
(student_marks.subject1+student_marks.subject2+student_marks.subject3) as Total,
case 
when (((student_marks.subject1+student_marks.subject2+student_marks.subject3)/300)*100) < 60 then 'F'
when (((student_marks.subject1+student_marks.subject2+student_marks.subject3)/300)*100) > 80 then 'E'
when (((student_marks.subject1+student_marks.subject2+student_marks.subject3)/300)*100) between 70 and 80 then 'A'
when (((student_marks.subject1+student_marks.subject2+student_marks.subject3)/300)*100) between 60 and 69 then 'B'
End as Grade

 from department_master inner join (student_master inner join student_marks 
 on(student_master.student_code = student_marks.student_code)) on
  (student_master.dept_code=department_master.dept_code);
