--2.3
--1. Create a Filtered Index HumanResources.Employee table present in the
--AdventureWorks database for the column EmployeeID. The index should cover all
--the queries that uses EmployeeID for its search & that select only rows with
--�Marketing Manager� for Title column.

use AdentureWorks;

create clustered index emploueeindex_277 on Humanresources.Employee(EmployeeId)
where title='Marketing Manager';