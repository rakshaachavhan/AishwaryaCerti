use Training;

--2.1 Transact-SQL Statements
--1. List the empno, name and Department No of the employees who have got experience of more than 18 years.
select * from Employees;
sp_help Employees;
insert into Employees values(13,'Sumit','1990-01-01',60000,'A',45),(14,'Abhi','1994-01-01',60000,'A',45),(15,'Sumit','1993-01-01',60000,'A',45);
alter table Employees add exp_year int;
alter table Employees drop column exp_year;
select * from Employees
select Employee_code,Department_code from Employees where  datediff(year,Date_of_joining,getdate())>18;

--2. Display the name and salary of the staff. Salary should be represented as X. Each X
--represents a 1000 in salary. It is assumed that a staff�s salary to be multiples of 1000
-- for example a salary of 5000 is represented as XXXXX
--Sample Output
--JOHN 10000 XXXXXXXXXX
--ALLEN 12000 XXXXXXXXXXXX
select staff_name,replicate('X',(staff_sal/100)) as salary from staff_master;

--3.List out all the book code and library member codes whose return is still pending
select * from book_master;
select* from book_transaction;
select book_code,student_code,staff_code from book_transaction where book_actual_return_date is null;

--4.List all the staff�s whose birthday falls on the current month
select * from staff_master;

select staff_name,datename(month,staff_dob) from staff_master;

select * from staff_master where datename(month,staff_dob)=datename(month,MONTH(GETDATE()));

--5.How many books are stocked in the library?
select count(*) from book_master ;

--6. How many books are there for topics Physics and Chemistry?
select * from book_master;
select count(*) from book_master where book_category='physics' or book_category ='chemistry' ;

--7.How many members are expected to return their books today?
select * from book_transaction;
select count(*) from book_transaction where book_expected_return_date = getdate();

--8.Display the Highest, Lowest, Total & Average salary of all staff. Label the columns
--Maximum, Minimum, Total and Average respectively. Round the result to nearest
--whole number
select * from staff_master;
select max(staff_sal) as maxmium,min(staff_sal) as minimum,sum(staff_sal)as Total,avg(staff_sal)as Averagesal from staff_master;
select ceiling(max(staff_sal)),ceiling(min(staff_sal)),ceiling(sum(staff_sal)),ceiling(avg(staff_sal))from staff_master;


--9. How many staffs are managers�?
 select count(*) from staff_master where mgr_code is not null;

 --10. List out year wise total students passed. The report should be as given below. A
--student is considered to be passed only when he scores 60 and above in all 3
--subjects individually
select * from student_marks
select student_year as passing_year ,count(*) as no_of_stu_passed from Student_Marks 
 where (subject1>60 and subject2>60 and subject3>60 ) group by student_year;

 --11. List out all the departments which is having a headcount of more than 10
 select * from student_master;
 select * from department_master; 
 select count(*) as num_students
 from student_master inner join department_master on(student_master.dept_code = Department_master.dept_code)
 group by Department_master.Dept_name having count(student_master.student_code) > 10;

 --12. List the total cost of library inventory ( sum of prices of all books )
 select * from book_master;
 select * from book_transaction;
 select sum(bookprice) as totallib_cost from book_master;

 --13. List out category wise count of books costing more than Rs 1000 /-
 select count(*) as book from book_master group by bookprice having bookprice > 1000;


 --14. How many students have joined in Physics dept (dept code is 10) last year?
select * from student_master
select * from department_master;
select * from student_marks;
select count(*) from (student_master inner join student_marks on student_marks.student_code=student_marks.student_code)
 inner join department_master t2 on student_master.dept_code=t2.dept_code 
 where student_marks.student_year = 2017 and t2.dept_name = 'Physics';