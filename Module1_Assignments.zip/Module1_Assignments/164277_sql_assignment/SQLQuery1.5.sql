use Training;
--1.5 Data Retrieval - Joins, Subqueries, SET Operators and DML

--1. Write a query which displays Staff Name, Department Code, Department Name, and Salary for all staff who earns more than 20000.
select * from staff_master;
select * from department_master;
select staff_name,dept_name, staff_master.dept_code
from staff_master  inner join department_master on (staff_master.dept_code = department_master.Dept_Code) 
where staff_master.staff_sal>2000;


--2. Write a query to display Staff Name, Department Code, and Department Name for all staff who do not work in Department code 10
select staff_name,dept_name, staff_master.dept_code
from staff_master  inner join department_master on (staff_master.dept_code = department_master.Dept_Code)
where staff_master.dept_code <> 10;

--3. Print out a report like this
------Book Name    No of times issued
-------Let us C       12 
-----Linux Internals   9

select * from book_master;
select * from book_transaction;
select b1.book_name,count(*) as no_of_times_issued from book_master b1 inner join book_transaction b2 
on (b1.book_code = b2.book_code)  group by b1.book_name;

--4. List out number of students joined each department last year
select * from student_master;
select* from student_marks;
select * from Department_master;
select * from student_marks

select dept_name,count(*) as no_of_times_issued from student_master b1 inner join department_master b2 
on (b1.Dept_code = b2.dept_code)  group by b2.dept_name;


--5. List out a report like this Staff Code Staff Name Manager Code Manager Name
select * from staff_master;
select a.staff_code,a.staff_name,b.mgr_code,b.mgr_name
from staff_master a, staff_master b 
where a.staff_code=b.mgr_code order by staff_name,mgr_name;

--6. Display the Staff Name, Hire date and day of the week on which staff was hired.
--Label the column as DAY. Order the result by the day of the week starting with
--Monday.
select * from staff_master;
select staff_name, Hire_date, datename(dw,Hire_date) as day1 from staff_master order by (day1);


--7. Display Staff Code, Staff Name, and Department Name for those who have taken more than one book.
select staff_code, staff_name,d1.dept_name from department_master d1 inner join(
select s1.staff_code,s1.staff_name,s1.dept_code from staff_master s1 inner join 
(
select b1.book_code,b1.staff_code,count(*) as Total from staff_master s1 inner join book_transaction b1
on(s1.staff_code = b1.staff_code) group by b1.book_code,b1.staff_code having count(*) >1) as new_table
on(new_table.staff_code=s1.staff_code)) as result
on(result.dept_code=d1.dept_code);


--8.List out the names of all student code whose score in subject1 is equal to the highest score
select * from student;
select * from student_marks;
select student_name from student inner join
(
select student_code from Student_Marks where(subject1>subject2 and subject1>subject3) )as result_table
on (result_table.student_code = student.student_code);


--9. Modify the above query to display student names along with the codes.
select student_name, student.student_code from student inner join
(
select student_code from Student_Marks where(subject1>subject2 and subject1>subject3) )as result_table
on (result_table.student_code = student.student_code);

--10. List out the names of all the books along with the author name, book code and category which have not been issued at all. Try solving this question using EXISTS.
select * from department_master;
select * from student_master

select d1.dept_name from department_master d1 join
(select sp.student_code,sp.student_name,inner_table.dept_code
from student_master sp join 
(
select top(1) dept_code from student_master
group by dept_code
order by count(dept_code)desc
) as inner_table on(inner_table.dept_code=sp.dept_code)
) as new_one
on(new_one.dept_code=d1.dept_code);

--11. List out the code and names of all staff and students belonging to department 20.
select staff_code,staff_name from staff_master where dept_code=20
union
select student_code,Student_Name from student_master
where dept_code=20
union
select * from department
where department_id=20;

--12. List out all the students who have not appeared for exams this year.
select * from student_marks where student_year <> datename(year,GETDATE());

--13. List out all the student codes who have never taken books
select student_code from book_transaction where book_issue_date is null;

--14. Add the following records to the Customers Table , created in our earlier exercises
create table customer_16427(Customerid varchar(50), CustomerName varchar(100), Address1 varchar(100), 
Address2 varchar(100), ContactNumber varchar(20),Postalcode varchar(20),CustomerRegion varchar(50),gender varchar(1));

select * from customer_16427;

insert into customer_16427 values('ALFKI', 'AlfredsFutterkiste','ObereStr. 57','Berlin,Germany','030-0074321','12209', NULL,NULL),
('ANATR','Ana TrujilloEmparedados yhelados','Avda. delaConstituci�n 2222','M�xicoD.F.,Mexico','555-4729','5021', NULL,NULL);

insert into customer_16427 values
('ANTON','Antonio Moreno','Taquer�aMataderos2312','M�xicoD.F.,Mexico',5553932,5023, NULL,NULL),
('AROUT','Around the Horn', '120HanoverSq.','London,UK',1715557788,11,NULL,NULL),
('BERGS','Berglundssnabbk�p','Berguvsv�gen 8','Lule�,Sweden' ,0921123465,95822,NULL,NULL),
('BLAUS','Blauer SeeDelikatessen','Forsterstr. 57','Mannheim,Germany',062108460,68306,'NA',NUll),
('BLONP','Blondesddslp�reet fils','24,placeKl�ber','Strasbourg,France',88601531,67000, NULL,NULL),
('BOLID','B�lidoComidaspre paradas','C/Araquil,67','Madrid,Spain', 915552282,28023 ,nUll ,NULL),
('BONAP','Bon app',' 12,ruedesBouchers','Marseille,France',91244540,13008, NULL,NULL),
('BOTTM', 'Bottom-DollarMarkets','23Tsawassen Blvd.','Tsawassen,Canada',6045554729,12345,'BC',null);
truncate table customer_16427

sp_help customer_16427

--15. Replace the contact number of Customer id ANATR to (604) 3332345.
update customer_16427 set ContactNumber ='(604) 3332345' where Customerid='ANATR';

--16. Update the Address and Region of Customer BOTTM to the following
--19/2 12th Block, Spring Fields.
--Ireland - UK
--Region - EU

update customer_16427 set Address1='19/2 12th Block, Spring Fields',Address2='Ireland - UK',CustomerRegion='EU' where Customerid='BOTTM';

--17. Insert the following records in the Orders table. The Order id should be automatically generated
use Training_24Oct18_pune;
select *from orders
sp_help orders

create sequence s2 start with 1 increment by 1
insert into orders values (next value for s1,'AROUT',datefromparts(96,'jul',4),'P');

--18. Delete all the Customers whose Orders have been cleared.
--19. Remove all the records from the table using the truncate command
--20. Change the order status to C, for all orders before `15th July.