
--1.2 Getting Familiar with SQL Server
--1.Identify all the system and user defined database in your systems.
select * from sys.databases;

--2.Make master database as your current database
use Training_24Oct18_Pune

--3.Find out if your active database is master
select db_name()

--4.Find out the content of the database
sp_help

--5.Find out the version of your SQL Server
select @@version

--6.Find out the server date 
select getdate()

--7.Make Northwind as your current database
use Northwind


--8.Informationabouttables categories,Products,Orders, Order Details
sp_help categories

sp_help Products

sp_help OrderDetails

sp_help Employees


--1.3 SQL Languages � DDL- Creating Tables, Alias Data Type and Constraints
USE Training;
--1.Create a Table called Customer_<empid>
CREATE TABLE dbo.TestRethrow_164277
(
ID INT PRIMARY KEY
);
select * from dbo.TestRethrow_164277;

--2.Create a table called Employees_<empid>
create table dbo.customer_164277(
Customerid int unique not null,
CustomerName varchar(20) Not Null,
Address1 varchar(30),
Address2 varchar(30),
ContactNumber varchar(12) Not Null,
PostalCode Varchar(10));

select * from dbo.customer_164277;


--3.Create a table called Employees_<empid>
CREATE TABLE dbo.Employees164277
(
EmployeeId INT NOT NULL PRIMARY KEY,
Name NVARCHAR(255) NULL
);

select * from dbo.Employees164277;



--4.Create a table called Contractors_<empid>
CREATE TABLE dbo.Contractors_164277
(
ContractorId INT NOT NULL PRIMARY KEY,
Name NVARCHAR(255) NULL,

);

select * from dbo.Contractors_164277;


--5.Create a user defined data type called Region, which would store a character string of size 15.
Create Type Region164277 from varchar(15);

--6.Create a Default which would store the value �NA� (North America�
Create Default northAmerica164 as 'NA';

--7.bind default to alias
exec sp_bindefault northAmerica164,Region164277;

--8.Modify the table Customers to add the a column called Customer_Region whichwould be of data type: Region164277

alter table customer_164277 add Customer_Region Region164277;

select * from customer_164277;

sp_help customer_164277;


--9.Add the column to the Customer Table Gender char (1)
alter table customer_164277 add Gender char(1);
sp_help customer_164277;

--10.Using alter table statement add a constraint to the Gender column such that it would not accept any other values except �M�,�F� and �T�.
alter table customer_164277 add constraint ck_gender164277 check(Gender in('M','F','T'));
sp_help customer_164277;



--11.Create table orders_164277
create table orders_164277(
ordersId int not null identity(1000,1),
Customerid int not null,
CustomerName varchar(20) Not Null,
ordersDate datetime,
order_state char(1) constraint ck_orderstate164277 check(order_state in ('P','C')));

sp_help orders_164277;

select * from customer_164277;

--12.Add referential integrity constraint for Orders & Customer tables through Customerld with the name fk_CustOrders.
alter table customer_164277 add constraint pk_primarykey164277 primary key(Customerid);
alter table orders_164277 add constraint pk_primarykey1642 primary key(Customerid);
alter table orders_164277 add constraint fk_foreginkey164277 foreign key(Customerid) references customer_164277(customerid);
sp_help orders_164277;


--13.Creating Sequence Numbers
--Task1 Create Sequence
CREATE SEQUENCE IdSequence_164277 AS INT
START WITH 10000
INCREMENT BY 1;

--Task2 Using the Sequence to Insert New Rows
INSERT INTO Employees164277 (EmployeeId, Name) VALUES (NEXT VALUE FOR IdSequence_164277, 'Shashank');
INSERT INTO Contractors_164277 (ContractorId, Name) VALUES (NEXT VALUE FOR IdSequence_164277, 'Aditya');
SELECT * FROM Employees164277;
SELECT * FROM Contractors_164277;

