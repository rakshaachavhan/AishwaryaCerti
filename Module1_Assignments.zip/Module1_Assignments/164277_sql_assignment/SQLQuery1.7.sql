use training;

--1. Write a procedure that accept Staff_Code and updates the salary and store the old
--salary details in Staff_Master_Back (Staff_Master_Back has the same structure
--without any constraint) table. The procedure should return the updated salary as the
--return value
--Exp< 2 then no Update
--Exp>= 2 and <= 5 then 20% of salary
--Exp> 5 then 25% of salary

select * from staff_master;

create procedure staff_prod
(
@exp int,
@staff_sal int out
)
as 
begin
	if(@exp<2)
	begin
		print 'no update';
	end
	else
	begin
		if(@exp>=2 and @exp<=5)
		begin
		update employees set salary =(select Staff_sal from staff_master where employees.employee_code = staff_master.staff_code);
		update staff_master set staff_sal=(select staff_sal from staff_master where Staff_sal=@Staff_sal*0.2);
		end
		else
		if(@exp>5)
		begin
		update employees set salary =(select Staff_sal from staff_master where employees.employee_code = staff_master.staff_code);
		update staff_master set staff_sal=(select staff_sal from staff_master where staff_sal = staff_sal*0.2);
		end
	end
	return  @staff_sal;
end

declare @sal int
exec staff_prod 1, @sal out


--2.Write a procedure to insert details into Book_Transaction table. Procedure should
--accept the book code and staff/student code. Date of issue is current date and the
--expected return date should be 10 days from the current date. If the expected return
--date falls on Saturday or Sunday, then it should be the next working day. Suitable
--exceptions should be handled.

select * from book_transaction

create procedure book_prod
(
@bkcode int
)
as
begin
	if exists(select book_code from book_transaction where book_code = @bkcode)
	begin
		Raiserror('not available',1,1);
	end
	begin try
	begin
		insert into book_transaction(book_issue_date,book_expected_return_date)
		values(getdate(),(datename(d,getdate()))+10)
	end
	begin
	update book_transaction set book_expected_return_date=(datename(dd,getdate())+12)
	where datename(dw,book_expected_return_date)='saturday'
	end
	begin
	update book_transaction set book_expected_return_date=(datename(dd,getdate())+11)
	where datename(dw,book_expected_return_date)='sunday'
	end
	end try
	begin catch
	throw
	end catch
end

exec book_prod 354


--3.Modify question 1 and display the results by specifying With result sets
select * from staff_master

create procedure staff_prod1
(
@exp int
)
as 
select s.staff_code,s.staff_sal from staff_master s
begin
	if(@exp<2)
	begin
		print 'no update';
	end
	else
	begin
		if(@exp>=2 and @exp<=5)
		begin
		update employees set salary =(select Staff_sal from staff_master where employees.employee_code = staff_master.staff_code);
		update staff_master set staff_sal=(select staff_sal from staff_master where Staff_sal=Staff_sal*0.2);
		end
		else
		if(@exp>5)
		begin
		update employees set salary =(select Staff_sal from staff_master where employees.employee_code = staff_master.staff_code);
		update staff_master set staff_sal=(select staff_sal from staff_master where staff_sal = staff_sal*0.2);
		end
	end
	return select Staff_sal from satff_master;
end

exec staff_prod1 23
with result sets
(
(staff_code int not null,
staff_sal int not null)
)


--4. Create a procedure that accepts the book code as parameter from the user. Display
--the details of the students/staff that have borrowed that book and has not returned
--the same.
select * from book_transaction

create procedure book_details_display
(
@book_code int
)
as
begin
	select * from  staff_master full join book_transaction on( staff_master.staff_code=book_transaction.staff_code)
	where ((book_transaction.book_actual_return_date is null) and book_transaction.book_code=@book_code)
end

exec book_details_display 202


--5. Write a procedure to update the marks details in the Student_marks table. The following is the logic.
--� The procedure should accept student code , and marks as input parameter
--� Year should be the current year.
--� Student code cannot be null, but marks can be null.
--� Student code should exist in the student master.
--� The entering record should be unique ,i.e. no previous record should exist
--� Suitable exceptions should be raised and procedure should return -1.
--� IF the data is correct, it should be added in the Student marks table and a
--success value of 0 should be returned.

create procedure student_update
(
@code int,
@marks int
)
as
begin
	alter table student_marks add constraint const_update unique(student_code,toatl_marks)
	begin try
		--if(@code=student_code or @marks=toatl_marks)
		if exists ( select student_code from student_marks where student_code=@code)
		begin
			Raiserror('student code available',1,1)
		end
		else
		begin
			update student_marks set toatl_marks = @marks where student_year = datename(yyyy,getdate())
		return 2
		end
	end try
	begin catch
		return 1
	end catch
end

exec student_update 1100,658
select * from student_marks
