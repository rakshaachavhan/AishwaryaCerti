use Training;
--1.4 Simple Queries & Merge Statement

--1.List out Student_Code, Student_Name and Department_Code of every Student
select * from students;
select Student_code,Student_name,department_code from Students;


--2.Do the same for all the staff�s
select staff_code,staff_name,department_code from staff;


--3. Retrieve the details (Name, Salary and dept code) of the employees who are working in department 20, 40 
select Employee_Name,salary,Department_code from Employees 
where (Department_code=20 or Department_code=30 or Department_code=40);


--4.Display Student_Code, Subjects and Total_Marks for every student. Total_Marks will
--calculate as Subject1 + Subject2 + Subject3 from Student_Marks. The records
--should be displayed in the descending order of Total Score
select student_code,subject1,subject2,subject3, subject1+subject2+subject3 as TotalScore from Student_Marks;



--5.List out all the books which starts with �An�, along with price
Select Book_Name, BookPrice from Book_Master where Book_Name like 'An%';



--6.List out all the department codes in which students have joined this year
select * from Student_Marks;

select * from Student_Master;

select Dept_Code from  Student_Marks inner join Student_Master 
on Student_Marks.Student_code = Student_Master.Student_Code and Student_Marks.Student_year=2018;



--7.Display name and date of birth of students where date of birth must be displayed in
--the format similar to �January, 12 1981� for those who were born on Saturday or
--Sunday. 
select * from student
select Student_Name,DATENAME(Month,student_dob)+','+format(student_dob,'dd yyyy') as dob_of_student from 
Student where (datename(dw,student_dob)='Saturday' or  (datename(dw,student_dob)='Sunday'));



--8.List out a report like this StaffCode StaffName Dept Code Date of Joining No of years in the Company
select* from staff
select staff_code,staff_name,department_code,dateOfJoining from staff;



--9.List out all staffs who have joined before Jan 2000
select * from staff where DateofJoining < '2000-01-01';



--10.Write a query which will display Student_Name, Departmnet_Code and DOB of all
--students who born between January 1, 1981 and March 31, 1983.
select * from student;
select student_name ,department_code, student_dob from student where student_dob between '1981-01-10' and '1983-03-31'; 

--11.List out all student codes who did not appear in the exam subject2
select * from student_marks;
select student_code from Student_Marks where subject2 is null;



--Working with Merge
CREATE TABLE Products_164277
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
);

CREATE TABLE UpdatedProducts_164277
(
ProductID INT PRIMARY KEY,
ProductName VARCHAR(100),
Rate MONEY
);

INSERT INTO Products_164277 VALUES(1,'Tea', 10.00),(2, 'Coffee', 20.00),(3, 'Muffin', 30.00),(4, 'Biscuit', 40.00);

INSERT INTO UpdatedProducts_164277 VALUES (1, 'Tea', 10.00), (2, 'Coffee', 25.00), (3, 'Muffin', 35.00),(5, 'Pizza', 60.00);

MERGE Products_164277 AS TARGET
USING UpdatedProducts_164277 AS SOURCE
ON (TARGET.ProductID = SOURCE.ProductID) 
WHEN MATCHED AND TARGET.ProductName <> SOURCE.ProductName
OR TARGET.Rate <> SOURCE.Rate THEN
UPDATE SET TARGET.ProductName = SOURCE.ProductName,
TARGET.Rate = SOURCE.Rate
WHEN NOT MATCHED BY TARGET THEN
INSERT (ProductID, ProductName, Rate)
VALUES (SOURCE.ProductID, SOURCE.ProductName, SOURCE.Rate)
WHEN NOT MATCHED BY SOURCE THEN
DELETE
OUTPUT $action,
DELETED.ProductID AS TargetProductID,
DELETED.ProductName AS TargetProductName,
DELETED.Rate AS TargetRate,
INSERTED.ProductID AS SourceProductID,
INSERTED.ProductName AS SourceProductName,
INSERTED.Rate AS SourceRate;
SELECT @@ROWCOUNT;

select * from Products_164277;

Select * from UpdatedProducts_164277;

insert into Products_164277 values(8,'juice', 10.00),(9,'Coke', 12.00);
INSERT INTO UpdatedProducts_164277 VALUES (8, 'juice', 20.00), (9, 'Coke', 50.00), (11, 'Burger', 75.00);




--Working with merge 2
CREATE TABLE EmployeeTarget_164277
(
EmpID INT NOT NULL,
Designation VARCHAR (25) NOT NULL,
Phone VARCHAR (20) NOT NULL,
Address VARCHAR (50) NOT NULL,
CONSTRAINT PK_EmployeeTG_164277
PRIMARY KEY (EmpID)
);

CREATE TABLE EmployeeSource_164277
(
EmpID INT NOT NULL,
Designation VARCHAR (25) NOT NULL,
Phone VARCHAR (20) NOT NULL,
Address VARCHAR (50) NOT NULL,
CONSTRAINT PK_EmployeeSC_164277
PRIMARY KEY (EmpID)
);

insert into EmployeeTarget_164277 values(102,'Analyst','4545454','pqrstuv');
select * from EmployeeTarget_164277;

insert into EmployeeSource_164277 values(101,'Analyst','822908','talwade');
insert into EmployeeSource_164277 values(102,'Senoir Consultant','9999','hingewadi');
insert into EmployeeSource_164277 values(103,'Senoir Consultant','9999008','hingewadi');
select * from EmployeeSource_164277;

MERGE EmployeeTarget_164277 AS TARGET
USING EmployeeSource_164277 AS SOURCE
ON (TARGET.EmpId = SOURCE.EmpID) 
WHEN MATCHED AND TARGET.Designation <> SOURCE.Designation
OR TARGET.Phone <> SOURCE.Phone  OR  TARGET.Address <> SOURCE.Address 
THEN
UPDATE SET TARGET.Designation = SOURCE.Designation,
TARGET.Phone = SOURCE.Phone,TARGET.Address = SOURCE.Address
WHEN NOT MATCHED BY TARGET THEN
INSERT (EmpId, Designation,Phone,Address)
VALUES (SOURCE.EmpId, SOURCE.Designation, SOURCE.Phone,Source.Address)
WHEN NOT MATCHED BY SOURCE THEN
DELETE
OUTPUT $action,
DELETED.EmpId AS TargetEmpId,
DELETED.Designation AS TargetDesignation,
DELETED.Phone AS TargetPhone,
DELETED.Address AS TargetAddress,
INSERTED.EmpID AS SourceEmpId,
INSERTED.Designation AS SourceDesignation,
INSERTED.Phone AS SourcePhone,
INSERTED.Address AS SourceAddress;
SELECT @@ROWCOUNT;


---Working with group sets
CREATE TABLE Employee_164277
(
Employee_Number INT NOT NULL PRIMARY
KEY,
Employee_Name VARCHAR(30) NULL,
Salary FLOAT NULL,
Department_Number INT NULL,
Region VARCHAR(30) NULL
);

insert into Employee_164277 values(100,'ABC',50000.0,30,'Talawade'),(101,'PQR',50000.0,40,'Talawade'),(102,'XYZ',50000.0,30,'Hingewadi'),
(103,'LMN',50000.0,30,'Hingewadi'),(104,'IJK',50000.0,40,'Talawade'),(105,'EFG',50000.0,40,'Talawade');
select * from Employee_164277;

SELECT Region, Department_Number, AVG (Salary) Average_Salary From Employee_164277 Group BY GROUPING SETS ( (Region, Department_Number), (Region), (Department_Number));

