﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LayeredDemo.Exceptions
{
    public class UDException : ApplicationException
    {
        public UDException() : base()
        {

        }

        public UDException(string message) : base(message)
        {

        }

        public UDException(string message, Exception objEx) : base(message, objEx)
        {

        }

    }
}
