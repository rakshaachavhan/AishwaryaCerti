﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LayeredDemo.Entity;
using LayeredDemo.Exceptions;
using System.Data.SqlClient;
namespace LayeredDemo.DataAccessLayer
{
    public class ProductDAL
    {

    }
}
