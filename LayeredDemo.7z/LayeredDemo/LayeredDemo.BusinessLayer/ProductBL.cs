﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LayeredDemo.DataAccessLayer;
using LayeredDemo.Entity;
using LayeredDemo.Exceptions;

namespace LayeredDemo.BusinessLayer
{
    public class ProductBL
    {

    }
}
