﻿using System;

namespace LayeredDemo.Entities
{
    public class Class1
    {
    }
}
