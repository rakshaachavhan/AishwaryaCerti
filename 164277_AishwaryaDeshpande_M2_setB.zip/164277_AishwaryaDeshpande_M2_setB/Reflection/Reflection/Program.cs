﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersonInfo;
using System.Reflection;


namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            Type t = typeof(Person); // To pass the type of Person class
            Console.WriteLine("The {0} type has the following properties: ", t.Name); 
            foreach (var prop in t.GetProperties())
                Console.WriteLine("   {0} ({1})", prop.Name,prop.PropertyType.Name); // to get display Property Info of Person Class

            Console.ReadKey();
        }
    }
}
