﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Question2
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string path;
                Console.WriteLine("Enter file Path"); //to get the location of file from user
                path = Console.ReadLine();
                if (path != string.Empty)
                {


                    FileInfo fileObj = new FileInfo(path); //passing path to file object
                    if (fileObj.Exists)
                    {
                        Console.WriteLine("File Name = {0}", fileObj.Name);  //to get file name
                        Console.WriteLine("File length in Bytes = {0}", fileObj.Length); //to get length of file
                        Console.WriteLine("File Extension = {0}", fileObj.Extension);
                        Console.WriteLine("File Full path = {0}", fileObj.FullName); // to get full path of file
                        Console.WriteLine("File Directory = {0}", fileObj.Directory); //to get directory
                        Console.WriteLine("File Parent Directory = {0}", fileObj.Directory); //to get parent directoy
                        Console.WriteLine("File Creation Date and Time = {0}", fileObj.CreationTime.ToString("dd-MM-yyyy hh:mm:ss tt")); //creation tim
                        Console.WriteLine("File Modified Date and Time = {0}", fileObj.LastWriteTime.ToString("dd-MM-yyyy hh:mm:ss tt")); //write time
                        Console.WriteLine("File Last Access Date and Time = {0}", fileObj.LastAccessTime.ToString("dd-MM-yyyy hh:mm:ss tt")); //access time
                        Console.WriteLine("File Attributes = {0}", fileObj.Attributes.ToString()); //attributes
                    }
                    else
                    {
                        Console.WriteLine("File does not Exists");
                    }
                }
                else
                {
                    Console.WriteLine("Please provide file info");
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
