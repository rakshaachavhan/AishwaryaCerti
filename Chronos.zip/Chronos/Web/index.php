<?php
/*! @file
 * @brief トップ画面
 */

require_once './models/app.php';

init(basename(__FILE__));

$regionID  = getRegionIDFromSetting(); //!< @brief リージョンID
$headerUri = $regionID ? 'sub/patient.php' : 'sub/region.php'; //!< @brief 遷移先

header('Location: ' . $headerUri);
exit;
