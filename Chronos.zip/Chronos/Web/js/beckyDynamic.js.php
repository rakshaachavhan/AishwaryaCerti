<?php
/*! @file
 * @brief 動的生成に JavaScript を生成する
 */

// とても意外な事に JavaScript では端末の IP アドレスを調べる事ができない
$clientIpAddress = $_SERVER['REMOTE_ADDR'];

// サーバーの起動日時
$uptime_s = getenv('UPTIME_S');
if (empty($uptime_s)) {
	// とりあえず適当に設定
	$uptime_s = "2012-05-15 00:57:24";
}

header("Content-type: application/x-javascript");

// 原則、ヒアドキュメントは使用しない事になっているが、
// PHP で動的生成する JavaScript という特殊な場面であり、
// ヒアドキュメントを使った方がコードが見易いため使用している。
echo <<<OUTPUT_DYNAMIC_JAVASCRIPT
/*! @file
 * @brief 動的生成 JavaScript
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.dynamic = becky.dynamic || {};

/*!
 * @brief 端末の IP アドレスを得る
 *
 * @return string 端末の IP アドレス
 */
becky.dynamic.getClientIpAddress = function()
{
	return "{$clientIpAddress}";
}

/*!
 * @brief サーバーの起動日時
 * uptime -s と同じ内容
 *
 * @return string サーバーの起動日時(yyyy-mm-dd hh:mm:ss)
 */
becky.dynamic.getUptime_s = function()
{
	return "{$uptime_s}";
}
OUTPUT_DYNAMIC_JAVASCRIPT;
