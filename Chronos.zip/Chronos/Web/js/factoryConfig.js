/*! @file
 * @brief 工場設定で使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

/*!
 * @brief ディオプターシフトのフォーマットとして正しいか？
 *
 * @param[in] string aDiopterShift 対象
 * @retval true 正しい
 * @retval false 正しくない
 */
function _isDiopterShiftFormat(aDiopterShift)
{
	if (becky.assertion.isNullOrEmpty(aDiopterShift)) {
		return false;
	}
	const trimdDiopterShift = aDiopterShift.trim();
	const pattern = /^[+,-]?([1-9]\d*|0)(\.\d+)?$/;
	return pattern.test(trimdDiopterShift);
}

$(document).ready(function(){
	// スタイル適用前の画面を見せたくない
	$("body").fadeIn();

	//$("select").selectmenu(); 標準のコントロールを使用する
	$("button").button();
	$("input[type='radio']").checkboxradio({
		icon: false
	});
	//$("input[type='tel']").spinner();
	//
	//$("input[name='date']").datepicker();

	// ディオプターシフト
	const $inputDiopterShift = $("input[name='diopterShift']");
	$inputDiopterShift.attr("autocomplete", "on");
	$inputDiopterShift.attr("list", "listDiopterShift");

	// 模型眼アライメントモード
	// 設定ファイルには保存していないため、WebStorage から取得
	const $inputModelEyeAlignmentMode = $("input[name='modelEyeAlignmentMode']");
	$inputModelEyeAlignmentMode.prop("checked",
		becky.WebStorage.modelEyeAlignmentMode.getValue());

	// 戻る
	$("#goBack").click(function(){
		location.href = "../index.php";
	});

	const $factoryConfig_form = $("#factoryConfig_form");
	if (becky.assertion.isNullOrEmpty($factoryConfig_form)) {
		return;
	}
	// 送信前の処理
	$("#register").click(function(){
		// 不正フィールド変更イベント定義する。
		const funcRegistEventInvalidField = () => {
			const funcRemoveClass = target => {
				const $invalid_field = $(target);
				$invalid_field.removeClass("invalidField");
			};
			$("input.invalidField").keypress(event => {
				funcRemoveClass(event.target);
			}).keyup(event => {
				// BackSpace, Delete
				if ( 8 !== event.keyCode &&
				    46 !== event.keyCode) {
					return;
				}
				funcRemoveClass(event.target);
			});
		};
		let isCancel = false;
		{	// 必須項目のチェック
			if (!modelHelper.isNullOrEmpty($inputDiopterShift)) {
				$inputDiopterShift.each((i, element) => {
					const $required_field = $(element);
					if (modelHelper.isNullOrEmpty($required_field.val())) {
						$required_field.addClass("invalidField");
						isCancel = true;
					}
				});
				// 不正フィールド変更イベントを登録する。
				funcRegistEventInvalidField();
			}
		}
		{	// ディオプターシフトのフォーマットチェック
			if (!modelHelper.isNullOrEmpty($inputDiopterShift)) {
				$inputDiopterShift.each((i, element) => {
					const $field = $(element);
					const val = $field.val();
					if (modelHelper.isNullOrEmpty(val)) {
						return;
					}
					if (!_isDiopterShiftFormat(val)) {
						$field.addClass("invalidField");
						isCancel = true;
					}
				});
				// 不正フィールド変更イベントを登録する。
				funcRegistEventInvalidField();
			}
		}
		if (isCancel) {
			// 送信をキャンセルする
			return;
		}
		// 模型眼アライメントモード
		// 設定ファイルには保存せずに WebStorage に保存
		becky.WebStorage.modelEyeAlignmentMode.setValue(
			$inputModelEyeAlignmentMode.prop("checked"));
		// 登録という事を識別する為の情報
		$("<input/>").attr({
			type : "hidden",
			name : "factoryConfig_register",
			value: "Register"
		}).appendTo($factoryConfig_form);
		$factoryConfig_form.submit();
	});
});

}());//即時関数の終端
