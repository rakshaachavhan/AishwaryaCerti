/*! @file
 * @brief モデルのヘルパー関数郡
 */
"use strict";

// 名前空間
var modelHelper = modelHelper || {};

/*!
 * @brief Objectかどうか判定
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
modelHelper.isObject = function(aObj)
{
	return !(aObj instanceof Array) && aObj instanceof Object;
}

/*!
 * @brief 論理型かどうか判定
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
modelHelper.isBoolean = function(aObj)
{
	return "boolean" === typeof aObj;
}

/*!
 * @brief 文字列かどうか判定
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
modelHelper.isString = function(aObj)
{
	return "string" === typeof aObj ||
	       aObj instanceof String;
}

/*!
 * @brief 無効か判定
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
modelHelper.isNull = function(aObj)
{
	return null === aObj;
}

/*!
 * @brief 無効もしくは要素が空か判定
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
modelHelper.isNullOrEmpty = function(aObj)
{
	if (null == aObj || 0 === aObj.length) {
		return true;
	}
	if (modelHelper.isObject(aObj)) {
		return 0 === Object.keys(aObj).length;
	}
	return false;
}

/*!
 * @brief undefined を得る
 *
 * @return undefined
 */
modelHelper.getUndefined = function()
{
	return void 0;
}

/*!
 * @brief undefined か判定
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
modelHelper.isUndefined = function(aObj)
{
	return modelHelper.getUndefined() === aObj;
}

/*!
 * @brief undefined を含んでいるか判定
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
modelHelper.hasUndefined = function(aObj)
{
	if (modelHelper.isNullOrEmpty(aObj)) {
		return false;
	}

	let filteredObj = null;
	if (Array.isArray(aObj)) {
		filteredObj = aObj.filter(function(_item){
			return modelHelper.isUndefined(_item);
		});
	} else {
		filteredObj = Object.getOwnPropertyNames(aObj).filter(function(_item){
			return modelHelper.isUndefined(this[_item]);
		}, aObj);
	}
	return 0 < filteredObj.length;
}

/*!
 * @brief 論理型に変換
 *
 * @param[in] object aValue 変換元
 * @return bool 変換結果
 */
modelHelper.toBoolean = function(aValue)
{
	if (becky.assertion.isUndefined(aValue) ||
	    becky.assertion.isUndefined(aValue.toString)) {
		return false;
	}
	const strValue = aValue.toString().toLowerCase();
	switch (strValue) {
		case "":
		case "0":
		case "false":
			return false;
		case "1":
		case "true":
			return true;
		default:
			becky.assertion.failure("modelHelper.toBoolean not define " + strValue);
			return true;
	}
}

/*!
 * @brief 配列の最後の要素を得る
 * pop と違い非破壊
 * 
 * @param[in] array aValues 取得元の配列
 * @return array 配列の最後の要素(要素が無い場合は null)
 */
modelHelper.getLast = function(aValues)
{
	if (becky.assertion.isNullOrEmpty(aValues)) {
		return null;
	}
	return aValues[aValues.length - 1];
}

/*!
 * @brief 実数値を四捨五入する
 *
 * @param[in] numeric aNumber 対象の値
 * @param[in] numeric aSignificance 丸め込む単位
 *
 * @return double 丸め込んだ値
 */
modelHelper.fround = function(aNumber, aSignificance)
{
	const halfSignificance = aSignificance / 2;
	const mod = Math.abs(aNumber) % aSignificance;

	let isRoundUp = halfSignificance > mod;
	if (0 < aNumber) {
		isRoundUp = !isRoundUp;
	}

	if (isRoundUp) {
		return Math.ceil(aNumber / aSignificance) * aSignificance;
	} else {
		return Math.floor(aNumber / aSignificance) * aSignificance;
	}
}

/*!
 * @brief 実数値を五捨六入する
 * 銀行家の丸め
 *
 * @param[in] numeric aNumber 対象の値
 * @param[in] numeric aSignificance 丸め込む単位
 *
 * @return double 丸め込んだ値
 */
modelHelper.fbankersRound = function(aNumber, aSignificance)
{
	const halfSignificance = aSignificance / 2;
	const mod = Math.abs(aNumber) % aSignificance;

	let isRoundUp = halfSignificance >= mod;
	if (0 < aNumber) {
		isRoundUp = !isRoundUp;
	}

	if (isRoundUp) {
		return Math.ceil(aNumber / aSignificance) * aSignificance;
	} else {
		return Math.floor(aNumber / aSignificance) * aSignificance;
	}
}

/*!
 * @brief Undefined の例外をキャッチする
 *
 * @param[in] object aEx 例外
 * @return void
 */
modelHelper.catchExceptionByUndefined = function(aEx)
{
	if (!(aEx instanceof TypeError)) {
		throw aEx;
	}
	if (becky.assertion.isUndefined(aEx.message)) {
		throw aEx;
	}
	const mes = aEx.message;
	if (0 > mes.toLowerCase().indexOf("undefined")) {
		throw aEx;
	}
	becky.assertion.failure(mes);
}
