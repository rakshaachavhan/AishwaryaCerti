/*! @file
 * @brief becky の Web Storage ヘルパー
 * 基本は HTML5 の Web Storage のラッパー
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.WebStorage = becky.WebStorage || {};

// ローカルストレージ(端末毎に永続化される)
becky.WebStorage.local = becky.WebStorage.local || {};

/*!
 * @brief ローカルストレージを得る
 *
 * @return Storage ローカルストレージ
 */
becky.WebStorage.local.getStorage = function()
{
	try {
		return localStorage;
	} catch (/*SecurityError*/ e) {
		becky.assertion.failure(e);
		return null;
	}
}

/*!
 * @brief ローカルストレージから文字列を得る
 *
 * @param[in] string aKeyName キー
 * @return string 値
 */
becky.WebStorage.local.getString = function(aKeyName)
{
	if (becky.assertion.isNullOrEmpty(aKeyName)) {
		return null;
	}
	const myStorage = becky.WebStorage.local.getStorage();
	if (becky.assertion.isNull(myStorage)) {
		return null;
	}
	return myStorage.getItem(aKeyName);
}

/*!
 * @brief ローカルストレージに文字列を設定
 *
 * @param[in] string aKeyName キー
 * @param[in] string aKeyValue 値
 * @return void
 */
becky.WebStorage.local.setString = function(aKeyName, aKeyValue)
{
	if (becky.assertion.isNullOrEmpty(aKeyName)) {
		return;
	}
	const myStorage = becky.WebStorage.local.getStorage();
	if (becky.assertion.isNull(myStorage)) {
		return;
	}
	try {
		myStorage.setItem(aKeyName, aKeyValue);
	} catch (e) {
		// ストレージが満杯だったり、プライベートモードだったり
		becky.assertion.failure(e);
	}
}

/*!
 * @brief ローカルストレージから Json を得る
 *
 * @param[in] string aKeyName キー
 * @return array Json データ
 */
becky.WebStorage.local.getJson = function(aKeyName)
{
	if (becky.assertion.isNullOrEmpty(aKeyName)) {
		return null;
	}
	const value = becky.WebStorage.local.getString(aKeyName);
	if (modelHelper.isNullOrEmpty(value)) {
		return null;
	}
	return JSON.parse(value);
}

/*!
 * @brief ローカルストレージに Json を設定
 *
 * @param[in] string aKeyName キー
 * @param[in] array aJson Json データ
 * @return void
 */
becky.WebStorage.local.setJson = function(aKeyName, aJson)
{
	if (becky.assertion.isNullOrEmpty(aKeyName)) {
		return;
	}
	if (becky.assertion.isNullOrEmpty(aJson)) {
		return;
	}
	const value = JSON.stringify(aJson);
	becky.WebStorage.local.setString(aKeyName, value);
}

/*!
 * @brief ローカルストレージのキーを削除
 *
 * @param[in] string aKeyName キー
 * @return void
 */
becky.WebStorage.local.removeItem = function(aKeyName)
{
	if (becky.assertion.isNullOrEmpty(aKeyName)) {
		return;
	}
	const myStorage = becky.WebStorage.local.getStorage();
	if (becky.assertion.isNull(myStorage)) {
		return;
	}
	myStorage.removeItem(aKeyName);
}

// becky.WebStorage.local.clear は用意しない
