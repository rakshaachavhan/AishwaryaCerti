/*! @file
 * @brief ナビゲーションメニューで使用するスクリプト
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.navi = becky.navi || {};

// 即時関数を使って閉じ込める
(function(){
"use strict";

$(document).ready(function(){
	const $labelClockDate = $("#clock-date");
	const $labelClockTime = $("#clock-time");

	const hasDate = !modelHelper.isNullOrEmpty($labelClockDate);
	const hasTime = !modelHelper.isNullOrEmpty($labelClockTime);

	/*!
	 * @brief ナビゲーション部の日付時間を更新する
	 */
	function _updateNaviDateTime()
	{
		const date = new Date();
		if (hasDate) {
			const strDate = viewHelper.getStrDate(date, "/");
			$labelClockDate.html(strDate);
		}
		if (hasTime) {
			let strTime = viewHelper.getStrTime(date, ":");
			strTime = strTime.slice(0, -3); // 秒を削除
			$labelClockTime.html(strTime);
		}
	}

	if (hasDate || hasTime) {
		_updateNaviDateTime();
		asyncHelper.interval(1000, _updateNaviDateTime);
	}

	// ページ遷移時にフェードイン/アウト
	const $siteframeBodyFooter = $(".siteframe .siteframe-body, .siteframe .siteframe-footer");
	$("#btnNaviNext").click(function(){
		$(this).fadeOut();
		$siteframeBodyFooter.fadeOut();
	});
	$siteframeBodyFooter.fadeIn();
});

}());//即時関数の終端

/*!
 * @brief 次への遷移を表示する
 *
 * @return void
 */
becky.navi.showNext = function()
{
	$("#btnNaviNext").fadeIn();
}

/*!
 * @brief 次へのタッチイベントを無効化する
 * 
 * @return void
 */
becky.navi.disableNext = function()
{
	$("#btnNaviNext").css("pointer-events", "none");
}