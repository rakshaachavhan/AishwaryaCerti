/*! @file
 * @brief ライブ像に関係するスクリプト
 *
 * 依存するもの
 * - modelHelper.js
 * - viewhelper.js
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.liveImage = becky.liveImage || {};

becky.liveImage.isConnectionClosed = false; //!< @brief 接続が閉じられたか

/*!
 * @brief ライブ像の接続を維持する
 *
 * @param[in] Event aEvent WebSocket の Event
 */
becky.liveImage.keepConnection = function(aEvent)
{
	if (becky.assertion.isNullOrEmpty(aEvent) ||
	    becky.assertion.isUndefined(aEvent.type)) {
		return;
	}
	switch (aEvent.type) {
		case "open":
			if (!becky.liveImage.isConnectionClosed) {
				break;
			}
			// ライブ像の転送が切れている可能性があるので再取得する
			$("img.eye-img").each((i, element) => {
				viewHelper.reloadImg($(element));
			});
			becky.liveImage.isConnectionClosed = false;
			break;
		case "close":
			becky.liveImage.isConnectionClosed = true;
			break;
		default:
			break;
	}
}
