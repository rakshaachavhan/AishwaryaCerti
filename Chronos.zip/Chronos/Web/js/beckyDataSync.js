/*! @file
 * @brief "data-*" 属性向けのユーティリティ
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.dataSync = becky.dataSync || {};

/*!
 * 属性の変更イベントを呼ぶ
 *
 * @param[in] Node aNode 対象のノード
 * @param[in] string aAttrName 属性名
 */
becky.dataSync.callChangeEventAttr = function(aNode, aAttrName)
{
	if (becky.assertion.isFalse(aNode instanceof Node) ||
	    becky.assertion.isNullOrEmpty(aAttrName)) {
		return;
	}

	// Todo.変更イベントを発生させるために、いったん属性を削除して復元している。
	// もっとシンプルにイベントを呼ぶ方法は無いだろうか……
	const dataValue = aNode.getAttribute(aAttrName);
	if (modelHelper.isNullOrEmpty(dataValue)) {
		return;
	}

	aNode.removeAttribute(aAttrName);
	aNode.setAttribute(aAttrName, dataValue);
}

/*!
 * @brief data-text, data-html などの属性を持つ要素の text を更新する
 * MutationObserver から呼ばれる
 *
 * @param[in] array aRecords MutationRecord の配列
 * @param[in] MutationObserver aObserver インスタンス自身
 */
becky.dataSync.onUpdateContent = function(aRecords/*, aObserver*/)
{
	if (becky.assertion.isNullOrEmpty(aRecords)) {
		return;
	}

	aRecords.forEach(record => {
		const dataset = record.target.dataset;
		const isText = !modelHelper.isUndefined(dataset.text); // data-text
		const isHtml = !modelHelper.isUndefined(dataset.html); // data-html
		if (becky.assertion.isFalse(isText || isHtml)) {
			// どちらか片方はあるはず
			return;
		}
		// どちらも指定されている場合 text を優先する
		const content = isText ? dataset.text : dataset.html;
		let contentStr = content;
		if (!modelHelper.isNullOrEmpty(contentStr)) {
			let contentFloat = parseFloat(content);

			if (!isNaN(contentFloat)) {
				// 実数に変換できた場合
				const fround        = dataset.fround;        // data-fround
				const fbankersRound = dataset.fbankersRound; // data-fbankers-round
				       if (!modelHelper.isNullOrEmpty(fround)) {
					// 実数値を四捨五入
					contentFloat = modelHelper.fround(contentFloat, fround);
					contentStr   = contentFloat.toString();
				} else if (!modelHelper.isNullOrEmpty(fbankersRound)) {
					// 実数値を五捨六入
					contentFloat = modelHelper.fbankersRound(contentFloat, fbankersRound);
					contentStr   = contentFloat.toString();
				}

				// 小数点以下の桁数
				const fixed = dataset.fixed; // data-fixed
				if (!modelHelper.isNullOrEmpty(fixed)) {
					contentStr   = contentFloat.toFixed(fixed);
					contentFloat = parseFloat(contentStr);
				}

				// 正の値に符号を付加する
				const classPlus = dataset.classPlus; // data-class-plus
				if (!modelHelper.isNullOrEmpty(classPlus)) {
					if (0.0 < contentFloat) {
						contentStr = "+" + contentStr;
					}
				}
			}

			// 先頭に付加するもの
			const prefix = dataset.prefix; // data-prefix
			if (!modelHelper.isNullOrEmpty(prefix)) {
				contentStr = prefix + contentStr;
			}

			// 末尾に追加するもの
			const suffix = dataset.suffix; // data-suffix
			if (!modelHelper.isNullOrEmpty(suffix)) {
				contentStr += suffix;
			}
		}

		// 出力
		if (isText) {
			record.target.textContent = contentStr;
		} else {
			record.target.innerHTML = contentStr;
		}
	});
}

/*!
 * @brief 変更イベントを作成する
 *
 * @return MutationObserver 生成した MutationObserver オブジェクト
 */
becky.dataSync.createChangeEvent = function()
{
	// 監視する属性郡
	const customDataNames = [
		"data-text",
		"data-html",
		"data-fround",
		"data-fbankers-round",
		"data-fixed",
		"data-prefix",
		"data-suffix",
	//	"data-class-plus", これを動的に変える事は無いだろうという予想
	];
	const selectors = "[" + customDataNames.join("], [") + "]";
	const nodeList = document.querySelectorAll(selectors);
	const mutationObserver = becky.MutationObserver.byNodeList(
		nodeList,
		becky.dataSync.onUpdateContent,
		{
			attributes     : true,
			attributeFilter: customDataNames,
		});
	if (becky.assertion.isNull(mutationObserver)) {
		return null;
	}
	// 画面の初期化として呼び出す
	nodeList.forEach(_node => {
		customDataNames.forEach(_customDataName => {
			becky.dataSync.callChangeEventAttr(_node, _customDataName);
		});
	});
	return mutationObserver;
}
