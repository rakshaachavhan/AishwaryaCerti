/*! @file
 * @brief becky の 検査に関する Web Storage
 *
 * 依存するもの
 * - beckyWebStorageHelper.js
 * - beckyWebStorageIO.js
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.WebStorage = becky.WebStorage || {};

// サーバーの起動日時
becky.WebStorage.uptime_s = becky.WebStorage.uptime_s || {};

becky.WebStorage.uptime_s.getKey = function()
{
	return "server.uptime_s";
}
becky.WebStorage.uptime_s.IO = function()
{
	return becky.WebStorage.local.IO(
		becky.WebStorage.uptime_s.getKey());
}
becky.WebStorage.uptime_s.getValue = function()
{
	return becky.WebStorage.uptime_s.IO().getString();
}
becky.WebStorage.uptime_s.setValue = function(aValue)
{
	return becky.WebStorage.uptime_s.IO().setString(aValue);
}

/*!
 * @brief もしサーバーが再起動しているなら値をリセットする
 * サーバーの起動日時が変更されているか
 */
becky.WebStorage.ifRebootServerThenResetValue = function()
{
	const webStorage_uptime_s = becky.WebStorage.uptime_s.IO();
	if (webStorage_uptime_s.getString() === becky.dynamic.getUptime_s()) {
		return;
	}
	webStorage_uptime_s.setString(becky.dynamic.getUptime_s());
	// 他覚検査の固視
	becky.WebStorage.objectiveLEDfixation.IO().removeItem();
	// 模型眼アライメントモード
	becky.WebStorage.modelEyeAlignmentMode.IO().removeItem();
}

// 他覚検査の固視
becky.WebStorage.objectiveLEDfixation = becky.WebStorage.objectiveLEDfixation || {};

becky.WebStorage.objectiveLEDfixation.getKey = function()
{
	return "objective.LED.fixation";
}
becky.WebStorage.objectiveLEDfixation.IO = function()
{
	return becky.WebStorage.local.IO(
		becky.WebStorage.objectiveLEDfixation.getKey());
}
becky.WebStorage.objectiveLEDfixation.getValue = function()
{
	becky.WebStorage.ifRebootServerThenResetValue();

	const value = becky.WebStorage.objectiveLEDfixation.IO().getString();
	if (modelHelper.isNullOrEmpty(value)) {
		return "High"; // デフォルト値
	}
	return value;
}
becky.WebStorage.objectiveLEDfixation.setValue = function(aValue)
{
	return becky.WebStorage.objectiveLEDfixation.IO().setString(aValue);
}

// 模型眼アライメントモード
becky.WebStorage.modelEyeAlignmentMode = becky.WebStorage.modelEyeAlignmentMode || {};

becky.WebStorage.modelEyeAlignmentMode.getKey = function()
{
	return "modelEye.alignment.mode";
}
becky.WebStorage.modelEyeAlignmentMode.IO = function()
{
	return becky.WebStorage.local.IO(
		becky.WebStorage.modelEyeAlignmentMode.getKey());
}
becky.WebStorage.modelEyeAlignmentMode.getValue = function()
{
	becky.WebStorage.ifRebootServerThenResetValue();

	const value = becky.WebStorage.modelEyeAlignmentMode.IO().getString();
	if (modelHelper.isNullOrEmpty(value)) {
		return false; // デフォルト値
	}
	return modelHelper.toBoolean(value);
}
becky.WebStorage.modelEyeAlignmentMode.setValue = function(aValue)
{
	if (modelHelper.isBoolean(aValue)) {
		aValue = aValue.toString();
	}
	return becky.WebStorage.modelEyeAlignmentMode.IO().setString(aValue);
}
