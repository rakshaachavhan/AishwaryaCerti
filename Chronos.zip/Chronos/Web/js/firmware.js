/*! @file
 * @brief ファームウェア画面で使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

const _intervalMSState    = 1000;
const _intervalMSProgress = 12000; // 20分 = 1200秒。進捗の最小単位は 1% なので 12秒。

let _intervalState    = null;
let _intervalProgress = null;

let _latestState    = -1; // 最後の状態
let _latestProgress = -1; // 最後の進捗

/*!
 * @brief (ファームウェア)メッセージの定義リストから文字列を得る
 *
 * @param[in] string aKeyByFirmware (ファームウェア)メッセージの定義名
 * @return string メッセージ文字列
 */
function _getDefMessageByFirmware(aKeyByFirmware)
{
	if (becky.assertion.isNullOrEmpty(aKeyByFirmware)) {
		return "";
	}
	return viewHelper.getDefMessage("firmware/" + aKeyByFirmware);
}

/*!
 * @brief プログレスバーに進捗を設定する
 *
 * @param[in] integer aValue 進捗率(0～100)
 */
function _setProgressbarValue(aValue)
{
	$("#progressUpdate").progressbar("value", aValue);
	$("#labelUpdateValue").attr("data-text", aValue);
}

/*!
 * @brief アップデートの状態や進捗の結果を受け取った時の処理
 * Mediator パターンと同じ考え
 *
 * @param[in] integer aState 状態
 * @param[in] integer aProgress 進捗
 */
function _onChangeStateOrProgress(aState, aProgress)
{
	const bIsChangeState    = aState    != _latestState;
	const bIsChangeProgress = aProgress != _latestProgress;

	const lines = [];

	if (0x80000000 == aState) {
		if (0 == aProgress) {
			// Update ボタンを押す事が可能
			viewHelper.setAttDisabled($("#btnUpdate"), false);
		}
	} else if (0 < aState) {
		// 状態コードを16進で表示
		lines.push("state = 0x" + viewHelper.zeroPadding(aState, 8, 16).toUpperCase());
	}

	if (0x00000000 == aState) {
		// 正常
		if (100 > aProgress) {
			// 進行中
			if (bIsChangeState) {
				const strLoadingImg = '<img src="../img/loader_16x11.gif" width="16" height="11" alt="...">';
				lines.push(_getDefMessageByFirmware("updating") + "&nbsp;" + strLoadingImg);
			}

			if (modelHelper.isNull(_intervalState)) {
				// 状況を問い合わせていない場合は状況を問い合わせる
				_intervalState = asyncHelper.delay(_intervalMSState);
				_intervalState.then(() => {
					_intervalState = null;
					_postSocketGetState();
				});
			}
			if (modelHelper.isNull(_intervalProgress)) {
				// 進捗を問い合わせていない場合は進捗を問い合わせる
				_intervalProgress = asyncHelper.delay(_intervalMSProgress);
				_intervalProgress.then(() => {
					_intervalProgress = null;
					_postSocketGetProgress();
				});
			}
		}
	} else if (0 < aState) {
		if (0x00000001 & aState) {
			// USBにアクセスできない
			lines.push(_getDefMessageByFirmware("errorAccessUSBmemory"));
		}
		if (0x00000002 & aState) {
			// アップデート用ディレクトリ、ファイルがない
			lines.push(_getDefMessageByFirmware("errorNotFindUpdateFiles"));
		}
		if (0x00000004 & aState) {
			// 制御BOX用 TAR展開エラー
			lines.push(_getDefMessageByFirmware("errorExpandTarFileForControlBox"));
		}
		if (0x00000008 & aState) {
			// 撮影測定メイン用 TAR展開エラー
			lines.push(_getDefMessageByFirmware("errorExpandTarFileForCaptureMeasurementMain"));
		}
		if (0x00000080 & aState) {
			// 外部入出力内部エラー
			lines.push(_getDefMessageByFirmware("errorInternalExternalIO"));
		}
		if (0x00000100 & aState) {
			// 撮影測定メイン右　ROOTアプリアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateRootAppOnTheRightCaptureMeasurementMain"));
		}
		if (0x00000200 & aState) {
			// 撮影測定メイン右　BOOTアプリアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateBootAppOnTheRightCaptureMeasurementMain"));
		}
		if (0x00000400 & aState) {
			// 撮影測定メイン右　OPTファームアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateOptFwOnTheRightCaptureMeasurementMain"));
		}
		if (0x00000800 & aState) {
			// 撮影測定メイン右　BASEファームアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateBaseFwOnTheRightCaptureMeasurementMain"));
		}
		if (0x00010000 & aState) {
			// 撮影測定メイン左　ROOTアプリアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateRootAppOnTheLeftCaptureMeasurementMain"));
		}
		if (0x00020000 & aState) {
			// 撮影測定メイン左　BOOTアプリアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateBootAppOnTheLeftCaptureMeasurementMain"));
		}
		if (0x00040000 & aState) {
			// 撮影測定メイン左　OPTファームアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateOptFwOnTheLeftCaptureMeasurementMain"));
		}
		if (0x00080000 & aState) {
			// 撮影測定メイン左　BASEファームアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateBaseFwOnTheLeftCaptureMeasurementMain"));
		}
		if (0x01000000 & aState) {
			// 制御BOX　ROOTアプリアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateRootAppOnTheControlBox"));
		}
		if (0x02000000 & aState) {
			// 制御BOX　BOOTアプリアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdateBootAppOnTheControlBox"));
		}
		if (0x04000000 & aState) {
			// 制御BOX　PICファームアップデートでエラーが発生
			lines.push(_getDefMessageByFirmware("errorUpdatePicFwOnTheControlBox"));
		}
	}

	if (100 <= aProgress) {
		// 完了
		lines.push(_getDefMessageByFirmware("updateFinished"));
	}

	if (bIsChangeProgress) {
		_setProgressbarValue(aProgress);
	}

	if (!modelHelper.isNullOrEmpty(lines)) {
		$("#labelUpdateMessage").html(lines.join("<BR>"));
	}

	_latestState    = aState;
	_latestProgress = aProgress;
}

/*!
 * @brief ソケット通信失敗時のエラー表示
 *
 * @param[in] XMLHttpRequest aXMLHttpRequest 通信に失敗した際に呼び出される Ajax Event の引数1を渡す
 * @param[in] string aTextStatus 通信に失敗した際に呼び出される Ajax Event の引数2を渡す
 * @param[in] string aErrorThrown 通信に失敗した際に呼び出される Ajax Event の引数3を渡す
 * @param[in] array aRequestJson リクエストに使用したJSON
 */
function _postSocketFailedAlert(aXMLHttpRequest, aTextStatus, aErrorThrown, aRequestJson)
{
	const lines = ajaxHelper.getFailedArray(aXMLHttpRequest, aTextStatus, aErrorThrown, aRequestJson);
	// ダイアログ表示
	alert(lines.join(" "));
	// HTML表示
	$("#labelErrorMessage").append("<p>" + lines.join("&nbsp;") + "</p>");
}

/*!
 * @brief アップデート状態を取得する
 * 非同期関数
 */
function _postSocketGetState()
{
	const json = {
		action:kAction.get,
		target:kTarget.setting,
		function:kFunction.maintenance,
		param:{
			option:kOption.state,
		},
		type:kType.command,
	};
	becky.Socket.post(json).then(resultJson => {
		const state = parseInt(resultJson.param.info, 10);
		_onChangeStateOrProgress(state, _latestProgress);
	}).catch((jqXHR, textStatus, errorThrown) => {
		// 失敗時
		_postSocketFailedAlert(jqXHR, textStatus, errorThrown, json);
	});
}

/*!
 * @brief アップデート進捗を問い合わせる
 * 非同期関数
 */
function _postSocketGetProgress()
{
	const json = {
		action:kAction.get,
		target:kTarget.setting,
		function:kFunction.maintenance,
		param:{
			option:kOption.progress,
		},
		type:kType.command,
	};
	becky.Socket.post(json).then(resultJson => {
		const progress = parseInt(resultJson.param.info, 10);
		_onChangeStateOrProgress(_latestState, progress);
	}).catch((jqXHR, textStatus, errorThrown) => {
		// 失敗時
		_postSocketFailedAlert(jqXHR, textStatus, errorThrown, json);
	});
}

/*!
 * @brief アップデートの開始
 * 非同期関数
 */
function _postSocketStartUpdate()
{
	const $btnUpdate = $("#btnUpdate");
	viewHelper.setAttDisabled($btnUpdate);

	const json = {
		action:kAction.start,
		target:kTarget.setting,
		function:kFunction.maintenance,
		param:{
			option:kOption.update,
			common:{
				update:kOption.normal,
			},
		},
		type:kType.command,
	};
	becky.Socket.post(json).then(() => {
		// 成功時
		// 状態と進捗を得る
		_postSocketGetState();
		_postSocketGetProgress();
	}).catch((jqXHR, textStatus, errorThrown) => {
		// 失敗時
		_postSocketFailedAlert(jqXHR, textStatus, errorThrown, json);
	});
}

$(document).ready(function(){
	$(".progress").progressbar({ value: false, max: 100 });

	// data-* の変更イベントを作成する
	becky.dataSync.createChangeEvent();

	// 状態と進捗を得る
	_postSocketGetState();
	_postSocketGetProgress();

	$("#btnUpdate").click(function(){
		_postSocketStartUpdate();
	});
});

}());//即時関数の終端
