/*! @file
 * @brief becky の WebSocket I/F関数郡
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.WebSocket = becky.WebSocket || {};

becky.WebSocket.eventTypes = ["open", "close", "error", "message"]; //!< @brief WebSocket のイベント名郡
becky.WebSocket.url = "ws://" + location.hostname + ":8080"; //!< @brief 接続先のURL
becky.WebSocket.webSocket = null; //!< @brief WebSocket キャッシュ
becky.WebSocket.checkStateInterval = 3000; //!< @brief WebSocket の状態確認の周期
becky.WebSocket.isRetrying = false; //!< @brief 再試行中かどうか
becky.WebSocket.responseWaitingIDs = new Set(); //!< @brief レスポンス待ちの ID 群

/*!
 * @brief 接続先のURLを設定する
 *
 * @param[in] string aURL 接続先のURL
 */
becky.WebSocket.setURL = function(aURL)
{
	becky.assertion.assert(!modelHelper.isNullOrEmpty(aURL), "becky.WebSocket.setURL");
	becky.WebSocket.url = aURL;
}

/*!
 * @brief 接続先のURLを得る
 *
 * @return string 接続先のURL
 */
becky.WebSocket.getURL = function()
{
	return becky.WebSocket.url;
}

/*!
 * @brief Websocket に共通のイベントを登録
 *
 * @param[in] Event aEvent 
 * @param[in,out] WebSocket aWebSocket 
 * @return void
 */
becky.WebSocket._addEventListeners = function(aEvent, aWebSocket)
{
	if (becky.assertion.isNull(aEvent) ||
	    becky.assertion.isNull(aWebSocket)) {
		return;
	}
	becky.WebSocket.eventTypes.forEach(aEventType => {
		aWebSocket.addEventListener(aEventType, aEvent, false);
	});
}

/*!
 * @brief Websocket の共通イベントを解除
 *
 * @param[in] Event aEvent 
 * @param[in,out] WebSocket aWebSocket 
 * @return void
 */
becky.WebSocket._removeEventListeners = function(aEvent, aWebSocket)
{
	if (becky.assertion.isNull(aEvent) ||
	    becky.assertion.isNull(aWebSocket)) {
		return;
	}
	becky.WebSocket.eventTypes.forEach(aEventType => {
		aWebSocket.removeEventListener(aEventType, aEvent, false);
	});
}

/*!
 * @brief Websocket を作り出す
 *
 * @param[in] Event aEvent 
 * @return WebSocket オブジェクト
 */
becky.WebSocket._create = function(aEvent)
{
	const webSocket = new WebSocket(becky.WebSocket.getURL());
	becky.WebSocket._addEventListeners(aEvent, webSocket);
	return webSocket;
}

/*!
 * @brief WebSocket を得る
 *
 * @return WebSocket オブジェクト
 */
becky.WebSocket.getWebSocket = function()
{
	return becky.WebSocket.webSocket;
}

/*!
 * WebSocket の状態確認の周期を設定
 *
 * @param[in] int aValue 状態確認の周期を設定[ms]
 */
becky.WebSocket.setCheckStateInterval = function(aValue)
{
	becky.assertion.assert(!modelHelper.isNullOrEmpty(aValue), "becky.WebSocket.setCheckStateInterval");
	becky.WebSocket.checkStateInterval = aValue;
}

/*!
 * @brief WebSocket の再接続処理
 *
 * @param[in] int aRetryCount 再試行回数
 * @param[in] Event aEvent 
 * @return void
 */
becky.WebSocket._retry = function(aRetryCount, aEvent)
{
	becky.WebSocket.isRetrying = true;
	// Exponential Backoff アルゴリズム
	const delayMS = (Math.random() * (Math.pow(2, aRetryCount) - 1)) * 1000;
	asyncHelper.delay(delayMS).then(() => {
		const webSocket = becky.WebSocket._create(aEvent);
		const funcRetry = event => {
			switch (event.type) {
				case "open":
					becky.WebSocket.isRetrying = false;
					becky.WebSocket._removeEventListeners(funcRetry, webSocket);
					becky.WebSocket.webSocket = webSocket;
					break;
				case "error":
					becky.WebSocket._retry(aRetryCount + 1, aEvent);
					break;
				default:
					break;
			}
		};
		becky.WebSocket._addEventListeners(funcRetry, webSocket);
	});
}

/*!
 * @brief WebSocket を利用可能な状態にする
 *
 * @param[in] Event aEvent 
 * @return void
 */
becky.WebSocket.build = function(aEvent)
{
	becky.WebSocket.webSocket = becky.WebSocket._create(aEvent);
	if (0 >= becky.WebSocket.checkStateInterval) {
		return;
	}
	asyncHelper.interval(becky.WebSocket.checkStateInterval, () => {
		if (becky.WebSocket.isRetrying) {
			return; // 再試行中はスキップ
		}
		const webSocket = becky.WebSocket.getWebSocket();
		if (becky.assertion.isNull(webSocket) ||
		    WebSocket.CLOSED === webSocket.readyState) {
			becky.WebSocket._retry(1, aEvent);
		}
	});
}

/*!
 * @brief エラーとして扱うJSONデータかを判定
 *
 * @param[in] array aRequestJson 判定対象の結果JSON
 * @retval true  エラー
 * @retval false エラーではない
 */
becky.WebSocket.isFailedJson = function(aResultJson)
{
	if (becky.assertion.isNullOrEmpty(aResultJson) ||
	    becky.assertion.isUndefined(aResultJson.return)) {
		return true;
	}
	return !aResultJson.return;
}

/*!
 * @brief 続きが存在するJSONデータかを判定
 *
 * @param[in] array aRequestJson 判定対象の結果JSON
 * @retval true  続きが存在する
 * @retval false 続きが存在しない
 */
becky.WebSocket.isContinueJson = function(aResultJson)
{
	if (becky.assertion.isNullOrEmpty(aResultJson) ||
	    modelHelper.isUndefined(aResultJson.continue)) {
		return false;
	}
	return aResultJson.continue;
}

/*!
 * @brief 他の端末からの要求でブロードキャストされて来たJSONデータかを判定
 *
 * @param[in] array aRequestJson 判定対象の結果JSON
 * @retval true  ブロードキャスト
 * @retval false 自身がリクエストして返ってきたもの
 */
becky.WebSocket.isBroadcast = function(aResultJson)
{
	if (becky.assertion.isNullOrEmpty(aResultJson) ||
	    becky.assertion.isUndefined(aResultJson.requestID)) {
		return true;
	}
	return !becky.WebSocket.responseWaitingIDs.has(aResultJson.requestID);
}

/*!
 * @brief becky の WebSocket にJSONデータをポストしイベント処理を行う
 * 非同期関数
 *
 * @param[in,out] array aJson 送信したいJSONデータ
 * @param[in] function aFuncResultJson 受信したJSONデータ(optional)
 * @return Promise 
 */
becky.WebSocket.post = async function(aJson, aFuncResultJson)
{
	let webSocket = null;
	let funcPost  = null;
	let timeout   = null;
	const promise = new Promise((resolve, reject) => {
		webSocket = becky.WebSocket.getWebSocket();
		if (becky.assertion.isNullOrEmpty(aJson) ||
		    becky.assertion.hasUndefined (aJson) ||
		    becky.assertion.isNull(webSocket) ||
		    becky.assertion.isFalse(WebSocket.OPEN === webSocket.readyState)) {
			reject();
			return;
		}
		if (modelHelper.isUndefined(aJson.requestID)) {
			aJson.requestID = becky.ID.createRequestID();
		}
		becky.jsonHelper.normalization(aJson); // 正規化
		const jsonString = JSON.stringify(aJson);
		funcPost = event => {
			switch (event.type) {
				case "message":
					const resultJson = JSON.parse(event.data);
					if (becky.assertion.isUndefined(resultJson.requestID)) {
						break;
					}
					if (aJson.requestID != resultJson.requestID) {
						// 受け取るべき情報かを判定し違う場合は何もせず抜ける
						break;
					}
					const isFailed   = becky.WebSocket.isFailedJson  (resultJson);
					const isContinue = becky.WebSocket.isContinueJson(resultJson);
					if (!becky.assertion.isNull(timeout)) {
						if (isContinue) {
							timeout.restart();
						} else {
							timeout.stop();
						}
					}
					if (!modelHelper.isUndefined(aFuncResultJson)) {
						aFuncResultJson(resultJson);
					}
					if (!isContinue) {
						if (isFailed) {
							reject(resultJson);
						} else {
							resolve(resultJson);
						}
					}
					break;
				case "close":
				case "error":
					reject();
					break;
				default:
					// 未知のイベント
					becky.assertion.failure("unknown event.type " + event.type);
					reject();
					break;
			}
		};
		becky.WebSocket._addEventListeners(funcPost, webSocket);
		becky.WebSocket.responseWaitingIDs.add(aJson.requestID);
		try {
			webSocket.send(jsonString);
		} catch (ex) {
			console.log(ex);
			reject();
		}
		timeout = asyncHelper.delay(15000);
		timeout.then(() => {
			// タイムアウトした
			reject();
		}).catch(() => {
			// stop が呼ばれた
			timeout = null;
		});
	});
	promise.catch(() => {}).then(() => {
		// always(reject or resolve)
		becky.WebSocket._removeEventListeners(funcPost, webSocket);
		becky.WebSocket.responseWaitingIDs.delete(aJson.requestID);
		if (!modelHelper.isNull(timeout)) {
			timeout.stop();
		}
	});
	return promise;
}
