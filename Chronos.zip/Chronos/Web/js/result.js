/*! @file
 * @brief (結果)出力で使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

$(document).ready(function(){

	// 端末に一時保存されている計測値を削除
	becky.WebStorage.local.removeItem( "objective.update.data");
	becky.WebStorage.local.removeItem("subjective.update.data");

	(async function(){
		try {
			becky.operatorLog.closeOneCycleNode();

			const requestJsonRL = { chartID: 0 };
			await becky.LeanStartup.post("Chart", {
				R: requestJsonRL,
				L: requestJsonRL,
			});

			const resetOptParamLR = {
				LED: {
					Fixation: becky.WebStorage.objectiveLEDfixation.getValue(),
				},
			};
			await becky.LeanStartup.post("ResetOpt", {
				L: resetOptParamLR,
				R: resetOptParamLR,
			});

		} catch (resultJson) {
			// 失敗
			// エラーメッセージ表示
			becky.LeanStartup.alertErrorMessage(resultJson);
		} finally {
			// 次へ遷移可能
			becky.navi.showNext();
		}
	}());

	// クリック時にカレントの切り替えを行う
	$(".current").parent().children().click(function(){
		viewHelper.selectClassSingle("current", $(this));
	});

	// タブヘッダ
	$(".tab-box .tab-header").click(function(){
		const $tabHeader = $(this);
		$("#tabResult").attr("data-tab-index", $tabHeader.index());
	});
	{
		const optionsAttributeFilterTabIndex = {
			attributes: true,
			attributeFilter: [ "data-tab-index" ],
		};
		becky.MutationObserver.byID(
			"#tabResult",
			records => records.forEach(_record => {
				const target = _record.target;
				const tabIndex = target.dataset.tabIndex;
				const $tab = $(".tab-box .tab-content-group .tab-content").eq(tabIndex);
				if (!becky.assertion.isNullOrEmpty($tab)) {
					viewHelper.selectClassSingle("current", $tab);
				}
				const $tabHead = $(".tab-box .tab-header-group .tab-header").eq(tabIndex);
				if (!becky.assertion.isNullOrEmpty($tabHead)) {
					viewHelper.selectClassSingle("current", $tabHead);
				}
			}),
			optionsAttributeFilterTabIndex);
	}

	// ページ遷移時
	const $btnNaviNext = $("#btnNaviNext");
	$btnNaviNext.click(function(){
		// 次へのタッチイベントを無効化
		becky.navi.disableNext();
	});

	// data-* の変更イベントを作成する
	becky.dataSync.createChangeEvent();
});

}());//即時関数の終端
