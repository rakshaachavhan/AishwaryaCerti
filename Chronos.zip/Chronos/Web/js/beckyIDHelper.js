/*! @file
 * @brief becky の識別子(ID)に関する関数郡
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.ID = becky.ID || {};

becky.ID.latestRequestID = { clientID:null, dateNow:0, duplicateCount:0 }; //!< @brief 最後の要求 ID

/*!
 * @brief 端末の IP アドレスを得る
 * 調べる事ができない場合はプライベートアドレス(127.0.0.1)を返す
 *
 * @return string 端末の IP アドレス
 */
becky.ID._getClientIP = function()
{
	try {
		return becky.dynamic.getClientIpAddress();
	} catch (ex) {
		modelHelper.catchExceptionByUndefined(ex);
		return "127.0.0.1";
	}
}

/*!
 * @brief 端末の ID を得る
 *
 * @return string 端末の ID (8桁固定)
 */
becky.ID._getClientID = function()
{
	if (modelHelper.isNull(becky.ID.latestRequestID.clientID)) {
		const clientIP = becky.ID._getClientIP();
		const splitClientIP = clientIP.split(".");
		becky.assertion.assert(4 === splitClientIP.length, "splitClientIP.length not 4");
		becky.ID.latestRequestID.clientID = splitClientIP.reduce((previousValue, currentValue) => {
			const currentValueInt = parseInt(currentValue, 10);
			const currentValueHex = viewHelper.zeroPadding(currentValueInt, 2, 16);
			return previousValue + currentValueHex;
		}, "");
	}
	return becky.ID.latestRequestID.clientID;
}

/*!
 * @brief 要求 ID を生成
 * 端末の ID (8桁固定) + エポックミリ秒(16進数)(11桁以上) + 重複時連番(16進数)(1桁以上)
 *
 * @return string 要求 ID を生成
 */
becky.ID.createRequestID = function()
{
	const newClientID = becky.ID._getClientID();
	const newDateNow  = viewHelper.zeroPadding(Date.now(), 11, 16);
	const    newClientID_DateNow = newClientID + newDateNow;
	const latestClientID_DateNow = becky.ID.latestRequestID.clientID + becky.ID.latestRequestID.dateNow;
	const newDuplicateCount = latestClientID_DateNow === newClientID_DateNow ?
		becky.ID.latestRequestID.duplicateCount + 1 : 0;
	const newRequestID = newClientID_DateNow + viewHelper.zeroPadding(newDuplicateCount, 1, 16);
	becky.assertion.assert(20 === newRequestID.length, "newRequestID.length not 20"); // ほぼ20桁で間違いない
	becky.assertion.assert(newClientID === becky.ID.latestRequestID.clientID, "becky.ID.createRequestID");
//	becky.ID.latestRequestID.clientID       = newClientID; 変化しない筈なので更新不要
	becky.ID.latestRequestID.dateNow        = newDateNow;
	becky.ID.latestRequestID.duplicateCount = newDuplicateCount;
	return newRequestID;
}
