/*! @file
 * @brief becky のログヘルパー
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.log = becky.log || {};

/*!
 * @brief ログ用のISO 8601文字列に変換(基本形式)
 * 例. (日本の場合) YYYYMMDDThhmmss+0900
 * 
 * @param[in] Date aDate 変換元
 * @return string 変換後
 */
becky.log.toISO8601String = function(aDate)
{
	if (becky.assertion.isFalse(aDate instanceof Date)) {
		return null;
	}

	return [
		[
			aDate.getFullYear(),
			aDate.getMonth() + 1,
			aDate.getDate()
		].map(value_ => viewHelper.zeroPadding(value_, 2))
		 .join(""),
		aDate.toTimeString()
		     .match(/(\d{1,2}):?(\d{1,2}):?(\d{1,2}).*GMT.*([+|-]\d+)/)
		     .slice(1)
		     .join(""),
	].join("T");
}

/*!
 * @brief ログ用のISO 8601文字列に変換(拡張形式)
 * 例. (日本の場合) YYYY-MM-DDThh:mm:ss+09:00
 * 
 * @param[in] Date aDate 変換元
 * @return string 変換後
 */
becky.log.toISO8601ExtString = function(aDate)
{
	if (becky.assertion.isFalse(aDate instanceof Date)) {
		return null;
	}

	const date = [
			aDate.getFullYear(),
			aDate.getMonth() + 1,
			aDate.getDate()
	].map(value_ => viewHelper.zeroPadding(value_, 2))
	 .join("-");

	const timeString = aDate.toTimeString();
	const time = timeString
		.match(/(\d{1,2}):?(\d{1,2}):?(\d{1,2})/)
		.slice(1)
		.join(":");
	const timeZone = timeString
		.match(/GMT.*([+|-]\d{2})(\d{2})/)
		.slice(1)
		.join(":");

	return [
		date,
		time,
	].join("T")
	 .concat(timeZone);
}

/*!
 * @brief ログ用のコマンドパラメーターを生成する
 *
 * @param[in] Date aDate execTimeに出力する時間
 * @return array infoForLog に設定する値
 */
becky.log.createCommandParamInfoForLog = function(aDate)
{
	let sessionDate_      = "";
	let sessionPatientID_ = "";
	try {
		sessionDate_      = becky.session.sessionDate;
		sessionPatientID_ = becky.session.sessionPatientID;
	} catch (ex) {
		modelHelper.catchExceptionByUndefined(ex);
	}
	return {
		sessionDate     : sessionDate_,
		sessionPatientID: sessionPatientID_,
		execTime        : becky.log.toISO8601String(aDate),
	}
}
