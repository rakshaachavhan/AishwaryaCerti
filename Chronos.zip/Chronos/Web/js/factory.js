/*! @file
 * @brief 工具ツールで使用するスクリプト
 */

// 即時関数を使って閉じ込める
(function(){
"use strict";

/*!
 * @brief IPとポート番号を得る
 *
 * @return string IPとポート番号(XXX.XXX.XXX.XXX:XXXX)
 */
function _getIDwithPort()
{
	const ip   = $("#ip").val();
	const port = $("#port").val();
	let ipPort = ip;
	if (80 != port) {
		ipPort += ":" + port;
	}
	return ipPort;
}

/*!
 * @brief アクセスすべきJSONのURIを得る
 *
 * @return string リクエスト先のJsonのURI
 */
function _getJsonURI()
{
	const pos = $("#pos").val();
	const url = "http://" + _getIDwithPort() + "/factory" + pos + "/can.json";
	return url;
}

/*!
 * @brief JSON の取得に失敗した場合に呼ぶ
 *
 * @param[in] string aCommand コマンド名
 */
function _alertJSONfailed(aCommand)
{
	alert("net work error!\ncommand = " + aCommand);
}

/*!
 * コマンドを送信する
 *
 * @param[in] array aParam 送信パラメータ
 */
function _sendCommand(aParam)
{
	$.getJSON(_getJsonURI(), aParam)
		.done(data => {
			const bResult = data["result"];
			if (!bResult) {
				alert("The function of CAN returned false.");
			}
		})
		.fail(() => {
			_alertJSONfailed(aParam.command);
		})
		.always(() => {
		});
}

$(document).ready(function(){
	// スタイル適用前の画面を見せたくない
	$("body").fadeIn();

	$("#tabs").tabs({ active: 1 });
	const $tabs = $("#tabs-AdjustList, #tabs-FunctionCheck");
	$tabs.tabs();
	$("#tabs-SingleFunctionCommand").tabs({ active: 5 });

	$("input[type='radio']").checkboxradio({
		icon: false
	});
	const $input_type_tel = $("input[type='tel']");
	$input_type_tel.spinner();
	$input_type_tel.width(64);

	// 情報を取得する類の関数で、結果が返ってくるまで表示する画像
	const strLoadingImg = '<img src="../img/loader_16x11.gif" width="16" height="11">';

	// Adjust List
	$("#E2PROMInitialize").click(function(){
		const $E2PROMInitializeResult = $("#E2PROMInitializeResult");
		$E2PROMInitializeResult.html(strLoadingImg);
		const strUnitId = $("[name=E2PROMinitUnitId]:checked").val();
		$.getJSON(_getJsonURI(), { command: "E2PROMInitialize", unitId: strUnitId })
			.done(data => {
				let strValue = "";
				const bResult = data["result"];
				if (!bResult) {
					strValue = "Error: Timeout!";
				} else {
					const nValue = data["value"];
					strValue = 0 != nValue ?
						"Error: E2PROM Initialize failed." : "Succeeded";
				}
				$E2PROMInitializeResult.html(strValue);
			})
			.fail(() => {
				$E2PROMInitializeResult.html("Error!");
				_alertJSONfailed("E2PROMInitialize");
			})
			.always(() => {
			});
	});

	// LED
	$("[name=anterior1LED]").click(function(){
		let nValue = $(this).val();
		if (0 != nValue) {
			nValue = $("#anterior1LED_Value").val();
		}
		_sendCommand({ command: "anterior1LED", value: nValue });
	});

	$("[name=anterior2LED]").click(function(){
		let nValue = $(this).val();
		if (0 != nValue) {
			nValue = $("#anterior2LED_Value").val();
		}
		_sendCommand({ command: "anterior2LED", value: nValue });
	});

	$("[name=XYLED]").click(function(){
		let nValue = $(this).val();
		if (0 != nValue) {
			nValue = $("#XYLED_Value").val();
		}
		_sendCommand({ command: "XYLED", value: nValue });
	});

	$("[name=keratoLED]").click(function(){
		let nValue = $(this).val();
		if (0 != nValue) {
			nValue = $("#keratoLED_Value").val();
		}
		_sendCommand({ command: "keratoLED", value: nValue });
	});

	$("#setSLDCurrent").click(function(){
		const nValue = $("#setSLDCurrent_Value").val();
		_sendCommand({ command: "setSLDCurrent", value: nValue });
	});

	$("[name=setSLDPower]").click(function(){
		const nValue = $(this).val();
		_sendCommand({ command: "setSLDPower", value: nValue });
	});

	$("[name=fixationLED]").click(function(){
		let nValue = $(this).val();
		if (0 != nValue) {
			nValue = $("#fixationLED_Value").val();
		}
		_sendCommand({ command: "fixationLED", value: nValue });
	});

	// Shutter
	$("[name=opticalPath]").click(function(){
		const nValue = $(this).val();
		_sendCommand({ command: "opticalPath", value: nValue });
	});

	$("[name=RGBandpass]").click(function(){
		const nValue = $(this).val();
		_sendCommand({ command: "RGBandpass", value: nValue });
	});

	// OptMotor
	$("[name=rotaryPrism]").click(function(){
		const nValue = $(this).val();
		_sendCommand({ command: "rotaryPrism", value: nValue });
	});

	$("[name=setTFPower]").click(function(){
		const nValue = $(this).val();
		_sendCommand({ command: "setTFPower", value: nValue });
	});

	$("#initializeTF").click(function(){
		_sendCommand({ command: "initializeTF" });
	});

	$("#getTFPosition").click(function(){
		const $getTFPositionValue = $("#getTFPositionValue");
		$getTFPositionValue.html(strLoadingImg);
		$.getJSON(_getJsonURI(), { command: "getTFPosition" })
			.done(data => {
				let strValue = "";
				const bResult = data["result"];
				if (!bResult) {
					strValue = "Error!";
				} else {
					strValue = data["value"];
				}
				$getTFPositionValue.html(strValue);
			})
			.fail(() => {
				$getTFPositionValue.html("Error!");
				_alertJSONfailed("getTFPosition");
			})
			.always(() => {
			});
	});

	$("#moveTF_Normal").click(function(){
		const nExponent = $("#TFExponent").val();
		const nValue    = $("#TFMoveDiopter").val();
		_sendCommand({ command: "moveTF", tfmove: "Normal", exponent: nExponent, value: nValue });
	});

	$("#moveTF_Fog").click(function(){
		_sendCommand({ command: "moveTF", tfmove: "Fog" });
	});

	$("#setTFOffset").click(function(){
		const nValue = $("#TFOffsetPulse").val();
		_sendCommand({ command: "setTFOffset", value: nValue });
	});

	$("[name^=setVCCPower]").click(function(){
		const nVCC = $(this).attr("name").slice(-1);
		const nValue = $(this).val();
		_sendCommand({ command: "setVCCPower", vcc: nVCC, value: nValue });
	});

	$("[id^=initializeVCC]").click(function(){
		const nVCC = $(this).attr("id").slice(-1);
		_sendCommand({ command: "initializeVCC", vcc: nVCC });
	});

	$("[id^=getVCCPosition]").click(function(){
		const nVCC = $(this).attr("id").slice(-1);
		const $getVCCPositionValue = $("#getVCCPositionValue" + nVCC);
		$getVCCPositionValue.html(strLoadingImg);
		$.getJSON(_getJsonURI(), { command: "getVCCPosition", vcc: nVCC })
			.done(data => {
				let strValue = "";
				const bResult = data["result"];
				if (!bResult) {
					strValue = "Error!";
				} else {
					const nN     = data["n"];
					const nValue = data["value"];
					const nPower = Math.pow(10, nN);
					const nPos   = nPower * nValue;
					strValue = nPos;
				}
				$getVCCPositionValue.html(strValue);
			})
			.fail(() => {
				$getVCCPositionValue.html("Error!");
				_alertJSONfailed("getVCCPosition");
			})
			.always(() => {
			});
	});

	$("[id^=moveVCC]").click(function(){
		const nVCC = $(this).attr("id").slice(-1);
		const nExponent = $("#VCCExponent"    + nVCC).val();
		const nValue    = $("#VCCMoveDiopter" + nVCC).val();
		_sendCommand({ command: "moveVCC", vcc: nVCC, exponent: nExponent, value: nValue });
	});

	$("[id^=setVCCOffset]").click(function(){
		const nVCC = $(this).attr("id").slice(-1);
		const nValue = $("#VCCOffsetPulse" + nVCC).val();
		_sendCommand({ command: "setVCCOffset", vcc: nVCC, value: nValue });
	});

	// Stereo Camera
	$("[id^=getStereoCameraReadROMData]").click(function(){
		const nValue = $(this).attr("id").slice(-1);
		const $stereoCameraReadROMDataValue = $("#stereoCameraReadROMDataValue" + nValue);
		$.getJSON(_getJsonURI(), { command: "getStereoCameraReadROMData", value: nValue })
			.done(data => {
				let strValue = "";
				const bResult = data["result"];
				if (!bResult) {
					strValue = "Error!";
				} else {
					strValue = data["value"];
				}
				$stereoCameraReadROMDataValue.append(strValue + "<br/>");
			})
			.fail(() => {
				$stereoCameraReadROMDataValue.append("Error!<br/>");
				_alertJSONfailed("getStereoCameraReadROMData");
			})
			.always(() => {
			});
	});

	// Base Motor
	$("[name^=setMotorPower]").click(function(){
		const strMotorType = $(this).attr("name").slice(-1);
		const nValue = $(this).val();
		_sendCommand({ command: "setMotorPower", type: strMotorType, value: nValue });
	});

	$("[id^=setMotorParameter]").click(function(){
		const strMotorType = $(this).attr("id").slice(-1);
		const nMove         = $("input[name=move" + strMotorType + "]:checked").val();
		const nInitialPps   = $("#motorInitialPps" + strMotorType).val();
		const nAcceleration = $("#motorAcceleration" + strMotorType).val();
		const nMaxPps       = $("#motorMaxPps" + strMotorType).val();
		_sendCommand({ command: "setMotorParameter", type: strMotorType, move: nMove, initialPps: nInitialPps, acceleration: nAcceleration, maxPps: nMaxPps });
	});

	$("[id^=moveMotorDistance]").click(function(){
		const strMotorType = $(this).attr("id").slice(-1);
		const nMove     = $("input[name=move" + strMotorType + "]:checked").val();
		const nExponent = $("#motorExponentDistance" + strMotorType).val();
		const nValue    = $("#motorMoveDistanceValue" + strMotorType).val();
		_sendCommand({ command: "moveMotorDistance", type: strMotorType, move: nMove, exponent: nExponent, value: nValue });
	});

	$("[id^=moveMotorSpeed]").click(function(){
		const strMotorType = $(this).attr("id").slice(-1);
		const nExponent = $("#motorExponentSpeed" + strMotorType).val();
		const nValue    = $("#motorMoveSpeedValue" + strMotorType).val();
		_sendCommand({ command: "moveMotorSpeed", type: strMotorType, exponent: nExponent, value: nValue });
	});

	$("[id^=initializeMotor]").click(function(){
		const strMotorType = $(this).attr("id").slice(-1);
		_sendCommand({ command: "initializeMotor", type: strMotorType });
	});

	$("[id^=getMotorPosition]").click(function(){
		const strMotorType = $(this).attr("id").slice(-1);
		const $motorPositionValue = $("#motorPositionValue" + strMotorType);
		$motorPositionValue.html(strLoadingImg);
		$.getJSON(_getJsonURI(), { command: "getMotorPosition", type: strMotorType })
			.done(data => {
				let strValue = "";
				const bResult = data["result"];
				if (!bResult) {
					strValue = "Error!";
				} else {
					const nN     = data["n"];
					const nValue = data["value"];
					const nPower = Math.pow(10, nN);
					const nPos   = nPower * nValue;
					strValue = nPos;
				}
				$motorPositionValue.html(strValue);
			})
			.fail(() => {
				$motorPositionValue.html("Error!");
				_alertJSONfailed("getMotorPosition");
			})
			.always(() => {
			});
	});
});

}());//即時関数の終端
