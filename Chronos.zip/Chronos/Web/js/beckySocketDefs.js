/*! @file
 * @brief becky のソケットで使用する定数郡
 */
"use strict";

// 送信するJSONには含まれない

const kEye = {
	L: "L",
	R: "R",
	B: "B",
};

// 送信するJSONに含まれる

const kAction = {
	get  : "get"  ,
	set  : "set"  ,
	start: "start",
	stop : "stop" ,
};

const kTarget = {
	base   : "base"   ,
	exam   : "exam"   ,
	optics : "optics" ,
	setting: "setting",
};

const kFunction = {
	acquisition: "acquisition",
	alignment  : "alignment"  ,
	input      : "input"      ,
	maintenance: "maintenance",
	measurement: "measurement",
	output     : "output"     ,
	patient    : "patient"    ,
};

const kOption = {
	acquisition   : "acquisition"   ,
	auto          : "auto"          ,
	condition     : "condition"     ,
	examination   : "examination"   ,
	export        : "export"        ,
	fog           : "fog"           ,
	import        : "import"        ,
	initialization: "initialization",
	manual        : "manual"        ,
	normal        : "normal"        ,
	objective     : "objective"     ,
	progress      : "progress"      ,
	pupil         : "pupil"         ,
	regist        : "regist"        ,
	serviceman    : "serviceman"    ,
	state         : "state"         ,
	subjective    : "subjective"    ,
	track         : "track"         ,
	update        : "update"        ,
	version       : "version"       ,
};

const kType = {
	command: "command",
};
