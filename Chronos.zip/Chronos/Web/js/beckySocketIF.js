/*! @file
 * @brief becky のソケットI/F関数郡
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.Socket = becky.Socket || {};

/*!
 * @brief 送信先 URI を得る
 *
 * @return string 送信先 URI
 */
becky.Socket.getUri = function()
{
	return "../socket/json.php";
}

/*!
 * @brief becky のソケットにJSONデータをポストする
 * 非同期関数
 *
 * @param[in] string aUri 送信先 URI
 * @param[in] array aJson 送信したいJSONデータ
 * @return jqXHR JSON の jqXHR オブジェクト
 */
becky.Socket.ajax = function(aUri, aJson)
{
	if (modelHelper.hasUndefined(aJson)) {
		// 警告を表示する
		alert("undefined found!\n" + JSON.stringify(aJson));
		return null;
	}
	return $.ajax({
		url     : aUri,
		type    : "post",
		dataType: "json",
		data    : JSON.stringify(aJson),
	});
}

/*!
 * @brief エラーとして扱うJSONデータかを判定
 *
 * @param[in] array aRequestJson 判定対象の結果JSON
 * @retval true  エラー
 * @retval false エラーではない
 */
becky.Socket.isFailedJson = function(aResultJson)
{
	if (becky.assertion.isNullOrEmpty(aResultJson) ||
	    becky.assertion.isUndefined(aResultJson.return)) {
		return true;
	}
	return "success" != aResultJson.return;
}

/*!
 * @brief becky のソケットにJSONデータをポストしイベント処理を行う
 * 非同期関数
 *
 * @param[in] array aJson 送信したいJSONデータ
 * @return Promise 
 */
becky.Socket.post = async function(aJson)
{
	return new Promise((resolve, reject) => {
		const uri = becky.Socket.getUri();
		const $json = becky.Socket.ajax(uri, aJson);
		if (becky.assertion.isNullOrEmpty($json)) {
			reject();
			return;
		}
		$json.done(aResultJson => {
			if (becky.Socket.isFailedJson(aResultJson)) {
				reject(aResultJson);
			} else {
				resolve(aResultJson);
			}
		}).fail((jqXHR, textStatus, errorThrown) => {
			reject();
			const lines = ajaxHelper.getFailedArray(jqXHR, textStatus, errorThrown);
			becky.assertion.failure(lines.join(" "));
		});
	});
}
