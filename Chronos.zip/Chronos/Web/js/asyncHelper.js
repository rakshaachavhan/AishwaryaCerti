/*! @file
 * @brief 非同期処理のヘルパー関数郡
 */
"use strict";

// 名前空間
var asyncHelper = asyncHelper || {};

/*!
 * @brief 周期実行する
 *
 * @param[in] int aMS 周期秒数[ミリ秒]
 * @param[in] function aFunc 周期実行する関数
 * @return Promise(拡張)
 * 	stop(): 実行を止める(reject が発生する)
 */
asyncHelper.interval = function(aMS, aFunc)
{
	let funcStop;
	const promise = new Promise((resolve, reject) => {
		if (becky.assertion.isUndefined(aMS) ||
		    becky.assertion.isUndefined(aFunc)) {
			reject();
			return;
		}
		const id = setInterval(aFunc, aMS);
		funcStop = function()
		{
			clearInterval(id);
			reject();
		};
	});
	promise.stop = funcStop;
	return promise;
}

/*!
 * @brief 遅延実行する
 *
 * @param[in] int aMS 遅延秒数[ミリ秒]
 * @return Promise(拡張)
 * 	stop(): 実行を止める(reject が発生する)
 * 	restart(): 再スタートする
 */
asyncHelper.delay = function(aMS)
{
	let funcStop;
	let funcRestart;
	const promise = new Promise((resolve, reject) => {
		if (becky.assertion.isUndefined(aMS)) {
			reject();
			return;
		}
		let id = null;
		const func_setTimeout = function()
		{
			becky.assertion.assert(modelHelper.isNull(id));
			id = setTimeout(resolve, aMS);
		};
		const func_clearTimeout = function()
		{
			if (becky.assertion.isNull(id)) {
				return;
			}
			clearTimeout(id);
			id = null;
		};
		funcStop = function()
		{
			func_clearTimeout();
			reject();
		};
		funcRestart = function()
		{
			func_clearTimeout();
			func_setTimeout();
		};
		func_setTimeout();
	});
	promise.stop    = funcStop;
	promise.restart = funcRestart;
	return promise;
}
