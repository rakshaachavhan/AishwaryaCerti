/*! @file
 * @brief 画面などのヘルパー関数郡
 */
"use strict";

// 名前空間
var viewHelper = viewHelper || {};

/*!
 * @brief 文字列を指定回数分繰り返す
 *
 * @param[in] string aValue 対象の文字列
 * @param[in] integer aCount 繰り返し回数
 * @return string 結果
 */
viewHelper.repeatString = function(aValue, aCount)
{
	if (becky.assertion.isNullOrEmpty(aValue) ||
	    becky.assertion.isUndefined(aCount)) {
		return "";
	}
	let result = "";
	while (0 < aCount) {
		result += aValue;
		--aCount;
	}
	return result;
}

/*!
 * @brief 桁数に満たない場合に 0 を付ける
 * ただし、入力の桁数が指定した桁数以上ならそのまま出力
 *
 * @param[in] object aValue 対象の値
 * @param[in] integer aDigitNumber 桁数
 * @param[in] integer aRadix 底(未指定時は10)
 * @return string 結果
 */
viewHelper.zeroPadding = function(aValue, aDigitNumber, aRadix)
{
	if (!aValue) {
		return viewHelper.repeatString("0", aDigitNumber);
	}
	if (modelHelper.isUndefined(aRadix)) {
		aRadix = 10;
	}
	const strVal = aValue.toString(aRadix);
	if (strVal.length >= aDigitNumber) {
		return strVal;
	}
	const prefix = viewHelper.repeatString("0", aDigitNumber - 1);
	const result = (prefix + strVal).slice(-aDigitNumber);
	return result;
}

/*!
 * @brief Dateを文字列の日付にする
 *
 * @param[in] Date aDate 入力
 * @param[in] string aSeparator セパレータ
 * @return string 変換後の文字列
 */
viewHelper.getStrDate = function(aDate, aSeparator)
{
	if (becky.assertion.isNull(aDate) ||
	    becky.assertion.isFalse(aDate instanceof Date)) {
		return "";
	}
	if (modelHelper.isUndefined(aSeparator)) {
		aSeparator = "-";
	}
	return [
		aDate.getFullYear(),
	].concat([
		aDate.getMonth() + 1,
		aDate.getDate ()    ,
	].map(_value => {
		return viewHelper.zeroPadding(_value, 2);
	})).join(aSeparator);
}

/*!
 * @brief Dateを文字列の時間にする
 *
 * @param[in] Date aDate 入力
 * @param[in] string aSeparator セパレータ
 * @return string 変換後の文字列
 */
viewHelper.getStrTime = function(aDate, aSeparator)
{
	if (becky.assertion.isNull(aDate) ||
	    becky.assertion.isFalse(aDate instanceof Date)) {
		return "";
	}
	if (modelHelper.isUndefined(aSeparator)) {
		aSeparator = ":";
	}
	return [
		aDate.getHours  (),
		aDate.getMinutes(),
		aDate.getSeconds(),
	].map(_value => {
		return viewHelper.zeroPadding(_value, 2);
	}).join(aSeparator);
}

/*!
 * @brief disabled属性を付加(もしくは取り除く)
 * disabled属性が付加された入力フィールドは
 * 灰色っぽい色になりフォーカスもセットできなくなる
 *
 * @param[in,out] selector $objThis 対象のセレクタ
 * @param[in] bool aIsDisabled 付加/除去
 * @return void
 */
viewHelper.setAttDisabled = function($objThis, aIsDisabled)
{
	if (becky.assertion.isNullOrEmpty($objThis)) {
		return;
	}
	if (modelHelper.isUndefined(aIsDisabled)) {
		aIsDisabled = true;
	}
	$objThis.prop("disabled", aIsDisabled);
}

/*!
 * @brief visibilityスタイルを設定
 * visibilityの大きな特徴として、
 * 表示/非表示でも位置や大きさは変化しないという点である
 *
 * @param[in,out] selector $objThis 対象のセレクタ
 * @param[in] bool aEnabled 有効/無効
 * @return void
 */
viewHelper.setVisibility = function($objThis, aEnabled)
{
	if (becky.assertion.isNullOrEmpty($objThis)) {
		return;
	}
	let v_val = "";
	if (aEnabled) {
		v_val = "visible";
	} else {
		v_val = "hidden";
	}
	$objThis.css("visibility", v_val);
}

/*!
 * @brief jQueryUIのボタンの有効/無効の切り替え
 *
 * @param[in,out] selector $btn 対象のセレクタ
 * @param[in] bool aEnabled 有効/無効
 * @return void
 */
viewHelper.setEnableButtonJQUI = function($btn, aEnabled)
{
	if (becky.assertion.isNullOrEmpty($btn)) {
		return;
	}
	if (aEnabled) {
		$btn.button("enable");
	} else {
		$btn.button("disable");
		// フォーカスが残ったままになるので対応
		$btn.removeClass("ui-state-hover");
	}
}

/*!
 * @brief 対象の<form>に<input>タグを追加
 * <input type="hidden" name="?" value="?">を追加
 *
 * @param[in] string aAttName 属性名
 * @param[in] string aAttValue 属性値
 * @param[in,out] selector $targetForm 対象のセレクタ
 * @return void
 */
viewHelper.appendInputHiddenValue = function(aAttName, aAttValue, $targetForm)
{
	if (modelHelper.isUndefined(aAttValue)) {
		return;
	}
	$("<input/>").attr({
		type : "hidden",
		name : aAttName,
		value: aAttValue
	}).appendTo($targetForm);
}

/*!
 * @brief 対象の<form>に<input>タグを複数追加
 * <input type="hidden" name="?" value="?">を複数追加
 *
 * @param[in] string aAttName 属性名
 * @param[in] array aAttValues 属性値リスト
 * @param[in,out] selector $targetForm 対象のセレクタ
 * @return void
 */
viewHelper.appendInputHiddenValues = function(aAttName, aAttValues, $targetForm)
{
	if (becky.assertion.isNullOrEmpty(aAttValues)) {
		return;
	}
	aAttValues.forEach(val => {
		viewHelper.appendInputHiddenValue(aAttName, val, $targetForm);
	});
}

/*!
 * @brief <img> 画像のリロードを促す
 * 単純にURLにパラメータを付加してブラウザから違う画像だと認識させる
 *
 * @param[in,out] selector $img 対象の画像
 */
viewHelper.reloadImg = function($img)
{
	if (becky.assertion.isNullOrEmpty($img)) {
		return;
	}
	$img.each((i, element) => {
		let url = $(element).attr("src");
		const posQ = url.indexOf("?");
		if (0 <= posQ) {
			url = url.slice(0, posQ);
		}
		const dateNow = new Date();
		url += "?" + viewHelper.getStrDate(dateNow, "") + viewHelper.getStrTime(dateNow, "");
		$(element).attr("src", url);
	});
}

/*!
 * @brief 指定したクラスを単一設定する
 * ラジオボタンのように同じグループで1つだけ設定される
 *
 * @param[in] string aClassName メッセージの定義名
 * @param[in,out] selector $target 対象
 */
viewHelper.selectClassSingle = function(aClassName, $target)
{
	if (becky.assertion.isFalse(1 === $target.length)) {
		return;
	}
	// 自身に aClassName を追加し、兄弟の aClassName を除去
	$target.addClass(aClassName).siblings().removeClass(aClassName);
}

/*!
 * @brief タッチの開始終了のイベント処理を登録する
 *
 * @param[in,out] selector $target 対象
 * @param[in] function aFuncDown タッチ開始で呼び出したい関数
 * @param[in] function aFuncUp タッチ終了で呼び出したい関数
 * @return void
 */
viewHelper.eventRegistrationTouchDownUp = function($target, aFuncDown, aFuncUp)
{
	if (becky.assertion.isNullOrEmpty($target)) {
		return;
	}
	const bindParam = {};
	if (!modelHelper.isUndefined(aFuncDown)) {
		bindParam['touchstart mousedown'] = aFuncDown;
	}
	if (!modelHelper.isUndefined(aFuncUp)) {
		bindParam['touchend mouseup'] = aFuncUp;
	}
	$target.bind(bindParam);
}

/*!
 * @brief メッセージの定義リストから文字列を得る
 *
 * @param[in] string aKey メッセージの定義名
 * @return string メッセージ文字列
 */
viewHelper.getDefMessage = function(aKey)
{
	if (becky.assertion.isNullOrEmpty(aKey)) {
		return "";
	}
	const $list_message = $("#list_message");
	if (becky.assertion.isNullOrEmpty($list_message)) {
		return "";
	}
	const $dt = $list_message.children(":contains(" + aKey + ")");
	if (becky.assertion.isNullOrEmpty($dt)) {
		return "";
	}
	const $dd = $dt.next();
	if (becky.assertion.isNullOrEmpty($dd)) {
		return "";
	}
	const msg = $dd.html();
	return msg;
}
