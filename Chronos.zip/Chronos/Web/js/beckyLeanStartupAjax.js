/*! @file
 * @brief becky の Lean startup Ajax 関数郡
 *
 * 依存するもの
 * - beckyAsyncAjax.js
 * - beckyWebStorageIO.js
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.LeanStartup = becky.LeanStartup || {};

/*!
 * @brief 送信先 URI を得る
 *
 * @param[in] string aPostPos 送信先(指定しない場合はL/R両方)
 * @return string 送信先 URI
 */
becky.LeanStartup.getUri = function(aPostPos)
{
	if (modelHelper.isUndefined(aPostPos)) {
		aPostPos = "";
	}
	return "../ls/jsonDistributor" + aPostPos + ".php";
}

/*!
 * @brief JSONデータをポストする
 * 非同期関数
 *
 * @param[in] string aUri 送信先 URI
 * @param[in] array aJson 送信したいJSONデータ
 * @return Promise
 */
becky.LeanStartup.ajax = async function(aUri, aJson)
{
	if (modelHelper.hasUndefined(aJson)) {
		// 警告を表示する
		becky.assertion.failure("undefined found!\n" + JSON.stringify(aJson));
	}
	return becky.async.ajax({
		url     : aUri,
		cache   : false,
		type    : "post",
		dataType: "json",
		data    : JSON.stringify(aJson),
	});
}

/*!
 * @brief エラーとして扱うJSONデータかを判定
 *
 * @param[in] array aRequestJson 判定対象の結果JSON
 * @retval true  エラー
 * @retval false エラーではない
 */
becky.LeanStartup.isFailedJson = function(aResultJson)
{
	if (becky.assertion.isNullOrEmpty(aResultJson) ||
	    becky.assertion.isUndefined(aResultJson.return)) {
		return true;
	}
	return !aResultJson.return;
}

/*!
 * @brief JSONデータをポストしイベント処理を行う
 * 非同期関数
 *
 * @param[in] array aCommand コマンド名
 * @param[in] array aJson 送信したいJSONデータ
 * @param[in] string aPostPos 送信先(指定しない場合はL/R両方)
 * @return Promise 
 */
becky.LeanStartup.post = async function(aCommand, aJson, aPostPos)
{
	return new Promise((resolve, reject) => {
		const uri = becky.LeanStartup.getUri(aPostPos);
		const json = { command: aCommand, };
		if (!modelHelper.isUndefined(aJson)) {
			json.json = aJson;
		}
		becky.LeanStartup.ajax(uri, json).then(resultJson => {
			becky.debug.scope(() => {
				const webStorageDebugCommandLog = becky.WebStorage.local.IO("debug.log.command");
				const debugCommandLogJson = webStorageDebugCommandLog.getJson();
				debugCommandLogJson.values.push({command:aCommand,json:aJson,result:resultJson});
				webStorageDebugCommandLog.setJson(debugCommandLogJson);
			});
			if (becky.LeanStartup.isFailedJson(resultJson)) {
				if (becky.assertion.isNullOrEmpty(resultJson)) {
					resultJson = {};
				}
				// 失敗したコマンド名を付加
				resultJson.command = aCommand;
				reject(resultJson);
			} else {
				resolve(resultJson);
			}
		}).catch(ex => {
			becky.debug.scope(() => {
				const webStorageDebugCommandLog = becky.WebStorage.local.IO("debug.log.command");
				const debugCommandLogJson = webStorageDebugCommandLog.getJson();
				debugCommandLogJson.values.push({command:aCommand,json:aJson,result:becky.LeanStartup.getErrorMessage(ex)});
				webStorageDebugCommandLog.setJson(debugCommandLogJson);
			});
			reject(ex);
		});
	});
}

/*!
 * @brief JSONデータをポストしイベント処理を行い、操作ログのノードに情報を追加する
 * 非同期関数
 *
 * @param[in] string aCommand コマンド名
 * @param[in] object aJson 送信したいJSONデータ
 * @param[in] string aPostPos 送信先(指定しない場合はL/R両方)
 * @param[in] Date aDate コマンドの開始となる日付(操作ログ記録用)
 * @param[out] array aAdditionalTargetArray 操作ログのノードの追加先配列(操作ログ記録用)
 * @return Promise 
 */
becky.LeanStartup.postWithOperatorLog = async function(aCommand, aJson, aPostPos, aDate, aAdditionalTargetArray)
{
	const operatorLogNode = becky.operatorLog.createBaseNode();
	aAdditionalTargetArray.push(operatorLogNode);
	operatorLogNode.date.first = aDate;
	operatorLogNode.name = aCommand;
	operatorLogNode.private.param = aJson;
	try {
		const resultJson = await becky.LeanStartup.post(aCommand, aJson, aPostPos);
		operatorLogNode.private.result = resultJson;
		return resultJson;
	} catch (resultJson) {
		if (!modelHelper.isUndefined(resultJson)) {
			if (modelHelper.isUndefined(resultJson.return)) {
				// jQuery のエラー
				operatorLogNode.private.result = becky.LeanStartup.getErrorMessage(resultJson);
			} else {
				// becky のエラー
				operatorLogNode.private.result = resultJson;
			}
		}
		// エラーを揉み消してしまわない様に、例外を再度投げる
		throw resultJson;
	} finally {
		operatorLogNode.date.last = new Date();
	}
}

/*!
 * @brief エラーメッセージを得る(ユーザー向け)
 *
 * @param[in] array aResultJson becky.LeanStartup.post が返したJson
 * @return string
 */
becky.LeanStartup.getErrorMessage = function(aResultJson)
{
	const messages = [];
	if (!modelHelper.isUndefined(aResultJson)) {
		if (modelHelper.isUndefined(aResultJson.return)) {
			// jQuery のエラー
			const jqXHR       = aResultJson[0];
			const textStatus  = aResultJson[1];
			const errorThrown = aResultJson[2];
			const lines = ajaxHelper.getFailedArray(jqXHR, textStatus, errorThrown);
			return lines.join(" ").trim();
		} else {
			// becky のエラー
			if (!becky.assertion.isUndefined(aResultJson.command)) {
				// コマンド名
				messages.push(aResultJson.command);
			}
			["L", "R"].forEach(_pos => {
				if (!becky.assertion.isUndefined(aResultJson[_pos])) {
					const resultSingle = aResultJson[_pos];
					if (modelHelper.isUndefined(resultSingle.error)) {
						return;
					}
					becky.assertion.assert(false === resultSingle.return);
					// ユーザ向けメッセージ
					if (Array.isArray(resultSingle.error)) {
						// 複数
						resultSingle.error.forEach(_once => messages.push(_pos + ":" + _once.messageForUser));
					} else {
						// 単一
						messages.push(_pos + ":" + resultSingle.error.messageForUser);
					}
				}
			});
		}
	}
	messages.unshift("Error!");
	return messages.join("\n").trim();
}

/*!
 * @brief エラーメッセージを表示する(ユーザー向け)
 *
 * @param[in] array aResultJson becky.LeanStartup.post が返したJson
 * @return void
 */
becky.LeanStartup.alertErrorMessage = function(aResultJson)
{
	alert(becky.LeanStartup.getErrorMessage(aResultJson));
}
