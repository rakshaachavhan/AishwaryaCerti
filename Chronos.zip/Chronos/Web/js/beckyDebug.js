/*! @file
 * @brief becky の デバッグ 向け
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.debug = becky.debug || {};

/*!
 * @brief デバッグのスコープ
 * デバッグ用コードという事が分かり易くなるだけ
 *
 * @param[in] function aFunc デバッグで実行したい処理
 * @return void
 */
becky.debug.scope = function(aFunc)
{
	if (becky.assertion.isUndefined(aFunc)) {
		return;
	}
	try {
		aFunc();
	} catch (ex) {
		console.log(ex);
	}
}
