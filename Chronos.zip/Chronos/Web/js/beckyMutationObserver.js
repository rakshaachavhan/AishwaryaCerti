/*! @file
 * @brief DOM の変更を検知する
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.MutationObserver = becky.MutationObserver || {};

/*!
 * @brief DOM の変更を検知(ノード指定)
 *
 * @param[in] Node aNode 対象のノード
 * @param[in] function aFuncChanged 変更時に呼び出す関数
 * @param[in] MutationObserverInit aOptions 監視オプション
 * @return MutationObserver DOM の変更を検知するオブザーバー
 */
becky.MutationObserver.byNode = function(aNode, aFuncChanged, aOptions)
{
	if (becky.assertion.isFalse      (aNode instanceof Node) ||
	    becky.assertion.isNull       (aFuncChanged) ||
	    becky.assertion.isNullOrEmpty(aOptions)) {
		return null;
	}
	const mutationObserver = new MutationObserver(aFuncChanged);
	mutationObserver.observe(aNode, aOptions);
	return mutationObserver;
}

/*!
 * @brief DOM の変更を検知(ノードリスト指定)
 *
 * @param[in] NodeList aNodeList 対象のノードリスト
 * @param[in] function aFuncChanged 変更時に呼び出す関数
 * @param[in] MutationObserverInit aOptions 監視オプション
 * @return MutationObserver DOM の変更を検知するオブザーバー
 */
becky.MutationObserver.byNodeList = function(aNodeList, aFuncChanged, aOptions)
{
	if (becky.assertion.isNullOrEmpty(aNodeList) ||
	    becky.assertion.isNull       (aFuncChanged) ||
	    becky.assertion.isNullOrEmpty(aOptions)) {
		return null;
	}
	const mutationObserver = new MutationObserver(aFuncChanged);
	aNodeList.forEach(_node => {
		mutationObserver.observe(_node, aOptions);
	});
	return mutationObserver;
}

/*!
 * @brief DOM の変更を検知(ID指定)
 *
 * @param[in] string aID 対象のID
 * @param[in] function aFuncChanged 変更時に呼び出す関数
 * @param[in] MutationObserverInit aOptions 監視オプション
 * @return MutationObserver DOM の変更を検知するオブザーバー
 */
becky.MutationObserver.byID = function(aID, aFuncChanged, aOptions)
{
	if (becky.assertion.isNullOrEmpty(aID) ||
	    becky.assertion.isNull       (aFuncChanged) ||
	    becky.assertion.isNullOrEmpty(aOptions)) {
		return null;
	}
	if (aID.startsWith("#")) {
		// CSSセレクタと違い"#"は不要
		aID = aID.slice(1);
	}
	const node = document.getElementById(aID);
	return becky.MutationObserver.byNode(node, aFuncChanged, aOptions);
}

/*!
 * @brief DOM の変更を検知(CSSセレクタ指定)
 *
 * @param[in] string aSelectors 対象のCSSセレクタ
 * @param[in] function aFuncChanged 変更時に呼び出す関数
 * @param[in] MutationObserverInit aOptions 監視オプション
 * @return MutationObserver DOM の変更を検知するオブザーバー
 */
becky.MutationObserver.bySelectorAll = function(aSelectors, aFuncChanged, aOptions)
{
	if (becky.assertion.isNullOrEmpty(aSelectors) ||
	    becky.assertion.isNull       (aFuncChanged) ||
	    becky.assertion.isNullOrEmpty(aOptions)) {
		return null;
	}
	const nodeList = document.querySelectorAll(aSelectors);
	return becky.MutationObserver.byNodeList(nodeList, aFuncChanged, aOptions);
}
