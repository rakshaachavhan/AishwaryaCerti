/*! @file
 * @brief becky のアサーション
 *
 * 依存するもの
 * - modelHelper.js
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.assertion = becky.assertion || {};

/*!
 * @brief assert
 *
 * @param[in] bool aAssertion 評価式
 * @param[in] object aObjN アサート時に表示するもの(可変長引数)
 * @return void
 */
becky.assertion.assert = function(aAssertion, ...aObjN)
{
	// 現状ラップしただけ
	console.assert(aAssertion, aObjN);
}

/*!
 * @brief assert 常にアサーション
 *
 * @param[in] object aObjN アサートで表示するもの(可変長引数)
 * @return void
 */
becky.assertion.failure = function(...aObjN)
{
	// 常にアサーション
	console.assert(false, aObjN);
}

/*!
 * @brief 無効か判定
 * 通常とは異なり、結果が true になった時にアサーションが発生
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
becky.assertion.isNull = function(aObj)
{
	const result = modelHelper.isNull(aObj);
	if (result) {
		console.assert(false, "becky.assertion.isNull");
	}
	return result;
}

/*!
 * @brief 無効もしくは要素が空か判定
 * 通常とは異なり、結果が true になった時にアサーションが発生
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
becky.assertion.isNullOrEmpty = function(aObj)
{
	const result = modelHelper.isNullOrEmpty(aObj);
	if (result) {
		console.assert(false, "becky.assertion.isNullOrEmpty");
	}
	return result;
}

/*!
 * @brief undefined か判定
 * 通常とは異なり、結果が true になった時にアサーションが発生
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
becky.assertion.isUndefined = function(aObj)
{
	const result = modelHelper.isUndefined(aObj);
	if (result) {
		console.assert(false, "becky.assertion.isUndefined");
	}
	return result;
}

/*!
 * @brief undefined を含んでいるか判定
 * 通常とは異なり、結果が true になった時にアサーションが発生
 *
 * @param[in] object aObj 調査対象
 * @return bool 判定結果
 */
becky.assertion.hasUndefined = function(aObj)
{
	const result = modelHelper.hasUndefined(aObj);
	if (result) {
		console.assert(false, "becky.assertion.hasUndefined");
	}
	return result;
}

/*!
 * @brief true か判定
 * 通常とは異なり、評価式が true になった時にアサーションが発生
 *
 * @param[in] bool aValue 評価式
 * @return bool 判定結果
 */
becky.assertion.isTrue = function(aValue)
{
	console.assert("boolean" === (typeof aValue), "aValue is not boolean");
	if (aValue) {
		console.assert(false, "becky.assertion.isTrue");
	}
	return aValue;
}

/*!
 * @brief false か判定
 * 通常通り、評価式が false になった時にアサーションが発生
 *
 * @param[in] bool aValue 評価式
 * @return bool 判定結果
 */
becky.assertion.isFalse = function(aValue)
{
	console.assert("boolean" === (typeof aValue), "aValue is not boolean");
	if (!aValue) {
		console.assert(false, "becky.assertion.isFalse");
	}
	return !aValue;
}
