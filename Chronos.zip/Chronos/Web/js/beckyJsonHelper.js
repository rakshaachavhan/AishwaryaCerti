/*! @file
 * @brief JSONのヘルパー関数郡
 */
"use strict";

// 名前空間
var becky = becky || {};
becky.jsonHelper = becky.jsonHelper || {};

/*!
 * @brief Jsonデータをキー名でソートする
 *
 * @param[in] object aJson 対象となるJson
 * @return object ソート済みJson
 */
becky.jsonHelper.sortByKey = function(aJson)
{
	const sortedJson = {};
	Object.getOwnPropertyNames(aJson).sort().forEach((propertyName) => {
		const propertyValue = aJson[propertyName];
		if (modelHelper.isObject(propertyValue)) {
			// 再帰的に処理を進める
			sortedJson[propertyName] = becky.jsonHelper.sortByKey(propertyValue);
		} else {
			sortedJson[propertyName] = propertyValue;
		}
	});
	return sortedJson;
}

/*!
 * @brief Jsonデータの比較
 *
 * @param[in] object aJson1 比較対象となるJson
 * @param[in] object aJson2 比較対象となるJson
 * @retval  true 等しい
 * @retval false 等しくない
 */
becky.jsonHelper.isEquals = function(aJson1, aJson2)
{
	const sortedJson1 = becky.jsonHelper.sortByKey(aJson1);
	const sortedJson2 = becky.jsonHelper.sortByKey(aJson2);
	return JSON.stringify(sortedJson1) === JSON.stringify(sortedJson2);
}

/*!
 * @brief Jsonデータの正規化
 *
 * @param[in,out] object aJson 正規化の対象となるJson
 * @param[in] array aExclusionKeys 除外するキー郡(optional)
 * @return void
 */
becky.jsonHelper.normalization = function(aJson, aExclusionKeys)
{
	Object.getOwnPropertyNames(aJson).forEach((propertyName) => {
		if (!modelHelper.isUndefined(aExclusionKeys) &&
		    0 <= aExclusionKeys.indexOf(propertyName)) {
			// 除外対象
			return;
		}
		const propertyValue = aJson[propertyName];
		if (becky.assertion.isUndefined(propertyValue)) {
			return;
		}
		if (modelHelper.isObject(propertyValue)) {
			// 再帰的に処理を進める
			becky.jsonHelper.normalization(propertyValue, aExclusionKeys);
		} else {
			if (modelHelper.isString(propertyValue)) {
				// 文字列の"false", "true"を論理型に変換
				{
					const propertyValueLowerCase = propertyValue.toLowerCase();
					switch (propertyValueLowerCase) {
						case "false":
						case  "true":
							aJson[propertyName] = modelHelper.toBoolean(propertyValueLowerCase);
							return;
						default:
							break;
					}
				}
				// 文字列の数値を整数・実数に変換
				if (/^-?([1-9][0-9]*|0)(\.[0-9]+)?$/.test(propertyValue)) {
					const fValue = parseFloat(propertyValue);
					if (!isNaN(fValue)) {
						aJson[propertyName] = fValue;
						return;
					}
				}
			}
		}
	});
}
