<?php

require_once '../models/app.php';

init('sub/' . basename(__FILE__));

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8" />
		<meta name="format-detection" content="telephone=no" />
		<title></title>
	</head>

	<body>
		<script>
		</script>

		<header>
		</header>

		<img src="<?php echo topUri() . 'contents/stream/getStream.php' ?>" width="64" height="64" />
		<img src="<?php echo topUri() . 'contents/stream/getStream.php' ?>" width="64" height="64" />

		<footer></footer>
	</body>
</html>
