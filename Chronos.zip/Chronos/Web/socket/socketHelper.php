<?php
/*! @file
 * @brief becky 外部入出力のソケット通信を行うヘルパー関数
 */

namespace becky;

/*!
 * @brief ソケットを作る
 *
 * @param[in] string $ipAdress 接続先の IP アドレス
 * @param[in] integer $port 接続ポート
 * @return resource ストリームリソース
 */
function _createSocket($ipAdress, $port)
{
	return @stream_socket_client('tcp://' . $ipAdress . ':' . $port);
}

/*!
 * @brief 文字列を送信する
 *
 * @param[in] resource $socket ストリームリソース
 * @param[in] string $value 送信文字列
 * @return boolean 成功/失敗
 */
function _sendString($socket, $value)
{
	$valueSize = strlen($value);
	if (0xFFFF < $valueSize) {
		// サイズオーバー
		return false;
	}

	// 'n' = unsigned short ビッグエンディアン
	$valueReserveBin = pack('n',          0); // Reserve(2byte)
	$valueSizeBin    = pack('n', $valueSize);
	$valueBin = $valueReserveBin . $valueSizeBin;
	if (false === fwrite($socket, $valueBin, 4)) {
		return false;
	}

	if (false === fwrite($socket, $value, $valueSize)) {
		return false;
	}

	return true;
}

/*!
 * @brief 文字列を受信する
 *
 * @param[in] resource $socket ストリームリソース
 * @return string|boolean 受信文字列(エラー時はfalse)
 */
function _recvString($socket)
{
	$resultStringSizeBin = fread($socket, 4);
	if (false === $resultStringSizeBin) {
		return false;
	}

	// 'n' = unsigned short ビッグエンディアン
	$arrayReserveAndSize = unpack('n2', $resultStringSizeBin);
	//$resultReserve    = $arrayReserveAndSize[1]; Reserve に値が入っていた場合はどうすべき？
	$resultStringSize = $arrayReserveAndSize[2];
	if (0 === $resultStringSize) {
		// データ長が0
		return false;
	}

	$resultString = fread($socket, $resultStringSize);
	if (false === $resultString) {
		return false;
	}

	return $resultString;
}

/*!
 * @brief 文字列を送受信する
 *
 * @param[in] resource $socket ストリームリソース
 * @param[in] string $value 送信文字列
 * @return string|boolean 受信文字列(エラー時はfalse)
 */
function _sendRecvString($socket, $value)
{
	if (false === _sendString($socket, $value)) {
		return false;
	}

	$resultString = _recvString($socket);
	if (false === $resultString) {
		return false;
	}

	return $resultString;
}

/*!
 * @brief IP アドレスとポートを指定し、文字列を送受信する
 *
 * @param[in] string $ipAdress 接続先の IP アドレス
 * @param[in] integer $port 接続ポート
 * @param[in] string $value 送信文字列
 * @return string|boolean 受信文字列(エラー時はfalse)
 */
function postSocketString($ipAdress, $port, $value)
{
	$socket = _createSocket($ipAdress, $port);
	if (!$socket) {
		return false;
	}
	stream_set_blocking($socket, true);

	$resultString = _sendRecvString($socket, $value);

	fclose($socket);

	return $resultString;
}
