<?php

require_once '../models/app.php';

init('socket/' . basename(__FILE__));

require_once topDir() . 'defs/defData.php';
require_once topDir() . 'views/jsonHelper.php';
require_once topDir() . 'socket/socketHelper.php';

const SOCKET_IP_ADRESS = PrivateIpAdress::Bino;
const SOCKET_PORT      = Maestro2Protocol::Port;

$jsonString = file_get_contents('php://input');

$resultString = becky\postSocketString(SOCKET_IP_ADRESS, SOCKET_PORT, $jsonString);
if (!$resultString) {
	// 接続先のサーバが無効
	http_response_code(500);
	exit;
}

$resultJson = json_decode($resultString, true);

header('Content-Type: application/json; charset=utf-8');

// JSON 文字列化とエスケープ
echo json_encode_and_escape($resultJson);
