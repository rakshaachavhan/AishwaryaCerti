<?php
/*! @file
 * @brief ファイルパスなどのユーティリティ
 */

namespace becky\Path;

/*!
 * @brief ファイル名を連結
 * 末尾のパス区切り文字は除去される
 *
 * @param[in] array 連携させたい文字列(可変長引数)
 * @return string 連結後のパス
 */
function combine()
{
	$hasSlash = false;
	$hasBackSlash = false;
	$first = true;
	$paths = func_get_args();
	// パスを集計
	foreach ($paths as &$path) {
		if (!$hasSlash && false !== strpos($path, '/')) {
			$hasSlash = true;
		}
		if (!$hasBackSlash && false !== strpos($path, '\\')) {
			$hasBackSlash = true;
		}
		$path = $first ? rtrim($path, '\\/') : trim($path, '\\/');
		$first = false;
	}
	// 区切り文字を決定
	$separateDir = '';
	if ($hasBackSlash) {
		$separateDir = '\\';
	} elseif ($hasSlash) {
		$separateDir = '/';
	} else {
		$separateDir = DIRECTORY_SEPARATOR;
	}
	// パス連結
	return implode($separateDir, $paths);
}
