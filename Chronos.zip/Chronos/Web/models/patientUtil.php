<?php
/*! @file
 * @brief 患者に関するユーティリティ
 */

namespace becky\Patient;

/*!
 * @brief セッション患者IDへ変換する
 *
 * @param[in] string $patientID 患者ID
 * @param[in] string $sessionTime セッション時間
 * @return string セッション患者ID
 */
function toSessionPatientID($patientID, $sessionTime)
{
	$sessionPatientID = $patientID;
	if ('' === $sessionPatientID) {
		$sessionPatientID = 'empty' . $sessionTime;
	} else {
		// ファイルパスとして保存可能にする
		$sessionPatientID = urlencode($sessionPatientID);
	}
	return $sessionPatientID;
}
