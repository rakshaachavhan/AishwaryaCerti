<?php
/*! @file
 * @brief ファームウェア画面の中身
 */

//require_once topDir() . 'views/_tags.php';
require_once topDir() . 'views/messageHelper.php';
//require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/firmware/_head.php';
//require_once topDir() . 'contents/firmware/_viewLogic.php';
require_once topDir() . 'defs/defData.php';
require_once topDir() . 'socket/socketHelper.php';

$ipAdress = PrivateIpAdress::Bino;
$port = 19200;

$json = [
	'action' => 'get',
	'target' => 'setting',
	'function' => 'maintenance',
	'param' => [
		'option' => 'version',
	],
	'type' => 'command',
];
$jsonString = json_encode($json);

$resultJsonString = becky\postSocketString($ipAdress, $port, $jsonString);
if (false === $resultJsonString) {
	$_SESSION['error'] = [
		'redirectUri'  => topUri() . 'sub/firmware.php',
	//	'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'failed to get version information.',
	];
	header("Location: " . topUri() . 'sub/error.php');
	return;
}
$resultJson = json_decode($resultJsonString, true);
if (null === $resultJson) {
	$arrayParamInfo = [];
} else {
	$arrayParamInfo = $resultJson['param']['info'];
}

?>
<!DOCTYPE html>
<html>
	<head>
		<?php outputHeadContents(); ?>
		<title><?php echo _m('firmware', 'title'); ?></title>
	</head>

	<body>
		<!-- メッセージの定義リスト(JavaScript向け) -->
		<dl id="list_message" style="display: none;">
			<?php
				echoListMessageItem('firmware', 'updating');
				echoListMessageItem('firmware', 'updateFinished');
				echoListMessageItem('firmware', 'errorAccessUSBmemory');
				echoListMessageItem('firmware', 'errorNotFindUpdateFiles');
				echoListMessageItem('firmware', 'errorExpandTarFileForControlBox');
				echoListMessageItem('firmware', 'errorExpandTarFileForCaptureMeasurementMain');
				echoListMessageItem('firmware', 'errorInternalExternalIO');
				echoListMessageItem('firmware', 'errorUpdateRootAppOnTheRightCaptureMeasurementMain');
				echoListMessageItem('firmware', 'errorUpdateBootAppOnTheRightCaptureMeasurementMain');
				echoListMessageItem('firmware', 'errorUpdateOptFwOnTheRightCaptureMeasurementMain');
				echoListMessageItem('firmware', 'errorUpdateBaseFwOnTheRightCaptureMeasurementMain');
				echoListMessageItem('firmware', 'errorUpdateRootAppOnTheLeftCaptureMeasurementMain');
				echoListMessageItem('firmware', 'errorUpdateBootAppOnTheLeftCaptureMeasurementMain');
				echoListMessageItem('firmware', 'errorUpdateOptFwOnTheLeftCaptureMeasurementMain');
				echoListMessageItem('firmware', 'errorUpdateBaseFwOnTheLeftCaptureMeasurementMain');
				echoListMessageItem('firmware', 'errorUpdateRootAppOnTheControlBox');
				echoListMessageItem('firmware', 'errorUpdateBootAppOnTheControlBox');
				echoListMessageItem('firmware', 'errorUpdatePicFwOnTheControlBox');
			?>
		</dl>

		<header>
			<h1><?php echo _m('firmware', 'title'); ?></h1>
		</header>

		<div id="main">
			<div class="horizontal-center">
				<input type="button" value="<?php echo _m('firmware', 'update'); ?>" id="btnUpdate" disabled>
			</div>
			<div class="progress" id="progressUpdate">
				<div class="progress-value" id="labelUpdateValue" data-text="" data-suffix="%"></div>
			</div>
			<div class="message" id="labelUpdateMessage"></div>
			<div class="fieldset">
				<fieldset>
					<div class="legend">Current Version</div>
					<div>
						<div class="list-header">Opt Version</div>
						<div class="list-value" ><?php echo $arrayParamInfo['optversion']; ?></div>
					</div>
					<div>
						<div class="list-header">Base Version</div>
						<div class="list-value" ><?php echo $arrayParamInfo['baseversion']; ?></div>
					</div>
					<div>
						<div class="list-header">Pic Version</div>
						<div class="list-value" ><?php echo $arrayParamInfo['picversion']; ?></div>
					</div>
					<div>
						<div class="list-header">MasterApp Version</div>
						<div class="list-value" ><?php echo $arrayParamInfo['masterappversion']; ?></div>
					</div>
					<div>
						<div class="list-header">Slaveapp Version</div>
						<div class="list-value" ><?php echo $arrayParamInfo['slaveappversion']; ?></div>
					</div>
				</fieldset>
			</div>
		</div>

		<footer>
			<div class="error-message" id="labelErrorMessage"><?php if (empty($arrayParamInfo)) echo $resultJsonString; ?></div>
		</footer>
	</body>
</html>
