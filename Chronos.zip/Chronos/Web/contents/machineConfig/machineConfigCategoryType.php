<?php
/*! @file
 * @brief 機器設定向けのカテゴリクラス定義
 */

namespace machineConfig;

/*!
 * @brief カテゴリ enum
 */
final class CategoryType
{
	const REGION        = 'region';            //!< @brief 地域
	const OBJECTIVE     = 'objective';         //!< @brief 他覚
	const SUBJECTIVE    = 'subjective';        //!< @brief 自覚
}
