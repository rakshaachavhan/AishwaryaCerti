<?php
/*! @file
 * @brief 工場設定画面の保存や復元などを行う関数群
 */

require_once topDir() . 'models/fileUtil.php';
//require_once topDir() . 'contents/factoryConfig/factoryConfigCategoryType.php';
require_once topDir() . 'contents/factoryConfig/_factoryConfigUtil.php';

/*!
 * @brief 設定ファイルのパスを得る
 *
 * @param[in] string $filePrefix ファイルの接頭語
 * @return string 設定ファイルのパス
 */
function _getSettingFilePath()
{
	return topDir() . 'contents/settings/factory.setting.json';
}

/*!
 * @brief 工場設定を保存する
 * 複数のファイルへ保存
 *
 * @param[in] array $elements 工場設定要素郡
 * @return bool 成功可否
 *
 * @global array $_POST                       この連想配列に記録されている工場設定を保存する
 */
function doRegisterFactoryConfig(array $elements)
{
	$jsonData = [];
	foreach ($elements as $element) {
		$name        = getName       ($element);
		$controlType = getControlType($element);

		if ('modelEyeAlignmentMode' === $name) {
			// 模型眼アライメントモード
			// 設定ファイルには保存せずに WebStorage に保存
			continue;
		}

		$postValue = $_POST[$name];

		switch ($controlType) {
			case \becky\ControlType::FIELDSET_BEGIN:
			case \becky\ControlType::FIELDSET_END:
			case \becky\ControlType::HEADING:
			case \becky\ControlType::BUTTON:
				continue;
			case \becky\ControlType::RADIO:
			case \becky\ControlType::DROPDOWN_LIST:
			case \becky\ControlType::EDIT_BOX:
			case \becky\ControlType::EDIT_TIME:
				break;
			case \becky\ControlType::CHECKBOX:
				$postValue = is_null($postValue) ?
					\becky\CheckboxValueType::OFF :
					\becky\CheckboxValueType::ON;
				break;
			default:
				// 分岐処理を追加する必要がある。
				die('Error: It is necessary to add branch processing.' . $controlType);
				return false;
		}

		$jsonData += [ $name => $postValue ];
	}

	$settingFilePath = _getSettingFilePath();
	$jsonDataString = json_encode($jsonData);
	return false !== \becky\file_put_contents_and_sync($settingFilePath, $jsonDataString, LOCK_EX);
}

/*!
 * @brief 工場設定を読み込む
 * 複数のファイルから読み込む
 *
 * @param[in] array $elements 工場設定要素郡
 * @return bool 成功可否
 *
 * @global array $_POST                       この連想配列に工場設定を取り込む
 */
function loadFactoryConfig(array $elements)
{
	$settingFilePath = _getSettingFilePath();
	if (!is_file($settingFilePath)) {
		return false;
	}

	$settingString = file_get_contents($settingFilePath);
	if (false === $settingString) {
		return false;
	}

	$settingJSON_Datas = json_decode($settingString, true);
	if (!$settingJSON_Datas) {
		return false;
	}

	foreach ($settingJSON_Datas as $key => $value) {
		$_POST[$key] = $value;
	}

	return true;
}
