<?php
/*! @file
 * @brief 工場設定向けのユーティリティ関数群
 */

require_once topDir() . 'views/htmlEntityUtil.php';
require_once topDir() . 'views/beckyControlType.php';
require_once topDir() . 'views/beckyControlUtil.php';
require_once topDir() . 'views/_tags.php';

/*!
 * @brief コントロールタイプを得る
 *
 * @param[in] array $element 設定要素
 * @return string コントロールタイプ
 */
function getControlType(array $element)
{
	return \ModelUtil\array_get($element[0], '');
}

/*!
 * @brief 名称を得る
 *
 * @param[in] array $element 設定要素
 * @return string 名称
 */
function getName(array $element)
{
	return \ModelUtil\array_get($element[1], '');
}

/*!
 * @brief デフォルトを得る
 *
 * @param[in] array $element 設定要素
 * @return int or string デフォルト情報
 */
function getDefault(array $element)
{
	return $element[2];
}

/*!
 * @brief 値郡を得る
 *
 * @param[in] array $element 設定要素
 * @return array 値郡
 */
function getValues(array $element)
{
	return \ModelUtil\array_get($element[3], []);
}

/*!
 * @brief メッセージを得る
 * 機器設定向け
 *
 * @param[in] string $name キー
 * @return string メッセージ
 */
function _mes($name)
{
//	$mes = _m('factoryConfig', $name);
//	if (empty($mes)) {
//		return $name;
//	}
//
//	return $mes;
	global $app;
	return \ModelUtil\array_get($app['messages']['factoryConfig'][$name], $name);
}

/*!
 * @brief 設定要素のタグ郡を作成する
 *
 * @param[in] array  $elements       設定要素郡
 * @return string HTMLタグ
 */
function buildConfigTags(array $elements)
{
	$tags = '';
	$uniqueNames = []; // Debug 用
	$isFieldsetBeginning = false; // Debug 用
	foreach ($elements as $element) {
		$name    = getName   ($element);
		if (array_key_exists($name, $uniqueNames)) {
			// 設定名をユニークにする必要がある。
			die('Error: The keys are duplicated.' . $name);
		}
		$uniqueNames[] = $name;

		$tag = '';
		$controlType = getControlType($element);
		switch ($controlType) {
			case \becky\ControlType::FIELDSET_BEGIN:
				// フィールドセットなのでラベルは不要
				$tag .= buildConfigFieldsetBegin($element);
				if ($isFieldsetBeginning) {
					die('Error: <fieldset> has not ended.');
				}
				$isFieldsetBeginning = true;
				break;
			case \becky\ControlType::FIELDSET_END:
				// フィールドセットなのでラベルは不要
				$tag .= buildConfigFieldsetEnd($element);
				if (!$isFieldsetBeginning) {
					die('Error: <fieldset> has not started.');
				}
				$isFieldsetBeginning = false;
				break;
			case \becky\ControlType::HEADING:
				// 見出しなのでラベルは不要
				$tag .= buildConfigHeading($element);
				break;
			case \becky\ControlType::BUTTON:
				$tag .= _createElementLabel($name);
				$tag .= buildConfigButton($element);
				break;
			case \becky\ControlType::RADIO:
				$tag .= _createElementLabel($name);
				$tag .= buildConfigRadio($element);
				break;
			case \becky\ControlType::CHECKBOX:
				$tag .= _createElementLabel($name);
				$tag .= buildConfigCheckbox($element);
				break;
			case \becky\ControlType::DROPDOWN_LIST:
				$tag .= _createElementLabel($name);
				$tag .= buildConfigDropdownList($element);
				break;
			case \becky\ControlType::EDIT_BOX:
				$tag .= _createElementLabel($name);
				$tag .= buildConfigEditBox($element);
				break;
			case \becky\ControlType::EDIT_TIME:
				$tag .= _createElementLabel($name);
				$tag .= buildConfigEditTime($element);
				break;
			default:
				// 分岐処理を追加する必要がある。
				die('Error: It is necessary to add branch processing.' . $controlType);
				break;
		}
		$tags .= _p($tag) . PHP_EOL; // 改行を付けると出力ソースのデバッグしやすいかも
	}

	return $tags;
}
