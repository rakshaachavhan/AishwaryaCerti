<?php
/*
 * 全ページに表示する ナビゲーションメニュー
 */

/*!
 * @brief メニューのカレント情報を更新する
 *
 * @param[in] string $name 画面名(拡張子を除いたファイル名)
 */
function _updateCurrent($name)
{
	$serverScriptName = $_SERVER['SCRIPT_NAME'];
	$scriptFileName = pathinfo($serverScriptName, PATHINFO_FILENAME);
	if ($scriptFileName !== $name) {
		return;
	}
	echo ' current';
}

/*!
 * @brief 次のページのリンクを出力
 */
function _echoNextUri()
{
	$pages = [
		'patient.php',
		'objective.php',
		'subjective.php',
		'result.php'
	];

	$serverScriptName = $_SERVER['SCRIPT_NAME'];
	$scriptBaseName = pathinfo($serverScriptName, PATHINFO_BASENAME);
	$index = array_search($scriptBaseName, $pages);
	if (false === $index) {
		echo '#';
		return;
	}

	// 次のページ
	if (count($pages) <= ++$index) {
		$index = 0;
	}

	echo $pages[$index];
}

?>
<div class="siteframe-header">
<div class="siteframe-header-inner">
<div class="layout-header clearfix">
	<div class="navigation">
		<div class="navigation-item<?php _updateCurrent('patient'); ?>"><a class="btn btn-navigation" href="#"><span class="btn-inner"><?php echo _m('patient', 'title'); ?></span></a></div>
		<div class="navigation-item<?php _updateCurrent('objective'); ?>"><a class="btn btn-navigation" href="#"><span class="btn-inner"><?php echo _m('objective', 'title'); ?></span></a></div>
		<div class="navigation-item<?php _updateCurrent('subjective'); ?>"><a class="btn btn-navigation" href="#"><span class="btn-inner"><?php echo _m('subjective', 'title'); ?></span></a></div>
		<div class="navigation-item<?php _updateCurrent('result'); ?>"><a class="btn btn-navigation" href="#"><span class="btn-inner"><?php echo _m('result', 'title'); ?></span></a></div>
	</div><!--/.navigation-->
	<div class="setting">
		<a href="machineConfig.php" class="btn btn-setting" id="btnSetting"><div class="btn-inner"><span class="icon icon-setting"></span></div></a>
	</div><!--/.setting-->
	<div class="clock">
		<div class="clock-date" id="clock-date"></div>
		<div class="clock-time" id="clock-time"></div>
	</div><!--/.clock-->
	<div class="navi-next">
		<a href="<?php _echoNextUri(); ?>" class="btn btn-navi-next" id="btnNaviNext" style="display: none;"><div class="btn-inner"><span class="icon icon-navi-next"></span></div></a>
	</div><!--/.navi-next-->
</div><!--/.layout-header-->
</div><!--./siteframe-header-inner-->
</div><!--./siteframe-header-->
