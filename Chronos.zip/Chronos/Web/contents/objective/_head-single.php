<?php
/*! @file
 * @brief objective-single 固有のスタイルシートとスクリプトの読み込み
 */

addStyles(
	[
		'css/objective-single.css',
	]
);

addScripts(
	[
		'js/objective-single.js',
	]
);
