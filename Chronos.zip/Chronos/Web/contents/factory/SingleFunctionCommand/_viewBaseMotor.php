<?php

$motorTypes = ['X', 'Y', 'Z'];

foreach ($motorTypes as $motorType) {
	include '_viewBaseMotor_Motor.php';
}
