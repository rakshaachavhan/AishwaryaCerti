<div class="block-list">
	<div class="block-horizontal5">
		<h3>CPU1: A unit (Master)</h3>
		<input type="button" id="getStereoCameraReadROMData1" value="red">
	</div>
	<div class="block-horizontal5">
		<h3>CPU2: B unit (Slave)</h3>
		<input type="button" id="getStereoCameraReadROMData2" value="red">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal5">
		<textarea id="stereoCameraReadROMDataValue" style="width: 640px; height: 200px;" readonly></textarea>
	</div>
</div>
