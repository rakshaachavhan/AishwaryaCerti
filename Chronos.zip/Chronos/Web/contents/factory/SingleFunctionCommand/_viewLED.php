<div class="block-list">
	<div class="block-horizontal5">
		<h3>Anterior1</h3>
		<?php _putRagio_ON_OFF('anterior1LED'); ?>
		<input type="tel" id="anterior1LED_Value" value="128" min="0" max="255">
	</div>
	<div class="block-horizontal5">
		<h3>Anterior2</h3>
		<?php _putRagio_ON_OFF('anterior2LED'); ?>
		<input type="tel" id="anterior2LED_Value" value="128" min="0" max="255">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal5">
		<h3>XY</h3>
		<?php _putRagio_ON_OFF('XYLED'); ?>
		<input type="tel" id="XYLED_Value" value="128" min="0" max="255">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal5">
		<h3>Kerato</h3>
		<?php _putRagio_ON_OFF('keratoLED'); ?>
		<input type="tel" id="keratoLED_Value" value="128" min="0" max="255">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal5">
		<h3>SLD</h3>
		<?php _putRagio_ON_OFF('setSLDPower'); ?>
		<input type="tel" id="setSLDCurrent_Value" value="128" min="0" max="255">
		<input type="button" id="setSLDCurrent" value="Set">
	</div>
</div>
<div class="block-list">
	<div class="block-horizontal5">
		<h3>Fixation LED</h3>
		<?php _putRagio_ON_OFF('fixationLED'); ?>
		<input type="tel" id="fixationLED_Value" value="128" min="0" max="255">
	</div>
	<div class="block-horizontal5">
		<h3>Fixation LCD</h3>
	</div>
</div>
