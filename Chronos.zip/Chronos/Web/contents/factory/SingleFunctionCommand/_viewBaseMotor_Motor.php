<div class="block-list">
	<div class="block-horizontal">
		<h3><?php echo $motorType; ?></h3>
		<?php _putRagio_ON_OFF('setMotorPower' . $motorType); ?>
	</div>
	<ul class="block-horizontal">
		<li>
			<input type="radio" name="move<?php echo $motorType; ?>" value="Constant"  id="move<?php echo $motorType; ?>-Constant" >
			<label for="move<?php echo $motorType; ?>-Constant" >Constant </label>
		</li>
		<li>
			<input type="radio" name="move<?php echo $motorType; ?>" value="Trapezoid" id="move<?php echo $motorType; ?>-Trapezoid">
			<label for="move<?php echo $motorType; ?>-Trapezoid">Trapezoid</label>
		</li>
		<li>
			<input type="radio" name="move<?php echo $motorType; ?>" value="J"         id="move<?php echo $motorType; ?>-J" checked>
			<label for="move<?php echo $motorType; ?>-J"        >J        </label>
		</li>
	</ul>
	<ul class="block-horizontal">
		<li>
			<label for="motorInitialPps<?php echo $motorType; ?>" class="motor-type-label">Initial pps:</label>
			<input type="tel" id="motorInitialPps<?php echo $motorType; ?>" value="300">
		</li>
		<li>
			<label for="motorAcceleration<?php echo $motorType; ?>" class="motor-type-label">pps/s^2:</label>
			<input type="tel" id="motorAcceleration<?php echo $motorType; ?>" value="47400">
		</li>
		<li>
			<label for="motorMaxPps<?php echo $motorType; ?>" class="motor-type-label">Max pps:</label>
			<input type="tel" id="motorMaxPps<?php echo $motorType; ?>" value="47400">
			<input type="button" id="setMotorParameter<?php echo $motorType; ?>" value="Set param">
		</li>
	</ul>
	<ul class="block-horizontal">
		<li>
			<div style="display: inline-block;">
				<label for="motorExponentDistance">10^</label>
				<input type="tel" id="motorExponentDistance<?php echo $motorType; ?>" value="0" min="-128" max="127">
			</div>
			<div style="display: inline-block;">
				<input type="tel" id="motorMoveDistanceValue<?php echo $motorType; ?>" value="0">
				<label for="motorMoveDistanceValue" class="motor-unit-label">μm</label>
			</div>
			<input type="button" id="moveMotorDistance<?php echo $motorType; ?>" value="Move Dist.">
		</li>
		<li>
			<div style="display: inline-block;">
				<label for="motorExponentSpeed">10^</label>
				<input type="tel" id="motorExponentSpeed<?php echo $motorType; ?>" value="0" min="-128" max="127">
			</div>
			<div style="display: inline-block;">
				<input type="tel" id="motorMoveSpeedValue<?php echo $motorType; ?>" value="0">
				<label for="motorMoveSpeedValue" class="motor-unit-label">μm/s</label>
			</div>
			<input type="button" id="moveMotorSpeed<?php echo $motorType; ?>" value="Move Speed">
		</li>
	</ul>
	<ul class="block-horizontal">
		<li>
			<input type="button" id="initializeMotor<?php echo $motorType; ?>" value="Zero">
		</li>
		<li>
			<input type="button" id="getMotorPosition<?php echo $motorType; ?>" value="Get Pos">
		</li>
		<li>
			<?php echo $motorType; ?>:
			<span  id ="motorPositionValue<?php echo $motorType; ?>">00000</span>
			<label for="motorPositionValue<?php echo $motorType; ?>">μm</label>
		</li>
	</ul>
</div>
