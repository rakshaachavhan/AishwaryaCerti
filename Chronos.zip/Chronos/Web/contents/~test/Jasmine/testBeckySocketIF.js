describe("becky.Socket", function() {

	function _fncSucceedResultJsonSuccess()
	{
		const d = $.Deferred();
		d.resolve({ return: "success" });
		return d.promise();
	}

	function _fncSucceedResultJsonFailure()
	{
		const d = $.Deferred();
		d.resolve({ return: "failure" });
		return d.promise();
	}

	function _fncFailed()
	{
		const d = $.Deferred();
		d.reject("error");
		return d.promise();
	}

	it("post(ResultJsonSuccess)", function(done) {
		spyOn($, "ajax").and.callFake(_fncSucceedResultJsonSuccess);

		let isSucceed   = false;
		let isFailed    = false;
		let requestJson = null;
		const json = {};
		becky.Socket.post(json).then(aRequestJson => {
			isSucceed = true;
			requestJson = aRequestJson;
		}).catch(() => {
			isFailed = true;
		}).then(() => {
			expect(isSucceed).toBeTruthy('成功時呼び出し関数が呼び出されなかった');
			expect(isFailed ).toBeFalsy ('失敗時呼び出し関数が呼び出されてしまった');

			expect(requestJson).not.toBeNull();

			done();
		});
	});
	it("post(ResultJsonFailure)", function(done) {
		spyOn($, "ajax").and.callFake(_fncSucceedResultJsonFailure);

		let isSucceed   = false;
		let isFailed    = false;
		let requestJson = null;
		const json = {};
		becky.Socket.post(json).then(() => {
			isSucceed = true;
		}).catch(aRequestJson => {
			isFailed = true;
			requestJson = aRequestJson;
		}).then(() => {
			expect(isSucceed).toBeFalsy ('成功時呼び出し関数が呼び出されてしまった');
			expect(isFailed ).toBeTruthy('失敗時呼び出し関数が呼び出されなかった');

			expect(requestJson).not.toBeNull();

			done();
		});
	});
	it("post(Failed)", function(done) {
		spyOn($, "ajax").and.callFake(_fncFailed);

		let isSucceed   = false;
		let isFailed    = false;
		const json = {};
		becky.Socket.post(json).then(() => {
			isSucceed = true;
		}).catch(() => {
			isFailed = true;
		}).then(() => {
			expect(isSucceed).toBeFalsy ('成功時呼び出し関数が呼び出されてしまった');
			expect(isFailed ).toBeTruthy('失敗時呼び出し関数が呼び出されなかった');

			done();
		});
	});
});
