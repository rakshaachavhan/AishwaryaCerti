describe("becky.WebSocket", function() {

	/*!
	 * @brief 正常なデータを得る(架空の設定)
	 *
	 * @return object(json)
	 */
	function _getJsonOK()
	{
		return { test: "OK" };
	}

	/*!
	 * @brief 不正なデータを得る(架空の設定)
	 *
	 * @return object(json)
	 */
	function _getJsonNG()
	{
		return { test: "NG" };
	}

	it("post(ResultJsonSuccess)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			let isSucceed = false;
			let isFailed  = false;
			let requestJson = null;
			const json = _getJsonOK();
			becky.WebSocket.post(json).then(aRequestJson => {
				isSucceed = true;
				requestJson = aRequestJson;
			}).catch(() => {
				isFailed  = true;
			}).then(() => {
				expect(isSucceed).toBeTruthy('成功時呼び出し関数が呼び出されなかった');
				expect(isFailed ).toBeFalsy ('失敗時呼び出し関数が呼び出されてしまった');

				expect(requestJson).not.toBeNull();
				expect(requestJson.return).toBeTruthy("結果JSONの return が false だった");

				done();
			});
		});
	});
	it("post(ResultJsonFailure)", function(done) {
		test.becky.WebSocket.prepare().then(() => {
			let isSucceed = false;
			let isFailed  = false;
			let requestJson = null;
			const json = _getJsonNG();
			becky.WebSocket.post(json).then(() => {
				isSucceed = true;
			}).catch(aRequestJson => {
				isFailed  = true;
				requestJson = aRequestJson;
			}).then(() => {
				expect(isSucceed  ).toBeFalsy ('成功時呼び出し関数が呼び出されてしまった');
				expect(isFailed   ).toBeTruthy('失敗時呼び出し関数が呼び出されなかった');

				expect(requestJson).not.toBeNull();
				expect(requestJson.return).toBeFalsy("結果JSONの return が true だった");

				done();
			});
		});
	});
});
