describe("becky.operatorLog", function() {
	it("convertDateTypeStringIntoDate(array)", function() {
		const dates = [
			"2018-05-21T08:30:00",
			"2018-05-22T17:15:00",
		];
		becky.operatorLog.convertDateTypeStringIntoDate(dates);
		expect(dates[0]).toEqual(new Date("2018-05-21T08:30:00")); // String → Date
		expect(dates[1]).toEqual(new Date("2018-05-22T17:15:00"));
	});
	it("convertDateTypeStringIntoDate(object)", function() {
		const dates = {
			first: "2018-05-21T08:30:00",
			last : "2018-05-22T17:15:00",
		};
		becky.operatorLog.convertDateTypeStringIntoDate(dates);
		expect(dates.first).toEqual(new Date("2018-05-21T08:30:00")); // String → Date
		expect(dates.last ).toEqual(new Date("2018-05-22T17:15:00"));
	});
	it("buildDateRecursively(Depth1)", function() {
		const node = becky.operatorLog.createBaseNode();
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-22T08:30:00");
			childNode.date.last  = new Date("2018-05-22T17:15:00");
			node.children.push(childNode);
		}
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-21T08:30:00");
			childNode.date.last  = new Date("2018-05-21T17:15:00");
			node.children.push(childNode);
		}
		becky.operatorLog.buildDateRecursively(node);

		expect(node.date.first).toEqual(new Date("2018-05-21T08:30:00"));
		expect(node.date.last ).toEqual(new Date("2018-05-22T17:15:00"));
	});
	it("buildDateRecursively(Depth2)", function() {
		const node = becky.operatorLog.createBaseNode();
		{
			const childNode = becky.operatorLog.createBaseNode();
			{
				const grandChildNode = becky.operatorLog.createBaseNode();
				grandChildNode.date.first = new Date("2018-05-22T08:30:00");
				grandChildNode.date.last  = new Date("2018-05-22T17:15:00");
				childNode.children.push(grandChildNode);
			}
			{
				const grandChildNode = becky.operatorLog.createBaseNode();
				grandChildNode.date.first = new Date("2018-05-21T08:30:00");
				grandChildNode.date.last  = new Date("2018-05-22T17:15:00");
				childNode.children.push(grandChildNode);
			}
			node.children.push(childNode);
		}
		{
			const childNode = becky.operatorLog.createBaseNode();
			{
				const grandChildNode = becky.operatorLog.createBaseNode();
				grandChildNode.date.first = new Date("2018-05-22T08:30:00");
				grandChildNode.date.last  = new Date("2018-05-23T17:15:00");
				childNode.children.push(grandChildNode);
			}
			{
				const grandChildNode = becky.operatorLog.createBaseNode();
				grandChildNode.date.first = new Date("2018-05-22T08:30:00");
				grandChildNode.date.last  = new Date("2018-05-22T17:15:00");
				childNode.children.push(grandChildNode);
			}
			node.children.push(childNode);
		}
		becky.operatorLog.buildDateRecursively(node);

		expect(node.date.first).toEqual(new Date("2018-05-21T08:30:00"));
		expect(node.date.last ).toEqual(new Date("2018-05-23T17:15:00"));

		expect(node.children[0].date.first).toEqual(new Date("2018-05-21T08:30:00"));
		expect(node.children[0].date.last ).toEqual(new Date("2018-05-22T17:15:00"));
		expect(node.children[1].date.first).toEqual(new Date("2018-05-22T08:30:00"));
		expect(node.children[1].date.last ).toEqual(new Date("2018-05-23T17:15:00"));
	});
	it("buildDateRecursively(NestDate1)", function() {
		const node = becky.operatorLog.createBaseNode();
		node.date.first = new Date("2018-05-20T08:30:00");
		node.date.last  = new Date("2018-05-20T17:15:00");
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-22T08:30:00");
			childNode.date.last  = new Date("2018-05-22T17:15:00");
			node.children.push(childNode);
		}
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-21T08:30:00");
			childNode.date.last  = new Date("2018-05-21T17:15:00");
			node.children.push(childNode);
		}
		becky.operatorLog.buildDateRecursively(node);

		expect(node.date.first).toEqual(new Date("2018-05-20T08:30:00")); // 更新されない
		expect(node.date.last ).toEqual(new Date("2018-05-22T17:15:00")); // 更新される
	});
	it("buildDateRecursively(NestDate2)", function() {
		const node = becky.operatorLog.createBaseNode();
		node.date.first = new Date("2018-05-23T08:30:00");
		node.date.last  = new Date("2018-05-23T17:15:00");
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-22T08:30:00");
			childNode.date.last  = new Date("2018-05-22T17:15:00");
			node.children.push(childNode);
		}
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-21T08:30:00");
			childNode.date.last  = new Date("2018-05-21T17:15:00");
			node.children.push(childNode);
		}
		becky.operatorLog.buildDateRecursively(node);

		expect(node.date.first).toEqual(new Date("2018-05-21T08:30:00")); // 更新される
		expect(node.date.last ).toEqual(new Date("2018-05-23T17:15:00")); // 更新されない
	});
	it("buildDateRecursively(DateTypeString)", function() {
		const node = becky.operatorLog.createBaseNode();
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = "2018-05-22T08:30:00";
			childNode.date.last  = "2018-05-22T17:15:00";
			node.children.push(childNode);
		}
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = "2018-05-21T08:30:00";
			childNode.date.last  = "2018-05-21T17:15:00";
			node.children.push(childNode);
		}
		becky.operatorLog.buildDateRecursively(node);

		expect(node.date.first).toEqual(new Date("2018-05-21T08:30:00"));
		expect(node.date.last ).toEqual(new Date("2018-05-22T17:15:00"));
	});
	it("normalization", function() {
		const node = becky.operatorLog.createBaseNode();
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-22T08:30:00");
			childNode.date.last  = new Date("2018-05-22T17:15:00");
			node.children.push(childNode);
		}
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-21T08:30:00");
			childNode.date.last  = new Date("2018-05-21T17:15:00");
			node.children.push(childNode);
		}
		becky.operatorLog.buildDateRecursively(node);
		becky.operatorLog.normalization(node);

		expect(node.date.first).toEqual(becky.log.toISO8601ExtString(new Date("2018-05-21T08:30:00"))); // Date → string
		expect(node.date.last ).toEqual(becky.log.toISO8601ExtString(new Date("2018-05-22T17:15:00")));
	});
	it("removeEmptyField", function() {
		const node = becky.operatorLog.createBaseNode();
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-22T08:30:00");
			childNode.date.last  = new Date("2018-05-22T17:15:00");
			node.children.push(childNode);
		}
		{
			const childNode = becky.operatorLog.createBaseNode();
			childNode.date.first = new Date("2018-05-21T08:30:00");
			childNode.date.last  = new Date("2018-05-21T17:15:00");
			node.children.push(childNode);
		}
		becky.operatorLog.removeEmptyField(node);

		expect(node.name    ).toBeUndefined();
		expect(node.private ).toBeUndefined();
		expect(node.children).toBeDefined(); // 存在するのでそのまま

		expect(node.children[0].name    ).toBeUndefined();
		expect(node.children[0].private ).toBeUndefined();
		expect(node.children[0].children).toBeUndefined();
		expect(node.children[1].name    ).toBeUndefined();
		expect(node.children[1].private ).toBeUndefined();
		expect(node.children[1].children).toBeUndefined();
	});
});
