/*! @file
 * @brief becky WebSocket 共通部(テスト用)
 */

// 名前空間
var test = test || {};
test.becky = test.becky || {};
test.becky.WebSocket = test.becky.WebSocket || {};

//! @brief 偽の WebSocket を使用するか？
//test.becky.useFakeWebSocket = false;
test.becky.useFakeWebSocket = true;

/*!
 * 偽の WebSocket 関数
 * WebSocket サーバが存在しなくてもテストできる様に用意
 *
 * @return object(class)
 */
test.becky.WebSocket._funcFakeServer = function(){
	this.readyState = WebSocket.CONNECTING;
	this.arrayEventFunc = [];
	this.addEventListener = function(aName, aFunc){
		this.arrayEventFunc.push([ aName, aFunc ]);
	};
	this.removeEventListener = function(aName, aFunc){
		const count = this.arrayEventFunc.length;
		for (let i = count - 1; i >= 0; --i) {
			const funcI = this.arrayEventFunc[i];
			if (funcI[0] ==  aName &&
			    funcI[1] === aFunc) {
				this.arrayEventFunc.splice(i, 1);
			}
		}
	};
	this.triggerEvent = function(aName, aData){
		if (modelHelper.isNullOrEmpty(aData)) {
			aData = {};
		}
		aData.type = aName; // event.type を付加
		const filterFunc = this.arrayEventFunc.filter(function(aFuncFind){
			return aFuncFind[0] == this;
		}, aName);
		// イベント発生までに遅延が発生するという架空の設定
		asyncHelper.delay(3).then(() => {
			filterFunc.forEach(aFilterFunc => {
				aFilterFunc[1](aData);
			});
		});
	}
	this.close = function(){
		this.triggerEvent("close");
	};
	this.send = function(data){
		const resultJson = {};
		const json = JSON.parse(data);
		resultJson.requestID = json.requestID;
		switch (json.test) {
			case "OK":
				resultJson.return = true;
				break;
			case "NG":
				resultJson.return = false;
				break;
			default:
				console.assert(false, "json.test = " + json.test);
				break;
		}
		const resultJsonString = JSON.stringify(resultJson);
		this.triggerEvent("message", { data: resultJsonString });
	};
	{	// open イベントを遅延呼び出し
		const _instance = this;
		asyncHelper.delay(1).then(() => {
			_instance.readyState = WebSocket.OPEN;
			_instance.triggerEvent("open");
		});
	}
};

/*!
 * WebSocket サーバを準備する
 *
 * @return Promise 
 */
test.becky.WebSocket.prepare = async function()
{
	return new Promise((resolve, reject) => {
		const webSocket = becky.WebSocket.getWebSocket();
		if (modelHelper.isNull(webSocket)) {
			if (test.becky.useFakeWebSocket) {
				// Create WebSocket like proxy
				spyOn(window, "WebSocket").and.callFake(test.becky.WebSocket._funcFakeServer);
			}
			becky.WebSocket.setCheckStateInterval(0); // テストの邪魔になるので、定期的な状態確認を抑止
			becky.WebSocket.build(event => {
				switch (event.type) {
					case "open":
						resolve();
					case "error":
						reject();
					default:
						break;
				}
			});
		} else {
			// 準備済み
			resolve();
		}
	});
};
