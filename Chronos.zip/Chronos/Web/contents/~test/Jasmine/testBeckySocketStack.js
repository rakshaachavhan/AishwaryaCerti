describe("becky.Socket.stack", function() {

	/*!
	 * @brief 成功な結果JSONを返す
	 * ただし即時実行されない
	 *
	 * @return Promise
	 */
	function _fncSucceed()
	{
		const d = $.Deferred();
		asyncHelper.delay(3).then(() => {
			d.resolve({ return: "success" });
		});
		return d.promise();
	}

	/*!
	 * @brief 失敗させる
	 * ただし即時実行されない
	 *
	 * @return Promise
	 */
	function _fncFailed()
	{
		const d = $.Deferred();
		asyncHelper.delay(3).then(() => {
			d.resolve({ return: "failure" });
		});
		return d.promise();
	}

	it("post(ResultJson01)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(1);
			}).catch(() => {
				arrayCalled.push(2);
			}).then(() => {
				arrayCalled.push(3);
			});

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(requestJson => {
				arrayCalled.push(4);
				expect(requestJson).not.toBeNull();
				expect(requestJson.return).toBe("success");
			}).catch(() => {
				arrayCalled.push(5);
			}).then(() => {
				arrayCalled.push(6);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(2); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(4);
			expect(arrayCalled[1]    ).toBe(6);
			// arrayCalled[1, 3]が呼び出されていないのが間違いの様に思えるが、
			// 次の becky.Socket.stack.post が成功(done)している為、最初のは無かった事にされる。
			done();
		});
	});

	it("post(ResultJson10)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(requestJson => {
				arrayCalled.push(1);
				expect(requestJson).not.toBeNull();
				expect(requestJson.return).toBe("success");
			}).catch(() => {
				arrayCalled.push(2);
			}).then(() => {
				arrayCalled.push(3);
			});

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(4);
			}).catch(requestJson => {
				arrayCalled.push(5);
				expect(requestJson).not.toBeNull();
				expect(requestJson.return).toBe("failure");
			}).then(() => {
				arrayCalled.push(6);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(4); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(1);
			expect(arrayCalled[1]    ).toBe(5);
			expect(arrayCalled[2]    ).toBe(3);
			expect(arrayCalled[3]    ).toBe(6);
			done();
		});
	});

	// 成功時呼び出し関数 - 全て失敗
	it("post(Succeed_000)", function(done) {
		spyOn($, "ajax").and.callFake(_fncFailed);

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(1);
			}).catch(() => {
				// このテストでは何もしない
			});

			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(2);
			}).catch(() => {
				// このテストでは何もしない
			});

			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(3);
			}).catch(() => {
				// このテストでは何もしない
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
			done();
		});
	});

	// 成功時呼び出し関数 - 1回成功
	it("post(Succeed_001)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(1);
			});

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(2);
			}).catch(() => {
				// このテストでは何もしない
			});

			//spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(3);
			}).catch(() => {
				// このテストでは何もしない
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(1); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(1);
			done();
		});
	});

	// 成功時呼び出し関数 - 1回成功
	it("post(Succeed_010)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(1);
			});

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(2);
			});

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(3);
			}).catch(() => {
				// このテストでは何もしない
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(1); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(2);
			done();
		});
	});

	// 成功時呼び出し関数 - 2回成功
	it("post(Succeed_011)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(1);
			});

			//spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(2);
			});

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(3);
			}).catch(() => {
				// このテストでは何もしない
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(2); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(1);
			expect(arrayCalled[1]    ).toBe(2);
			done();
		});
	});

	// 成功時呼び出し関数 - 1回成功
	it("post(Succeed_100)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(1);
			});

			//spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(2);
			});

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(1); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(3);
			done();
		});
	});

	// 成功時呼び出し関数 - 2回成功
	it("post(Succeed_101)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(1);
			});

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(2);
			});

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(2); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(1);
			expect(arrayCalled[1]    ).toBe(3);
			done();
		});
	});

	// 成功時呼び出し関数 - 2回成功
	it("post(Succeed_110)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(1);
			});

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(2);
			});

			//spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(2); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(2);
			expect(arrayCalled[1]    ).toBe(3);
			done();
		});
	});

	// 成功時呼び出し関数 - 全て成功
	it("post(Succeed_111)", function(done) {
		spyOn($, "ajax").and.callFake(_fncSucceed);

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(1);
			});

			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(2);
			});

			becky.Socket.stack.post(beckySocketStack, json).then(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(3); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(1);
			expect(arrayCalled[1]    ).toBe(2);
			expect(arrayCalled[2]    ).toBe(3);
			done();
		});
	});

	// 失敗時呼び出し関数 - 全て失敗
	it("post(Failed_000)", function(done) {
		spyOn($, "ajax").and.callFake(_fncFailed);

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(1);
			});

			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(2);
			});

			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(3); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(3);
			expect(arrayCalled[1]    ).toBe(2);
			expect(arrayCalled[2]    ).toBe(1);
			done();
		});
	});

	// 失敗時呼び出し関数 - 1回成功
	it("post(Failed_001)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(1);
			});

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(2);
			});

			//spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(2); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(3);
			expect(arrayCalled[1]    ).toBe(2);
			done();
		});
	});

	// 失敗時呼び出し関数 - 1回成功
	it("post(Failed_010)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(1);
			});

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(2);
			});

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(1); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(3);
			done();
		});
	});

	// 失敗時呼び出し関数 - 2回成功
	it("post(Failed_011)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(1);
			});

			//spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(2);
			});

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(1); // 呼び出し回数
			expect(arrayCalled[0]    ).toBe(3);
			done();
		});
	});

	// 失敗時呼び出し関数 - 1回成功
	it("post(Failed_100)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(1);
			});

			//spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(2);
			});

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
			done();
		});
	});

	// 失敗時呼び出し関数 - 2回成功
	it("post(Failed_101)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(1);
			});

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(2);
			});

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
			done();
		});
	});

	// 失敗時呼び出し関数 - 2回成功
	it("post(Failed_110)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			spyAnd.callFake(_fncFailed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(1);
			});

			spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(2);
			});

			//spyAnd.callFake(_fncSucceed);
			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
			done();
		});
	});

	// 失敗時呼び出し関数 - 全て成功
	it("post(Failed_111)", function(done) {
		spyOn($, "ajax").and.callFake(_fncSucceed);

		const arrayCalled = [];

		becky.Socket.stack.scope(beckySocketStack => {
			const json = { data: "OK" }; // 正常なデータ(という設定)

			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(1);
			});

			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(2);
			});

			becky.Socket.stack.post(beckySocketStack, json).catch(() => {
				arrayCalled.push(3);
			});

			expect(arrayCalled.length).toBe(0); // まだ呼び出されていない想定
		});

		asyncHelper.delay(15).then(() => {
			expect(arrayCalled.length).toBe(0); // 呼び出し回数は0回
			done();
		});
	});

	// 失敗時呼び出し関数 - 連打して全て成功(100回)
	it("post(Failed_RepeatedHitsSucceedAll)", function(done) {
		spyOn($, "ajax").and.callFake(_fncSucceed);

		const repeatCount = 100;
		let json = { value: 0 };

		becky.Socket.stack.scope(beckySocketStack => {
			for (let i = 0; i < repeatCount; ++i) {
				const jsonBak = $.extend(true, {}, json); // バックアップ
				json.value = i; // 値を書き換える

				becky.Socket.stack.post(beckySocketStack, json).catch(() => {
					json = jsonBak; // 失敗時に復元
				});
			}
		});

		asyncHelper.delay(50).then(() => {
			expect(json.value).toBe(repeatCount - 1); // 最後の状態
			done();
		});
	});

	// 失敗時呼び出し関数 - 連打して25回毎に成功
	it("post(Failed_RepeatedHitsEvery25Count)", function(done) {
		const spyAnd = spyOn($, "ajax").and;

		const repeatCount = 100;
		let json = { value: 0 };

		becky.Socket.stack.scope(beckySocketStack => {
			for (let i = 0; i < repeatCount; ++i) {
				const jsonBak = $.extend(true, {}, json); // バックアップ
				json.value = i; // 値を書き換える

				if (0 == i % 25) {
					spyAnd.callFake(_fncSucceed);
				} else {
					spyAnd.callFake(_fncFailed);
				}
				becky.Socket.stack.post(beckySocketStack, json).catch(() => {
					json = jsonBak; // 失敗時に復元
				});
			}
		});

		asyncHelper.delay(50).then(() => {
			expect(json.value).toBe(repeatCount - 25); // 最後の成功
			done();
		});
	});

	// 失敗時呼び出し関数 - 連打して全て失敗
	it("post(Failed_RepeatedHitsFailedAll)", function(done) {
		spyOn($, "ajax").and.callFake(_fncFailed);

		const repeatCount = 100;
		let json = { value: 0 };

		becky.Socket.stack.scope(beckySocketStack => {
			for (let i = 0; i < repeatCount; ++i) {
				const jsonBak = $.extend(true, {}, json); // バックアップ
				json.value = i; // 値を書き換える

				becky.Socket.stack.post(beckySocketStack, json).catch(() => {
					json = jsonBak; // 失敗時に復元
				});
			}
		});

		asyncHelper.delay(50).then(() => {
			expect(json.value).toBe(0); // 最初の状態
			done();
		});
	});

});
