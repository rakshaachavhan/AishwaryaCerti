<?php
	phpinfo();
