<?php

require_once '_common.php';
require_once topDir() . 'ls/jsonDistributorUtil.php';

// 以下のテストは言語設定が日本語で実行する事！

class JsonDistributorUtilTest extends PHPUnit_Framework_TestCase {

	public function test_createResultErrorJson() {
		$json = createResultErrorJson(404, 'file not found!');
		$jsonString = json_encode($json);
		$this->assertEquals('{"return":false,"error":{"code":404,"message":"file not found!"}}', $jsonString);
	}

	public function test_createMessageForUser() {
		$json = createResultErrorJson(10000, 'Could not connect to HTTP server.');
		$errorNode = &$json['error'];
		addMessageForUser($errorNode);
		$this->assertEquals('HTTPサーバーに接続できませんでした。(10000)', $errorNode['messageForUser']);
	}

	public function test_createMessageForUser_errorCodeOnly() {
		$json = createResultErrorJson(10000, 'Could not connect to HTTP server.');
		$errorNode = &$json['error'];
		unset($errorNode['message']); // メッセージ削除
		addMessageForUser($errorNode);
		$this->assertEquals('HTTPサーバーに接続できませんでした。(10000)', $errorNode['messageForUser']);
	}

	public function test_createMessageForUser_errorMessageOnly() {
		$json = createResultErrorJson(10000, 'Could not connect to HTTP server.');
		$errorNode = &$json['error'];
		unset($errorNode['code']); // エラー番号を削除
		addMessageForUser($errorNode);
		$this->assertEquals('Could not connect to HTTP server.', $errorNode['messageForUser']);
	}

	public function test_createMessageForUser_errorEmpty() {
		$json = createResultErrorJson(10000, 'Could not connect to HTTP server.');
		$errorNode = &$json['error'];
		unset($errorNode['message']); // メッセージ削除
		unset($errorNode['code'   ]); // エラー番号を削除
		addMessageForUser($errorNode);
		$this->assertEquals('', $errorNode['messageForUser']);
	}

	public function test_createMessageForUser_undefinedMessage() {
		$json = createResultErrorJson(418, "I'm a teapot");
		$errorNode = &$json['error'];
		addMessageForUser($errorNode);
		$this->assertEquals("I'm a teapot(418)", $errorNode['messageForUser']);
	}

}// class JsonDistributorUtilTest

?>
