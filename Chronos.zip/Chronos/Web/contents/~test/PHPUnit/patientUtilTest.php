<?php

require_once '_common.php';
require_once topDir() . 'models/patientUtil.php';

class PatientUtilTest extends PHPUnit_Framework_TestCase {

	public function test_toSessionPatientID_empty() {
		$actual = \becky\Patient\toSessionPatientID('', '091414');
		$this->assertSame('empty091414', $actual);
	}

	public function test_toSessionPatientID_inSpace() {
		$actual = \becky\Patient\toSessionPatientID('0 1', '092020');
		$this->assertSame('0+1', $actual);
	}

	public function test_toSessionPatientID_inSlash() {
		$actual = \becky\Patient\toSessionPatientID('0/1', '093210');
		$this->assertSame('0%2F1', $actual);
	}

	public function test_toSessionPatientID_inBackSlash() {
		$actual = \becky\Patient\toSessionPatientID('0\\1', '093412');
		$this->assertSame('0%5C1', $actual);
	}

	public function test_toSessionPatientID_inColon() {
		$actual = \becky\Patient\toSessionPatientID('0:1', '093551');
		$this->assertSame('0%3A1', $actual);
	}

	public function test_toSessionPatientID_inAsterisk() {
		$actual = \becky\Patient\toSessionPatientID('0*1', '094004');
		$this->assertSame('0%2A1', $actual);
	}

	public function test_toSessionPatientID_inQuestion() {
		$actual = \becky\Patient\toSessionPatientID('0?1', '094151');
		$this->assertSame('0%3F1', $actual);
	}

	public function test_toSessionPatientID_inDoubleQuotes() {
		$actual = \becky\Patient\toSessionPatientID('0"1', '094239');
		$this->assertSame('0%221', $actual);
	}

	public function test_toSessionPatientID_inLessThan() {
		$actual = \becky\Patient\toSessionPatientID('0<1', '094325');
		$this->assertSame('0%3C1', $actual);
	}

	public function test_toSessionPatientID_inGreaterThan() {
		$actual = \becky\Patient\toSessionPatientID('0>1', '094416');
		$this->assertSame('0%3E1', $actual);
	}

	public function test_toSessionPatientID_inPipe() {
		$actual = \becky\Patient\toSessionPatientID('0|1', '094503');
		$this->assertSame('0%7C1', $actual);
	}

	public function test_toSessionPatientID_prohibitedCharacters() {
		$actual = \becky\Patient\toSessionPatientID(' /\\:*?"<>|', '095031');
		$this->assertSame('+%2F%5C%3A%2A%3F%22%3C%3E%7C', $actual);
	}

}// class PatientUtilTest
