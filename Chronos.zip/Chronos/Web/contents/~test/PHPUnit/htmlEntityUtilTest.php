<?php

require_once '_common.php';
require_once topDir() . 'views/htmlEntityUtil.php';

class HtmlEntityUtilTest extends PHPUnit_Framework_TestCase {

	public function test_escapeHTML() {
		$value = '<br>';
		\HtmlEntityUtil\escapeHTML($value);
		$this->assertEquals('&lt;br&gt;', $value);
	}

	public function test_array_escapeHTML() {
		$values = array(
			'text1' => 'R<G',
			'text2' => 'R=G',
			'text3' => 'R>G',
		);
		\HtmlEntityUtil\array_escapeHTML($values);
		$expected = array(
			'text1' => 'R&lt;G',
			'text2' => 'R=G',
			'text3' => 'R&gt;G',
		);
		$this->assertEquals($expected, $values);
	}

}// class HtmlEntityUtilTest

?>
