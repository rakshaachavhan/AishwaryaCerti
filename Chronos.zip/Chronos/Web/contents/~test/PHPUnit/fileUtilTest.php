<?php

require_once '_common.php';
require_once topDir() . 'models/fileUtil.php';

class FileUtilTest extends PHPUnit_Framework_TestCase {

	public function test_file_put_contents_and_sync() {
		$filePath = 'test_file_put_contents_and_sync.txt';
		$this->assertEquals(true, \becky\file_put_contents_and_sync($filePath, "test"));
		$this->assertTrue(file_exists($filePath));
		unlink($filePath);
		$this->assertFalse(file_exists($filePath));
	}

	public function test_file_put_contents_and_sync2() {
		$filePath = 'test_file_put_contents_and_sync2.txt';
		$this->assertEquals(true, \becky\file_put_contents_and_sync($filePath, "test2", LOCK_EX));
		$this->assertTrue(file_exists($filePath));
		unlink($filePath);
		$this->assertFalse(file_exists($filePath));
	}

	public function test_file_put_contents_and_syncBackgroundExecute() {
		$filePath = 'test_file_put_contents_and_syncBackgroundExecute.txt';
		$this->assertEquals(true, \becky\file_put_contents_and_syncBackgroundExecute($filePath, "test"));
		$this->assertTrue(file_exists($filePath));
		unlink($filePath);
		$this->assertFalse(file_exists($filePath));
	}

	public function test_file_put_contents_and_syncBackgroundExecute2() {
		$filePath = 'test_file_put_contents_and_syncBackgroundExecute2.txt';
		$this->assertEquals(true, \becky\file_put_contents_and_syncBackgroundExecute($filePath, "test2", LOCK_EX));
		$this->assertTrue(file_exists($filePath));
		unlink($filePath);
		$this->assertFalse(file_exists($filePath));
	}

}// class FileUtilTest

?>
