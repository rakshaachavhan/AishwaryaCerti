<?php
/*! @file
 * @brief ネットワーク設定画面の保存や復元などを行う関数群
 */

//require_once topDir() . 'contents/networkConfig/networkConfigCategoryType.php';
//require_once topDir() . 'contents/networkConfig/_networkConfigUtil.php';
require_once topDir() . 'contents/networkConfig/networkInterfacesFileIO.php';

/*!
 * @brief ネットワーク設定を保存する
 *
 * @return bool 成功可否
 *
 * @global array $_POST この連想配列に記録されているネットワーク設定を保存する
 */
function doRegisterNetworkConfig()
{
	// 保存前にバックアップ
	if (!backupFileNetworkInterfaces()) {
		return false;
	}

	$ipAddress      = $_POST['ip_Address'    ];
	$subnetMask     = $_POST['subnetMask'    ];
	$defaultGateway = $_POST['defaultGateway'];

	return writeFileNetworkInterfaces($ipAddress, $subnetMask, $defaultGateway);
}

/*!
 * @brief 機器設定を読み込む
 * 複数のファイルから読み込む
 *
 * @return bool 成功可否
 *
 * @global array $_POST この連想配列にネットワーク設定を取り込む
 */
function loadNetworkConfig()
{
	$ipAddress      = '';
	$subnetMask     = '';
	$defaultGateway = '';
	if (!getNetworkInterfaces($ipAddress, $subnetMask, $defaultGateway)) {
		return false;
	}

	$_POST['ip_Address'    ] = $ipAddress;
	$_POST['subnetMask'    ] = $subnetMask;
	$_POST['defaultGateway'] = $defaultGateway;

	return true;
}
