<?php
/*! @file
 * @brief ネットワーク設定画面の中身
 */

require_once topDir() . 'views/beckyControlType.php';
//require_once topDir() . 'contents/_head.php';
//require_once topDir() . 'contents/networkConfig/networkConfigCategoryType.php';
require_once topDir() . 'contents/networkConfig/_head.php';
require_once topDir() . 'contents/networkConfig/_viewLogic.php';
require_once topDir() . 'contents/networkConfig/_networkConfigUtil.php';

/*!
 * @brief ネットワーク設定のすべての設定項目を定義
 */
$elements = [
	// コントロールタイプ               , 設定名称                              , デフォルト, 選択肢
	[ \becky\ControlType::EDIT_BOX      , 'ip_Address'                          , '10.1.2.3' ],
	[ \becky\ControlType::EDIT_BOX      , 'subnetMask'                          , '255.0.0.0' ],
	[ \becky\ControlType::EDIT_BOX      , 'defaultGateway'                      , '' ],
];

$networkFilePath = getNetworkFilePath();
if (!file_exists($networkFilePath)) {
	// ネットワーク設定ファイルが無いのでエラーページに飛ばす
	$_SESSION['error'] = [
		'redirectUri'  => topUri(),
	//	'redirectWait' => 30,
		'title'        => _m('error', 'title'),
		'msg'          => 'file not found!<br>' . $networkFilePath,
	];
	header('Location: ' . topUri() . 'sub/error.php');
	return;
}

$footerMessage = '';

if (!empty($_POST['networkConfig_register'])) {
	// 保存前にトリムする
	\ModelUtil\array_trim($_POST);

	if (doRegisterNetworkConfig()) {
		// 保存したので再起動を促す
		$footerMessage = _m('networkConfig', 'savedAndRestartMessage');
	} else {
		// 保存失敗
		$footerMessage = _mError('networkConfig', 'failedToSaveSettings');
	}
} else {
	if (!loadNetworkConfig()) {
		// ファイルの破損やアクセス権などの問題
		$footerMessage = _mError('networkConfig', 'failedToLoadSettings');
	}
}

?>
<!DOCTYPE html>
<html>
	<head>
		<?php outputHeadContents(); ?>
		<title><?php echo _m('networkConfig', 'title'); ?></title>
	</head>

	<body>
		<!-- メッセージの定義リスト(JavaScript向け) -->
		<dl id="list_message" style="display: none;">
			<dt>networkConfig/changeConfirmMessage</dt><dd><?php echo _m('networkConfig', 'changeConfirmMessage'); ?></dd>
		</dl>
		<div id="main">
			<form id="networkConfig_form" action="./networkConfig.php" method="post">
				<button type="button" id="goBack"><?php echo _m('networkConfig', 'goBack' ); ?></button>
				<button type="button" id="register"><?php echo _m('networkConfig', 'save' ); ?></button>
				<div>
					<?php echo buildConfigTags($elements); ?>
				</div>
			</form>
		</div>
		<footer><?php echo $footerMessage; ?></footer>
	</body>
</html>
