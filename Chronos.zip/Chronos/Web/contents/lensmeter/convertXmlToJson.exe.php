<?php
/*! @file
 * @brief 標準入力で受け取ったレンズメーターのXMLをJSON形式に変換して標準出力に返す
 */

require_once 'convertXmlToJsonHelper.php';

$xmlString  = file_get_contents('php://stdin');
$jsonString = \Lensmeter\convertXmlToJsonString($xmlString);
if (!$jsonString) {
	exit(1);
}

echo $jsonString;

exit(0);
