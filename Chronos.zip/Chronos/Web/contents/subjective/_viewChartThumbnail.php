<?php
/*! @file
 * @brief 視力表の(タブ内)サムネイルの画面
 */

// array_column が登場するのは、PHP 5.5.0 以降
if (!function_exists('array_column'))
{
	function array_column(array $array, $column_name)
	{
		return array_map(function($element) use($column_name){ return $element[$column_name]; }, $array);
	}
}

if (!function_exists('_getChartByLayoutID'))
{
	/*!
	 * @brief layoutID をキーに視力表のデータを得る
	 *
	 * @param[in] array $arrayChartPageN chartPage1～5 のデータ
	 * @param[in] integer $layoutID レイアウトID
	 * @return array 視力表のデータ
	 */
	function _getChartByLayoutID(array $arrayChartPageN, $layoutID)
	{
		$index = array_search($layoutID, array_column($arrayChartPageN, 'layoutID'));
		if (false === $index) {
			return null;
		}

		return $arrayChartPageN[$index];
	}
}

// 即時関数を実行する
call_user_func(function(){

	global $indent;
	global $arrayChartPageParam;
	global $keyChartPageParam;

	if (!array_key_exists($keyChartPageParam, $arrayChartPageParam)) {
		// キーが無い
		return;
	}

	$arrayChartPage = $arrayChartPageParam[$keyChartPageParam];
	if (!$arrayChartPage) {
		// 要素が空
		return;
	}

	for ($i = 0; $i < 21; ++$i) { // 7x3 の表
		$chart = _getChartByLayoutID($arrayChartPage, $i + 1);
		if (!$chart || !array_key_exists('chartID', $chart)) {
			echo $indent . '<div class="btn-tile" style="visibility: collapse;">' . PHP_EOL;
			echo $indent . '</div>' . PHP_EOL;
			continue;
		}
		$autoID = createAutoID($keyChartPageParam, $chart);
		$chartID = $chart['chartID'];
		$fileExt = '';
		switch ($chartID) {
			case 2004:
			case 2005:
			case 2006:
			case 2007:
			case 2104:
			case 2105:
			case 2106:
			case 2107:
			case 2204:
			case 2205:
			case 2206:
			case 2207:
			case 3156:
			case 3157:
				$fileExt = '.svg';
				break;
			default:
				$fileExt = '.png';
				break;
		}
		$examID = $chart['examID'];
		echo $indent . '<div class="btn-tile" data-auto-id="' . $autoID . '" data-chart-id="' . $chartID . '" data-exam-id="' . $examID . '">' . PHP_EOL;
		echo $indent . '	<img src="../img/small/small_' . $chartID . $fileExt . '">' . PHP_EOL;
		echo $indent . '</div>' . PHP_EOL;
	}

});
