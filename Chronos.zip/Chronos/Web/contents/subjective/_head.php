<?php
/*! @file
 * @brief subjective 固有のスタイルシートとスクリプトの読み込み
 */

addStyles(
	[
		'css/subjective.css',
	]
);

addScripts(
	[
		'js/subjective.js',
	]
);
