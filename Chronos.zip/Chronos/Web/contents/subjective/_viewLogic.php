<?php
/*! @file
 * @brief 自覚画面向けのロジック関数群
 */

require_once topDir() . 'models/modelUtil.php';
require_once topDir() . 'models/pathUtil.php';
require_once topDir() . 'models/fileUtil.php';

/*!
 * @breif 他覚の設定情報を得る
 *
 * @return array
 */
function getObjectiveSettingJson()
{
	$filenameObjectiveSettingJson = 'contents/settings/objective.setting.json';
	$arrayObjectiveSetting = getMapFromJsonFile(topDir() . $filenameObjectiveSettingJson);
	return $arrayObjectiveSetting;
}

/*!
 * @breif ポストデータ($_POST)から値を取得する
 *
 * @param[in] string $key 取得するキー
 * @return float or string
 */
function getValueFromPOST($key)
{
	$value = \ModelUtil\array_get($_POST[$key], '');
	return \ModelUtil\toNumericIfPossible($value);
}

/*!
 * @breif ポストデータ($_POST)からVAの単位を取得する
 *
 * @param[in] string $key 取得するキー
 * @return float or string
 */
function getVA_UnitFromPOST($key)
{
	$value = \ModelUtil\array_get($_POST[$key], '');
	$unit = '';
	switch ($value) {
		case 'd':
			$unit = 'decimal';
			break;
		case 'f':
			$unit = 'feet';
			break;
		case 'm':
			$unit = 'meter';
			break;
		default:
			break;
	}
	return $unit;
}

/*!
 * @brief 自覚を登録する
 * 登録先はファイル
 *
 * @return bool 成功可否
 */
function doRegisterSubjective()
{
	$objectiveSettingJson  = getObjectiveSettingJson();
	if (!$objectiveSettingJson) {
		return false;
	}

	$subjectiveFileDir = tempDir();
	if (!file_exists($subjectiveFileDir) &&
	    !mkdir($subjectiveFileDir, 0777, true)) {
		return false;
	}
	$subjectiveFileName = 'subjective.json';
	$subjectiveFilePath = \becky\Path\combine($subjectiveFileDir, $subjectiveFileName);

	if (file_exists($subjectiveFilePath)) {
		// 同名のファイルが存在する場合
		$backupFileName = $subjectiveFileName;

		$backupSuffix = '.His'; // 時分秒
		$backupSuffix = date($backupSuffix); // 時間フォーマットを適用
		if (!empty($backupSuffix)) {
			$pathInfos = pathinfo($backupFileName);
			$backupFileName = $pathInfos['filename'] . $backupSuffix . '.' . $pathInfos['extension'];
		}

		// リネームする
		$backupFilePath = $subjectiveFileDir . $backupFileName;
		rename($subjectiveFilePath, $backupFilePath);
	}

	$fVD = \ModelUtil\toNumericIfPossible($objectiveSettingJson['vd']);

	$subjectiveJSON = [
		'subjective' => [
			'RefractionTest' => [
				'List' => [
					'1' => [
						'Full Correction' => [
							'ExamDistance' => [
								'List' => [
									'1' =>  [// 遠見
										'Distance' => [
											'unit' => 'mm',
											'value' => getValueFromPOST('ExamDistanceFar'),
										],
										'RefractionData' => [
											'R' => [
												'Sphere' => [
													'unit' => 'D',
													'value' => getValueFromPOST('SphR'),
												],
												'Cylinder' => [
													'unit' => 'D',
													'value' => getValueFromPOST('CylR'),
												],
												'Axis' => [
													'unit' => 'deg',
													'value' => getValueFromPOST('AxsR'),
												],
											],
											'L' => [
												'Sphere' => [
													'unit' => 'D',
													'value' => getValueFromPOST('SphL'),
												],
												'Cylinder' => [
													'unit' => 'D',
													'value' => getValueFromPOST('CylL'),
												],
												'Axis' => [
													'unit' => 'deg',
													'value' => getValueFromPOST('AxsL'),
												],
											],
											'VD' => [
												'unit' => 'mm',
												'value' => $fVD,
											],
											'PD' => [
												'B' => [
													'unit' => 'mm',
													'value' => getValueFromPOST('PD'),
												],
											],
										],
										'VA' => [
											'R' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitFarR'),
												'value' => getValueFromPOST('VA_FarR'),
											],
											'L' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitFarL'),
												'value' => getValueFromPOST('VA_FarL'),
											],
											'B' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitFarB'),
												'value' => getValueFromPOST('VA_FarB'),
											],
										],
									],
									'2' =>  [// 近見
										'Distance' => [
											'unit' => 'mm',
											'value' => getValueFromPOST('ExamDistanceNear'),
										],
										'RefractionData' => [
											'R' => [
												'Sphere' => [
													'unit' => 'D',
													'value' => getValueFromPOST('SphR') + getValueFromPOST('ADD_R'),
												],
												'Cylinder' => [
													'unit' => 'D',
													'value' => getValueFromPOST('CylR'),
												],
												'Axis' => [
													'unit' => 'deg',
													'value' => getValueFromPOST('AxsR'),
												],
											],
											'L' => [
												'Sphere' => [
													'unit' => 'D',
													'value' => getValueFromPOST('SphL') + getValueFromPOST('ADD_L'),
												],
												'Cylinder' => [
													'unit' => 'D',
													'value' => getValueFromPOST('CylL'),
												],
												'Axis' => [
													'unit' => 'deg',
													'value' => getValueFromPOST('AxsL'),
												],
											],
											'VD' => [
												'unit' => 'mm',
												'value' => $fVD,
											],
											'PD' => [
												'B' => [
													'unit' => 'mm',
													'value' => getValueFromPOST('PD'),
												],
											],
										],
										'VA' => [
											'R' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitNearR'),
												'value' => getValueFromPOST('VA_NearR'),
											],
											'L' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitNearL'),
												'value' => getValueFromPOST('VA_NearL'),
											],
											'B' => [
												'unit'  => getVA_UnitFromPOST('VA_UnitNearB'),
												'value' => getValueFromPOST('VA_NearB'),
											],
										],
									],
								],
							],
						],
					],
				],
			],
		],
	];

	// ウォース4点テスト
	$worth4DotsResult = getValueFromPOST('Worth4DotsResult');
	if (!empty($worth4DotsResult)) {
		$subjectiveJSON['subjective']['Worth4Dots'] = [
			'ExamDistance' => [
				'List' => [
					'1' => [ // 遠見
						'Distance' => [
							'unit' => 'mm',
							'value' => getValueFromPOST('ExamDistanceFar'),
						],
						'Result' => $worth4DotsResult,
					],
					'2' => [ // 近見
						'Distance' => [
							'unit' => 'mm',
							'value' => getValueFromPOST('ExamDistanceNear'),
						],
						'Result' => $worth4DotsResult,
					],
				],
			],
		];
	}

	$subjectiveJSON_String = json_encode($subjectiveJSON);
	return false !== \becky\file_put_contents_and_sync($subjectiveFilePath, $subjectiveJSON_String, LOCK_EX);
}
