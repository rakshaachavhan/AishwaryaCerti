<?php
/*! @file
 * @brief 別のHTTPサーバに接続し、情報をそのまま流す
 */

require_once '../../models/modelUtil.php';

$file = \ModelUtil\array_get($_GET['file'], '');

if (empty($file)) {
	// ファイルが無い
	http_response_code(404);
	exit;
}

$socket = stream_socket_client('tcp://10.140.19.30:8080');
if (!$socket) {
	// 接続先のサーバが無効
	http_response_code(500);
	exit;
}

$strLF = chr(0x0a); // LF
$strCR = chr(0x0d); // CR
$strCRLF = $strCR . $strLF;

$uri = 'GET /' . $file . '?' . $_SERVER['QUERY_STRING'] . '  HTTP/1.0';
fwrite($socket, $uri . $strCRLF . $strCRLF);

if (feof($socket)) {
	// いきなり切断された
	http_response_code(500);
	exit;
}

// HTTPの最初のレスポンス部分を解析する
$response = trim(fgets($socket, 32));
if (0 > strpos($response, 200)) {
	// 200(OK)ではない
	http_response_code(500);
	exit;
}
header($response);

// HTTPヘッダの処理
$header = '';
while (!feof($socket)) {
	$header = trim(fgets($socket, 0xFF));
	if (empty($header)) {
		break;
	}
	header($header);
}

// 後はひたすら流し続ける
while (!feof($socket)) {
	set_time_limit(1);
	echo fread($socket, 1500); // 一般的な MTU のサイズを参考
}

fclose($socket);
