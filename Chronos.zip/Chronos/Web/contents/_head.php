<?php
/*! @file
 * @brief アプリ全体で共通に使用するスタイルシート、スクリプトファイル
 */

addStyles(
	[
		'vendor/normalize.css',
		'css/hol-on-common.css',
	]
);

addScripts(
	[
		'vendor/jqueryui/js/jquery-3.2.1.min.js',
		'vendor/jquery.ui.touch-punch.min.js',
		'js/all.js',
		'js/modelHelper.js',
		'js/viewHelper.js',
		'js/ajaxHelper.js',
		'js/asyncHelper.js',
		'js/beckyAssertion.js',
		'js/beckyDebug.js',
		'js/beckyDynamic.js.php',
		'js/beckyMutationObserver.js',
		'js/beckyDataSync.js',
		'js/beckyJsonHelper.js',
		'js/beckyAsyncAjax.js',
		'js/beckyLeanStartupAjax.js',
		'js/beckyScopedStyle.js',
		'js/beckyWebStorageHelper.js',
		'js/beckyWebStorageIO.js',
		'js/beckyWebStorageExam.js',
		'js/beckyOperatorLog.js',
		'js/beckyOperatorLogExam.js',
		'js/beckyLogHelper.js',
		'js/nav.js',
	]
);
