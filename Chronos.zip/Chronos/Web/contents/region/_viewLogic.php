<?php
/*! @file
 * @brief リージョン設定向けのロジック関数群
 */

require_once topDir() . 'models/pathUtil.php';
require_once topDir() . 'models/fileUtil.php';
require_once topDir() . 'views/htmlEntityUtil.php';

/*!
 * @brief 言語ファイル(*.ini)からIDと名称を得る
 *
 * @param[in] string $messageFile 言語ファイル名
 * @param[out] string $id         言語ID
 * @param[out] string $name       言語名
 * @return bool 成功可否
 */
function getIDWithNameFromMessageFile($messageFile, &$id, &$name)
{
	$inis = parse_ini_file($messageFile, true);
	if (!$inis) {
		return false;
	}

	$globalSection = $inis['global'];
	if (!$globalSection) {
		return false;
	}

	$id   = $globalSection['regionID'];
	$name = $globalSection['regionName'];

	return !empty($id) && !empty($name);
}

/*!
 * @brief リージョンの<select><option>...</select>を文字列で得る
 *
 * @return string HTMLタグ
 */
function getRegionSelector()
{
	$key_post = 'regionID';
	$messageDir = \becky\Path\combine(topDir(), 'contents', 'message');
	$messageFiles = scandir($messageDir);

	$lines = [];
	foreach ($messageFiles as $messageFile) {
		$messageFilePath = \becky\Path\combine($messageDir, $messageFile);
		if (!is_file($messageFilePath)) {
			continue;
		}
		if (!getIDWithNameFromMessageFile($messageFilePath, $id, $name)) {
			continue;
		}
		$label = sprintf('%1$s (%2$s)', $name, $id);
		$lines += [$label => $id];
	}

	return \HtmlEntityUtil\getSelectOptions($lines, 'select_1-2_1', $key_post, $_POST[$key_post]);
}

/*!
 * @brief リージョンに関するものを登録する
 * 登録先はファイル
 *
 * @return bool 成功可否
 */
function doRegisterRegion()
{
	$regionSettingFilePath = topDir() . 'contents/settings/region.setting.json';
	$regionSettingJSON = ['regionID' => $_POST['regionID']];
	$regionSettingJSON_String = json_encode($regionSettingJSON);
	return false !== \becky\file_put_contents_and_sync($regionSettingFilePath, $regionSettingJSON_String, LOCK_EX);
}
