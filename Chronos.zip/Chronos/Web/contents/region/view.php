<?php
/*! @file
 * @brief リージョン設定画面の中身
 */

//require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/region/_head.php';
require_once topDir() . 'contents/region/_viewLogic.php';

if (!empty($_POST['region_register'])) {
	if (doRegisterRegion()) {
		header('Location: ' . topUri() . 'sub/machineConfig.php');
		exit;
	}
}

if (!array_key_exists('regionID', $_POST)) {
	$_POST['regionID'] = getRegionIDFromSetting();
}

?>
<!DOCTYPE html>
<html>
	<head>
		<?php outputHeadContents(); ?>
		<title>Region</title>
	</head>

	<body>
		<script>
		</script>

		<header>
		</header>

		<div id="main">
			<form id="region_form" action="./region.php" method="post">
				<h2>Please select a region.</h2>
				<?php echo getRegionSelector(); ?>
				<input type="hidden" name="region_register" value="Register"></input>
				<button type="submit" id="text_1-2_2-1" class="ui-button ui-widget ui-corner-all">Start</button>
			</form>
		</div>

		<footer><?php printDebug(); ?></footer>
	</body>
</html>
