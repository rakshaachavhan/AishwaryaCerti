<?php
/*! @file
 * @brief 被検者情報-画面向けのロジック関数群
 */

require_once topDir() . 'models/modelUtil.php';
require_once topDir() . 'models/pathUtil.php';
require_once topDir() . 'models/fileUtil.php';
require_once topDir() . 'models/patientUtil.php';

/*!
 * @brief POST されるフィールド群を得る
 *
 * @return array フィールド(文字列)群
 */
function getPostFields()
{
	return [
		'patientID',
		'patientName',
		'patientDOB',
		'operatorID',
	];
}

/*!
 * @brief 患者を登録する
 * 登録先はファイル
 *
 * @return bool 成功可否
 */
function doRegisterPatient()
{
	// セッションの日付・患者IDをセット(セッション)
	$sessionDate = $_POST['sessionDate'];
	$sessionTime = $_POST['sessionTime'];
	$patientID   = $_POST['patientID'  ];
	$sessionPatientID = \becky\Patient\toSessionPatientID($patientID, $sessionTime);

	setSessionDate     ($sessionDate     );
	setSessionTime     ($sessionTime     );
	setSessionPatientID($sessionPatientID);

	$patientFileDir = tempDir();
	if (!file_exists($patientFileDir) &&
	    !mkdir($patientFileDir, 0777, true)) {
		return false;
	}
	$patientFilePath = \becky\Path\combine($patientFileDir, 'patient.json');

	$patientJSON = [];
	$postFields = getPostFields();
	foreach ($postFields as $field) {
		$patientJSON += [ $field => \ModelUtil\array_get($_POST[$field], '') ];
	}

	$patientJSON_String = json_encode($patientJSON);
	return false !== \becky\file_put_contents_and_sync($patientFilePath, $patientJSON_String, LOCK_EX);
}
