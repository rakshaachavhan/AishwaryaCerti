<?php
/*! @file
 * @brief 被検者情報-画面の中身
 */

require_once topDir() . 'views/_tags.php';
require_once topDir() . 'contents/_head.php';
require_once topDir() . 'contents/patient/_head.php';
require_once topDir() . 'contents/patient/_viewLogic.php';

if (!empty($_POST['patient_register'])) {
	// 保存前にトリムする
	\ModelUtil\array_trim($_POST);

	if (doRegisterPatient()) {
		header('Location: ' . topUri() . 'sub/objective.php');
		exit;
	}
}

?>
<!DOCTYPE html>
<!--[if lt IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html lang="ja-JP" class="no-js ie lt-ie9 lt-ie8"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 8]><html lang="ja-JP" class="no-js ie lt-ie9"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if IE 9]><html lang="ja-JP" class="no-js ie"  xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml"><![endif]-->
<!--[if gt IE 9]><!-->
<html lang="ja-JP" class="no-js" xmlns:og="http://ogp.me/ns#" xmlns:mixi="http://mixi-platform.com/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
<!--<![endif]-->
<head>
<?php outputHeadContents(); ?>
<title><?php echo _m('patient', 'title'); ?></title>
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body>
<div class="siteframe A-entry">
<div class="siteframe-inner">

<?php include_once topDir() . 'contents/_nav.php'; ?>

<div class="siteframe-body">
<div class="siteframe-body-inner">
<div class="layout-content clearfix">
	<div class="area-a">
		<div class="area-inner">
			<div class="form-table">
				<form id="patient_form" action="./patient.php" method="post">
					<div class="tr">
						<div class="th"><?php echo _m('patient', 'patientID'); ?></div>
						<div class="td"><input type="tel" class="form form-input" name="patientID" value=""></div>
					</div>
					<div class="tr">
						<div class="th"><?php echo _m('patient', 'patientName'); ?></div>
						<div class="td"><input type="text" class="form form-input" name="patientName" value=""></div>
					</div>
					<div class="tr">
						<div class="th"><?php echo _m('patient', 'patientDOB'); ?></div>
						<div class="td"><input type="date" class="form form-input" name="patientDOB" value=""></div>
					</div>
					<div class="tr">
						<div class="th"><?php echo _m('patient', 'operatorID'); ?></div>
						<div class="td"><input type="tel" class="form form-input" name="operatorID" value=""></div>
					</div>
				</form>
			</div><!--/.form-table-->
		</div><!--/.area-inner-->
	</div><!--/.area-a-->
</div><!--/.layout-content-->
</div><!--./siteframe-body-inner-->
</div><!--./siteframe-body-->

<div class="siteframe-footer">
<div class="siteframe-footer-inner">
<div class="layout-footer clearfix">
	<div class="menu">
		<div class="menu-item"><button type="button" class="btn" id="text_3-1_12-1"><div class="btn-inner">Clear</div></button></div>
		<?php
		//<div class="menu-item"><button type="button" class="btn"><div class="btn-inner">Scan</div></button></div>
		//<div class="menu-item"><button type="button" class="btn" id="text_3-1_13-1"><div class="btn-inner">OK</div></button></div>
		?>
	</div><!--/.menu-->
</div><!--/.layout-footer-->
</div><!--./siteframe-footer-inner-->
</div><!--./siteframe-footer-->

</div><!--./siteframe-inner-->
</div><!--./siteframe-->



</body>
</html>
