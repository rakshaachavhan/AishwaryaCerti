<?php
/*! @file
 * @brief jsonDistributor.php 向けユーティリティ
 */

if (!function_exists('topDir')) {
	function topDir()
	{
		return dirname(__FILE__) . '/../';
	}
}

require_once topDir() . 'models/modelUtil.php';
require_once topDir() . 'models/pathUtil.php';
require_once topDir() . 'models/systemUtil.php';

//! @brief ローカライズされたメッセージのマップ
$jsonDistributorMessageMap = [];

/*!
 * @brief エラー JSON を生成する
 *
 * @param[in] int $code エラー番号
 * @param[in] string $message エラーメッセージ
 * @return array
 */
function createResultErrorJson($code, $message)
{
	return [
		'return' => false,
		'error' => [
			'code' => $code,
			'message' => $message,
		],
	];
}

/*!
 * @brief ローカライズされたメッセージを得る
 * 得るものは、app.php の _m 関数 と同じだが、
 * この関数はJSON生成ページで使用されるため、
 * 必要な初期化処理が実施されていない事がある。
 * よって、必要最低限の処理を抜き出した。
 *
 * @global array $jsonDistributorMessageMap ローカライズされたメッセージのマップ
 * @param[in] string $section メッセージのセクション名。 通常はページの名称。
 * @param[in] string $name    メッセージ名
 * @return string 取得したメッセージ。指定メッセージが存在しない場合は空文字列を返す。
 */
function getLocalizedMessage($section, $name)
{
	global $jsonDistributorMessageMap;

	if (empty($jsonDistributorMessageMap)) {
		$regionSettingFilePath = topDir() . 'contents/settings/region.setting.json';

		$regionID = '';
		if (file_exists($regionSettingFilePath)) {
			$regionSettingJSON = file_get_contents($regionSettingFilePath);
			if (false !== $regionSettingJSON) {
				$regionSettingMap = json_decode($regionSettingJSON, true);
				$regionID = \ModelUtil\array_get($regionSettingMap['regionID'], '');
			}
		}
		if (empty($regionID)) {
			$regionID = 'US';
		}

		$regionFilePath = topDir() . 'contents/message/' . $regionID . '.ini';
		$jsonDistributorMessageMap = parse_ini_file($regionFilePath, true);
	}

	return \ModelUtil\array_get($jsonDistributorMessageMap[$section][$name], '');
}

/*!
 * @brief ユーザ向けエラーメッセージをノードに追加する
 * キーは'messageForUser'
 *
 * @param[in,out] array $errorNode エラーノード
 * @return void
 */
function addMessageForUser(&$errorNode)
{
	if (!is_array($errorNode)) {
		return;
	}
	$messageForUser = \ModelUtil\array_get($errorNode['message'], '');
	if (array_key_exists('code', $errorNode)) {
		$code = \ModelUtil\array_get($errorNode['code'], 0);
		$localizedMessage = getLocalizedMessage('command', 'errorCode' . $code);
		if (!empty($localizedMessage)) {
			$messageForUser = $localizedMessage;
		}
		$messageForUser .= '(' . $code . ')';
	}
	$errorNode['messageForUser'] = $messageForUser;
}

/*!
 * @brief ログを追記
 *
 * @param[in] string $path ファイルパス
 * @param[in] mixed $data 書き込む内容
 * @return void
 */
function _appendLog($path, $data)
{
	file_put_contents($path, $data . PHP_EOL, FILE_APPEND | LOCK_EX);
}

/*!
 * @brief エラー JSON を生成し、ログ出力する
 *
 * @param[in] int $code エラー番号
 * @param[in] string $message エラーメッセージ
 * @param[in] string $pathLog ログファイルパス
 * @return array
 */
function _createResultErrorJsonWithLog($code, $message, $pathLog)
{
	_appendLog($pathLog, $message . '(' . $code . ')');
	return createResultErrorJson($code, $message);
}

/*!
 * @brief 開かれているソケットが1つでも存在するか？
 *
 * @param[in] array $sockets 左右ヘッドとソケットのマップ
 * @retval  true 存在する
 * @retval false 存在しない
 */
function _hasOpenSocket($sockets)
{
	$socketValues = array_values($sockets);
	if (empty($socketValues)) {
		return false;
	}
	$feofs = array_map(function($socket){
		return feof($socket);
	}, $socketValues);
	return in_array(false, $feofs);
}

/*!
 * @brie fwrite をラップし、データを全て書き込む
 *
 * @param[in] socket $socket ソケット
 * @param[in] string $string 書き込みたい文字列
 * @retval  true 成功
 * @retval false 失敗
 */
function _fwriteFull($socket, $string)
{
	if (feof($socket)) {
		return false;
	}

	$stringLen = strlen($string);
	$total = 0;
	while ($stringLen > $total) {
		$written = fwrite($socket, $string);
		if (false === $written) {
			return false;
		}

		$total += $written;
		$string = substr($string, $written);
	}

	return !feof($socket);
}

/*!
 * HTTP リクエストをブロードキャストする
 *
 * @param[in] array $ipPorts IPアドレスとポート番号を連結した連想配列
 * @param[in] string $postData 送信するデータ
 * @param[in] string $pathLog ログファイルパス
 * @return string | null サーバーから返ってきたレスポンス(JSON形式)
 */
function broadcastHttpRequest($ipPorts, $postData, $pathLog)
{
	if (empty($postData)) {
		_appendLog($pathLog, 'php://input is empty');
		return null;
	}

	$resultJson = [];

	$targetFileName = \becky\System\isWindows() ? '_bootExeDumy.php' : '_bootExe.php';

	$sockets = [];
	foreach ($ipPorts as $pos => $ipPort) {
		$socket = false;
		// サーバー接続のリトライは3回まで
		for ($i = 0; $i < 3 && !$socket; ++$i) {
			// ネットワーク内の同じセグメントのサーバーに接続するのでタイムアウト時間は 3 秒もあれば十分
			$socket = stream_socket_client('tcp://' . $ipPort, $errno, $errstr, 3);
			if (!$socket) {
				_appendLog($pathLog, "stream_socket_client('tcp://'" . $ipPort . ', ' . $errno . ', ' . $errstr . ', 3)');
			}
		}
		if (!$socket) {
			// 接続できない
			if (empty($errstr)) {
				$errstr = 'Could not connect to HTTP server.';
			}
			$resultJson[$pos] = _createResultErrorJsonWithLog(10000, $errstr, $pathLog);
			continue;
		}

		$sockets[$pos] = $socket;
	}

	{
		define('STR_LF'  , chr(0x0a)); // LF
		define('STR_CR'  , chr(0x0d)); // CR
		define('STR_CRLF', STR_CR . STR_LF);

		$scriptName = $_SERVER['SCRIPT_NAME'];
		preg_match('#/([^/]+)/#', $scriptName, $matches);
		$appName = $matches[1];
		$path = '/' . \becky\Path\combine($appName, 'ls', $targetFileName);
		$uri = 'POST ' . $path . ' HTTP/1.0';
		foreach ($sockets as $pos => $socket) {
			$requests = [
				$uri,
				'Content-Type: application/json; charset=utf-8',
				'Content-Length: ' . strlen($postData),
				'',
				$postData,
			];
			$request = join(STR_CRLF, $requests);
			if (!_fwriteFull($socket, $request)) {
				// いきなり切断された
				$resultJson[$pos] = _createResultErrorJsonWithLog(10001, 'The communication was disconnected unexpectedly.', $pathLog);
				continue;
			}
		}
	}

	$timeout = ini_get('default_socket_timeout') * 0.8; // デフォルトの8割あれば

	$responses = [];
	$states    = [];
	foreach ($sockets as $pos => $socket) {
		$responses[$pos] = '';
		$states   [$pos] = 0;
	}
	while (_hasOpenSocket($sockets)) {
		$read = $sockets;
		$write  = null;
		$except = null;
		stream_select($read, $write, $except, $timeout);
		if (empty($read)) {
			// 時間内に応答がなかった
			$errorJson = _createResultErrorJsonWithLog(10004, 'The command did not return a response within that time.', $pathLog);
			foreach ($sockets as $pos => $socket) {
				$resultJson[$pos] = $errorJson;
			}
			break;
		}
		foreach ($read as $r) {
			$pos = array_search($r, $sockets);
			$state = &$states[$pos];
			switch ($state) {
			case 0: // HTTPの最初のレスポンス部分を解析する
				$readData = rtrim(fgets($r, 64));
				if (false === strpos($readData, '200')) {
					// 200(OK)ではない
					_appendLog($pathLog, $readData);
					$resultJson[$pos] = _createResultErrorJsonWithLog(10002, 'The HTTP server returned an error code.', $pathLog);
					// 強制切断
					fclose($r);
					unset($sockets[$pos]);
				} else {
					++$state;
				}
				break;
			case 1: // HTTPヘッダの処理
				$readData = rtrim(fgets($r, 255));
				if (empty($readData)) {
					++$state;
				}
				break;
			case 2: // レスポンスを得る
				$responses[$pos] .= fread($r, 1500); // 一般的な MTU のサイズを参考
				break;
			default:
				break;
			}
		}
	}

	foreach ($sockets as $pos => $socket) {
		fclose($socket);
	}

	// JSON を結合
	foreach ($responses as $pos => $response) {
		$responseJson = json_decode($response, true);
		if (null === $responseJson) {
			// JSON 形式ではない(ルール違反)
			_appendLog($pathLog, $response);
			$responseJson = _createResultErrorJsonWithLog(10003, 'The data returned by the command program was invalid.', $pathLog);
		}
		$resultJson[$pos] = $responseJson;
	}

	// エラーメッセージのローカライズ
	foreach ($resultJson as $pos => &$responseJson) {
		if (\ModelUtil\array_get($responseJson['return'], false)) {
			continue;
		}
		if (!array_key_exists('error', $responseJson)) {
			// エラー情報が無いので詳細が分からない
			continue;
		}
		$errorNode = &$responseJson['error'];
		if (\ModelUtil\is_vector($errorNode)) {
			// 複数
			foreach ($errorNode as &$once) {
				addMessageForUser($once);
			}
		} else {
			// 単一
			addMessageForUser($errorNode);
		}
	}

	// 結果の結合
	{
		// すべて成功しているか？
		$resultJsonReturnTrue = array_filter(array_values($resultJson), function($item) {
			return true === \ModelUtil\array_get($item['return'], false);
		});
		$resultJson['return'] = count($resultJsonReturnTrue) === count($resultJson);
	}

	return $resultJson;
}
