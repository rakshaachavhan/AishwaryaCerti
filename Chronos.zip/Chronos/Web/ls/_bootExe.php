<?php
/*! @file
 * @brief 実行ファイルを起動し標準出力の内容をJSON形式という想定でHTTPレスポンスとして返す
 */

// エラー発生時に JSON 形式でデータを返せなくなるので
// 全てのエラー出力をオフにする
error_reporting(0);

require_once '../models/modelUtil.php';
require_once '../models/pathUtil.php';

/*!
 * @brief 標準エラー出力
 *
 * @param[in] string $val 出力内容
 * @return void;
 */
function echoSTDERR($val)
{
	fputs(STDERR, $val);
}

/*!
 * @brief 標準エラー出力(改行)
 *
 * @param[in] string $val 出力内容
 * @return void;
 */
function echoLineSTDERR($val)
{
	echoSTDERR($val . PHP_EOL);
}

/*!
 * @brief ログを追記
 *
 * @param[in] string $path ファイルパス
 * @param[in] mixed $data 書き込む内容
 * @return void;
 */
function appendLog($path, $data)
{
	if (empty($data)) {
		return;
	}
	if (false === file_put_contents($path, $data, FILE_APPEND | LOCK_EX)) {
		echoLineSTDERR('Error! appendLog ' . $path);
	}
}

$jsonString = file_get_contents('php://input'); // POST の生データ
if (empty($jsonString)) {
	http_response_code(500);
	echoLineSTDERR('php://input is empty');
	exit;
}

$json = json_decode($jsonString, true);

$command = \ModelUtil\array_get($json['command'], '');
if (empty($command)) {
	http_response_code(500);
	echoLineSTDERR('command is empty');
	exit;
}

// セキュリティ対策
// 登録している実行ファイルしか動かさない
$exes = [
	'stdoutjson',        // 動作確認用
	'HeadPositionJson',  // 動作確認用
	'ChronosAlignment2', // 前眼部アライメント
	'ChronosRef2',       // 他覚屈折力測定(レフ)
	'Chart',             // 指標表示
	'Phoropter',         // フォロプター制御
	'ResetBase',         // Base-PCBのモーターを原点復帰
	'ResetOpt',          // OPT-PCBリセット
	'GetBaseSubVer',     // BaseSub ファームウェアバージョン取得
	'GetOptSubVer',      // OptSub ファームウェアバージョン取得
	'ChronosAlignment2ModelEye', // 前眼部アライメント(模型眼モード)
];
$index = array_search($command, $exes);
if (false === $index) {
	http_response_code(500);
	echoLineSTDERR('un-known command ' . $command);
	exit;
}

$path = '/home/root/chronos/' . $command;
if (!file_exists($path)) {
	http_response_code(500);
	echoLineSTDERR('Not found! ' . $path);
	exit;
}

$desc = [
	1 => ['pipe', 'w'],
	2 => ['pipe', 'w'],
];

$stdin = '';
if (array_key_exists('json', $json)) {
	$stdin = json_encode($json['json']);
}
$enableStdin = !empty($stdin);
if ($enableStdin) {
	$desc[0] = ['pipe', 'r'];
}

$proc = proc_open($path, $desc, $pipes);
if (!is_resource($proc)) {
	http_response_code(500);
	echoLineSTDERR('Error! proc_open');
	exit;
}

// ログファイル
$logDir = \becky\Path\combine(dirname(__FILE__), '..');
$pathLog       = \becky\Path\combine($logDir, 'log' . $command             . '.txt');
$pathLogStdin  = \becky\Path\combine($logDir, 'log' . $command . '.stdin'  . '.txt');
$pathLogStdout = \becky\Path\combine($logDir, 'log' . $command . '.stdout' . '.txt');
$pathLogStderr = \becky\Path\combine($logDir, 'log' . $command . '.stderr' . '.txt');
// ログファイルは蓄積させない方針
if (file_exists($pathLog      )) unlink($pathLog      );
if (file_exists($pathLogStdin )) unlink($pathLogStdin );
if (file_exists($pathLogStdout)) unlink($pathLogStdout);
if (file_exists($pathLogStderr)) unlink($pathLogStderr);

if ($enableStdin) {
	appendLog($pathLogStdin, $stdin);
	fwrite($pipes[0], $stdin);
	fclose($pipes[0]);
}
stream_set_blocking($pipes[1], 0);
stream_set_blocking($pipes[2], 0);

$stdout = '';
$stderr = '';
while (false === feof($pipes[1]) || false === feof($pipes[2])) {
	$ret = stream_select(
		$read    = [ $pipes[1], $pipes[2], ],
		$write   = null,
		$except  = null,
		$timeout = 1
	);
	if (false === $ret) {
		echoLineSTDERR('Error! stream_select');
		break;
	} else if (0 === $ret) {
		// タイムアウト
		continue; // 待ち続ける
	} else {
		foreach ($read as $sock) {
			       if ($sock === $pipes[1]) {
				$readStr = fread($sock, 4096);
				appendLog($pathLog      , $readStr);
				appendLog($pathLogStdout, $readStr);
				$stdout .= $readStr;
			} else if ($sock === $pipes[2]) {
				$readStr = fread($sock, 4096);
				appendLog($pathLog      , $readStr);
				appendLog($pathLogStderr, $readStr);
				$stderr .= $readStr;
			}
		}
	}
}

fclose($pipes[1]);
fclose($pipes[2]);

proc_close($proc);

$stdout = trim($stdout);
if (empty($stdout)) {
	$stdout = '{}';
}

$contentType = '';
if (null === json_decode($stdout, true)) {
	// Json 形式ではない(ルール違反)
	echoLineSTDERR('Warning! not json format');
	$contentType = 'text/plain';
} else {
	$contentType = 'application/json; charset=utf-8';
}

header('Content-Type: ' . $contentType);
echo $stdout;
