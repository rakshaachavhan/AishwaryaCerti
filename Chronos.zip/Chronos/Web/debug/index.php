<?php
/*! @file
 * @brief デバッグ用リンク
 */

require_once '../models/app.php';

init('debug/' . basename(__FILE__));

require_once topDir() . 'models/pathUtil.php';
require_once topDir() . 'views/_tags.php';

$protocol = $_SERVER['REQUEST_SCHEME'];
$host     = $_SERVER['HTTP_HOST'];

$scriptName = $_SERVER['SCRIPT_NAME'];
preg_match('#/([^/]+)/#', $scriptName, $matches);
$appName = $matches[1];

$headPos = '';
$logTop = [
	'L' => $protocol . '://' . \becky\Path\combine($host, '/headL', $appName),
	'R' => $protocol . '://' . \becky\Path\combine($host, '/headR', $appName),
];
$commands = [
	'ResetOpt',
	'ResetBase',
	'ChronosAlignment2',
	'ChronosRef2',
	'Chart',
	'Phoropter',
];

function getHeadTopUrl($fileName)
{
	global $headPos;
	global $logTop;
	return \becky\Path\combine($logTop[$headPos], $fileName);
}

function getATag($fileName, $title)
{
	return _a(['href'=>getHeadTopUrl($fileName),'target'=>'_blank'], $title);
}

function getLink($command)
{
	$atags = [
		getATag('log' . $command .        '.txt', '標準出力&標準エラー出力'),
		getATag('log' . $command . '.stdout.txt', '標準出力のみ'           ),
		getATag('log' . $command . '.stderr.txt', '標準エラー出力のみ'     ),
		getATag('log' . $command . '.stdin.txt' , '標準入力のみ'           ),
	];
	return join('&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;', $atags);
}

function getLinks()
{
	global $headPos;
	global $commands;
	foreach ($commands as $command) {
		echo \TagHelper\createHTML('h3', null, $command);
		switch ($command) {
			case 'ResetOpt':
			case 'ResetBase':
			case 'Chart':
				echo getATag('log' . $command . '.boot.txt', '標準出力&標準エラー出力(本体起動時)');
				echo '<br>';
				break;
			default:
				break;
		}
		echo getLink($command);
	}
	// lcosctl
	echo \TagHelper\createHTML('h3', null, 'lcosctl');
	echo getATag('loglcosctl.boot.txt', '標準出力&標準エラー出力(本体起動時)');
	// LiveStreamServer
	echo \TagHelper\createHTML('h3', null, 'LiveStreamServer');
	echo getATag('logLiveStreamServer.txt', '標準出力&標準エラー出力');
	// IOModule
	echo \TagHelper\createHTML('h3', null, 'IOModule(リーンスタートアップ版のみ)');
	echo getATag('logIOModule.txt', '標準出力&標準エラー出力');
}

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>デバッグ用リンク</title>
	</head>
	<body>
		<h1>デバッグ用リンク</h1>
		<?php echo _a(['href'=>topUri() . 'ls/logCommands.html','target'=>'_blank'], 'コマンド履歴(1サイクル分)'); ?>
		<h2>制御ボックス</h2>
		<?php
			// IOModule
			echo \TagHelper\createHTML('h3', null, 'IOModule');
			echo _a(['href'=>topUri() . 'logIOModule.txt','target'=>'_blank'], '標準出力&標準エラー出力');
			// jsonDistributor.php
			echo \TagHelper\createHTML('h3', null, 'JSON分配器(リーンスタートアップ版のみ)');
			echo _a(['href'=>topUri() . 'logjsonDistributor.txt','target'=>'_blank'], 'ログ出力');
		?>
		<h2>左ヘッド</h2>
		<?php $headPos = 'L'; getLinks(); ?>
		<h2>右ヘッド</h2>
		<?php $headPos = 'R'; getLinks(); ?>
	</body>
</html>
