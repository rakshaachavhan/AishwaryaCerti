<?php
namespace becky;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require_once dirname(__FILE__) . '/views/jsonHelper.php';

/*!
 * @brief コマンドの結果を設定する
 *
 * @param[in] bool $value 結果
 * @param[in,out] array $resultJson 結果JSON
 * @return void
 */
function setReturn($value, &$resultJson)
{
	$resultJson['return'] = $value;
}

/*!
 * @brief 入力系(仕様確定していない)
 *
 * @param[in] array $requestJson リクエストで渡されたJSON
 * @param[in,out] array $resultJson 結果JSON
 * @return void
 */
function requestInput($requestJson, &$resultJson)
{
	// Todo.決め打ちなので注意！
	$arrayPrivate = $requestJson['private'];
	$arrayPrivateL = $arrayPrivate['L'];
	$arrayPrivateR = $arrayPrivate['R'];

	$failed = false;

	// S, C は整数値のみ。A は3の倍数のみ許可する。
	// という架空の設定

	if (0 != fmod($arrayPrivateL['S'], 1)) {
		$failed = true;
	}
	if (0 != fmod($arrayPrivateL['C'], 1)) {
		$failed = true;
	}
	if (0 != $arrayPrivateL['A'] % 3) {
		$failed = true;
	}
	if (0 != fmod($arrayPrivateR['S'], 1)) {
		$failed = true;
	}
	if (0 != fmod($arrayPrivateR['C'], 1)) {
		$failed = true;
	}
	if (0 != $arrayPrivateR['A'] % 3) {
		$failed = true;
	}

	setReturn(!$failed, $resultJson);
}

class Fake implements MessageComponentInterface
{
	protected $clients;

	public function __construct()
	{
		$this->clients = new \SplObjectStorage;
	}

	public function onOpen(ConnectionInterface $conn)
	{
		// Store the new connection to send messages to later
		$this->clients->attach($conn);

		echo 'New connection! (' . $conn->resourceId . ')' . PHP_EOL;
	}

	public function onMessage(ConnectionInterface $from, $msg)
	{
		echo 'recv:' . PHP_EOL;
		echo $msg . PHP_EOL;

		$requestJson = json_decode($msg, true);
		$resultJson = $requestJson; // そのまま返す
		$requestJsonTest = @$requestJson['test'];
		if (empty($requestJsonTest)) {
			$requestFunction = @$requestJson['function'];
			// とりあえず、function/name に何かしらの値が入っている場合は成功とする
			$requestFunctionName = @$requestFunction['name'];
			$returnValue = !empty($requestFunctionName);
			// 関数名の最初が'get'以外ならブロードキャストする
			$isBroadcast = 0 !== strpos($requestFunctionName, 'get');
		} else {
			// 単体テスト専用
			switch ($requestJsonTest) {
				case 'OK':
					$returnValue = true;
					break;
				case 'NG':
					$returnValue = false;
					break;
				default:
					break;
			}
			$isBroadcast = false;
		}
		setReturn($returnValue, $resultJson);
		// JSON 文字列化とエスケープ
		$resultJsonString = json_encode_and_escape($resultJson);

		foreach ($this->clients as $client) {
			if (!$isBroadcast && $from !== $client) {
				continue;
			}
			$client->send($resultJsonString);
		}

		echo 'send:' . PHP_EOL;
		echo $resultJsonString . PHP_EOL;

		// Ratchet v0.3→v0.4 に変更してからメモリが開放されなくなった!?
		gc_collect_cycles();
	}

	public function onClose(ConnectionInterface $conn)
	{
		// The connection is closed, remove it, as we can no longer send it messages
		$this->clients->detach($conn);

		echo 'Connection ' . $conn->resourceId . ' has disconnected' . PHP_EOL;
	}

	public function onError(ConnectionInterface $conn, \Exception $e)
	{
		echo 'An error has occurred: ' . $e->getMessage() . PHP_EOL;

		$conn->close();
	}
}
