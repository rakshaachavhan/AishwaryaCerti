<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  </head>
  
  <body>
  <div class="container">
  <div class="row">
  <div class="col-md-3"></div>
  <div class="col-md-6"></div>
  <div class="panel panel-body"></div>
  <form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">
  <fieldset>
		<legend><center>Student Registration </center></legend>
  </fieldset>

	<div class="form-group">
	<label class="col-md-3 control-label">First Name</label>
	<div class="col-md-9 input Group container">
	<div class="input-group">
	<span class="input-group-addon">
	<i class="glyphicon glyphicon-user"></i>
	</span>
	<input name="firstname" placeholder="First Name" class="form-control" type="text">
	</div>
	</div>
    </div>
  </form>
  </div>
  </div>

  </body>
  </html>
