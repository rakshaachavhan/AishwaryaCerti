<?php
if(session_id())
{
  

}
else
{
  session_start();
}

      if(!(isset($_SESSION['varSesLogin'])))
      

?>


<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<div class="panel panel-body">
					<form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">
						<fieldset>
							<legend><center>Login</center></legend>
						</fieldset>
						<div class="form-group">
							<label class="col-md-3 control-label">Username</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-user"></i>
									</span>
									<input name="username" placeholder="Username" class="form-control" type="text">
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label">Password</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-lock"></i>
									</span>
									<input class="form-control" id="userPw" type="password" placeholder="password" 
                       name="password" data-minLength="5"
                       data-error="some error"
                       required/>
		                       <span class="glyphicon form-control-feedback"></span>
		                		<span class="help-block with-errors"></span>
								</div>
							</div>
						</div>

						<div class="form-group">
							<div class=" inputGroupContainer">
								<center><button type="submit" class="btn btn-primary btn-group-lg" name="btnlogin">login</button></center>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

</body>
</html>

 <?php
  error_reporting('all');
  include 'connection/dbconnect.php';
 	if (isset($_POST['btnlogin']))
 	{
      $varUserName=mysqli_real_escape_string($conObj,trim($_POST['username']));
      $varPassword=mysqli_real_escape_string($conObj,trim($_POST['password']));

      $varCheckLogin="SELECT * FROM login WHERE username='$varUserName' AND password='$varPassword'";

      $varResult=mysqli_query($conObj,$varCheckLogin);

		if(mysqli_num_rows($varResult)==1)
		{
      		session_start();
      		$arrData=mysqli_fetch_array($varResult);
      		$_SESSION["varSesLogin"]="LoginSuccess";
      		$_SESSION["varSesEmail"]=$arrData['username'];
      		echo "<script>location='welcome.php'</script>";
      	}
      	else
      	{
      		echo "<script>alert('login fail')</script>";
        	echo "<script>location='login.php'</script>";
      	}
    }
   
?>