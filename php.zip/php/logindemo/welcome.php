<?php
if(session_id())
{
  

}
else
{
  session_start();
}
//error_reporting('all');
include "connection/dbconnect.php";
$varID=@$_SESSION["varSesEmail"];
$varUserType=@$_SESSION["varSesUserType"];
$varShowQ="SELECT * FROM login WHERE username='$varID'";
$res=mysqli_query($conObj,$varShowQ);
$data=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
</head>
<body>
	  <div class="col-md-11">
       <span><h2>Welcome:<?php echo $data['username']; ?>!!!</h2></span>
     </div>
     <div class="col-md-1">
     	<a href="logout.php">Logout</a>
     </div>
</body>
</html>