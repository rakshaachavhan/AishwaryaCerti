<?php
if(session_id())
 {
      // session has been started
 }
 else
 {
      // session has NOT been started
      session_start();
 }

        if (isset($_SESSION['varSesLogin']))
        {
          session_destroy();
        }
      
       echo "<script>location='login.php'</script>";         

?>