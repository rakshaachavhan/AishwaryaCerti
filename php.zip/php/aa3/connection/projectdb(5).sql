-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2018 at 08:56 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `stureg`
--

CREATE TABLE `stureg` (
  `ID` bigint(20) NOT NULL,
  `fld_firstname` varchar(255) NOT NULL DEFAULT '0',
  `fld_middlename` varchar(255) NOT NULL DEFAULT '0',
  `fld_lastname` varchar(255) NOT NULL DEFAULT '0',
  `fld_contactno` varchar(15) NOT NULL DEFAULT '0',
  `fld_address` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `fld_dob` varchar(100) NOT NULL DEFAULT '0',
  `fld_gender` varchar(20) NOT NULL DEFAULT '0',
  `fld_branch` varchar(40) NOT NULL DEFAULT '0',
  `fld_year` varchar(10) NOT NULL DEFAULT '0',
  `fld_doaddmission` varchar(20) NOT NULL DEFAULT '0',
  `fld_password` varchar(50) NOT NULL DEFAULT '0',
  `fld_image` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `action` varchar(10) NOT NULL,
  `exdate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stureg`
--

INSERT INTO `stureg` (`ID`, `fld_firstname`, `fld_middlename`, `fld_lastname`, `fld_contactno`, `fld_address`, `fld_email`, `fld_dob`, `fld_gender`, `fld_branch`, `fld_year`, `fld_doaddmission`, `fld_password`, `fld_image`, `status`, `action`, `exdate`) VALUES
(1, 'aishwarya', 'keshavrao', 'deshpande', '8983627713', 'vayavatmal 445001', 'student@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '12345', 'images/jpg/1518452665slide-4.jpg', '', '', ''),
(2, 'akanksha', 'gajanan', 'karnewar', '7776948293', 'yavatmal 445001', 'akanksha@gmail.com', '1996-05-23', 'female', 'chemical', 'ii', '2018-02-21', '123', 'images/jpg/1518452822logo_red.jpg', '', '', ''),
(3, 'apeksha', 'sandeep', 'dabre', '8983627713', 'yavatmal 445001', 'apeksha@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2018-02-20', '123', 'images/jpg/1518454806logo.jpg', '', '', ''),
(5, 'priya', 'm', 'kochar', '1313131313', 'yavatmal 445001', 'priya@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '1234', 'images/jpg/15184910461518454806logo.jpg', '', '', ''),
(6, 'sayali', 'vinod', 'tinkhede', '1212121212', 'yavatmal 445001', 'sayali@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '1234', 'images/jpg/1518491656DSCN1144.jpg', '', '', ''),
(7, 'pallavi', 'xxx', 'walke', '7507384205', 'yavatmal 445001', 'pallavi@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '1234', 'images/jpg/1518492201DSCN1145.jpg', '', '', ''),
(8, 'shrinidhi', 'umesh', 'bajpayee', '9130832599', 'yavatmal 445001', 'shrinidhi@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '12345', 'images/jpg/1518527913DSCN1149.jpg', '', '', ''),
(9, 'nidhi', 'milind', 'joshi', '7057830133', 'yavatmal 445001', 'nidhi@gmail.com', '1996-05-23', 'female', 'textile', 'iv', '2014-07-01', '123456', 'images/jpg/1518549392DSCN1148.jpg', '', '', ''),
(13, 'kalyani', 'virndraa', 'anjankar', '1111111111', 'valaxmi nagar yavatmal', 'kalyani01@gmail.com', '2018-02-17', 'female', 'civil', 'iv', '2018-02-02', '1234', 'images/jpg/1519797241logo_red.jpg', '', '', ''),
(14, 'first', 'mnid', 'lasab', '5885555555', 'ascas ashbcj ahsb j', 'email@e.com', '1992-10-27', 'female', 'computer science and engg', 'i', '2018-02-01', '123456', 'images/jpg/1519823360logo.jpg', '', '', ''),
(15, 'xyz', 'xyz', 'xyz', '5555555555', 'xxxxxxxxxxxxxx', 'xx@gmail.com', '2018-03-24', 'female', 'computer science and engg', 'iv', '2018-03-16', '1234', 'images/jpg/1519998143jawaharlal-darda-institute-of-engineering-and-technology-jdiet-yavatmal.jpg', '', '', ''),
(16, 'zzzz', 'yyyy', 'xxxx', '6666666666', 'vvvvvvvvvvvvvvvvvvvvv', 'vvvv@gmail.com', '2018-03-30', 'female', 'computer science and engg', 'iv', '2018-03-03', '1234', 'images/jpg/15200062352.jpg', '', '', ''),
(17, 'kkkjk', 'h', 'deshpandee', '2222222222', 'jadvbssakuvbgksd', 'aa@aa.com', '2018-03-22', 'female', 'civil', 'iii', '2018-03-09', '1234', 'images/jpg/15200771321518454806logo.jpg', '', '', ''),
(18, 'xyz', 'xyz', 'xyz', '9999999999', 'jkdbkjzdvdjhj', 'ddd@gmail.com', '2018-03-16', 'female', 'computer science and engg', 'iv', '2018-03-24', '1234', 'images/jpg/15200773321519616211logo.jpg', '', '', ''),
(19, 'aaa', 'bbb', 'ccc', '9898989898', 'hkjkjkkjkjkj', 'ccc@ccc', '2018-03-30', 'female', 'computer science and engg', 'iv', '2018-03-10', '1234', 'images/jpg/15201370521518452822logo_red.jpg', '', '', ''),
(20, 'dsgfuyds', 'ksdfbgj', 'fkbj', '9098765321', 'sahdvhafvhvf', 'reg@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iii', '2018-03-22', '123', 'images/jpg/15201494212.jpg', '', '', ''),
(21, 'rahmi', 'kishore', 'deshkar', '9099999999', 'ufguygfyguyg', 'rashmi@gmail.com', '1997-05-21', 'female', 'computer science and engg', 'iv', '2018-03-30', '123', 'images/jpg/15201518662.jpg', '', '', ''),
(22, 'aishwarya', 'dilip', 'shukla', '7099999999', 'nagpur400023', 'ashukla@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-23', '1234', 'images/jpg/15201819722.jpg', '', '', ''),
(23, 'nupoor', 'm', 'kale', '7066666666', 'kjsdhaisuhciusd', 'nupoor@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-31', '1234', 'images/jpg/15201823162.jpg', '', '', ''),
(24, 'radhika', 'g', 'dhalwar', '7011111111', 'vaadsfdrhfgh', 'rads@gmail.com', '1996-03-30', 'female', 'computer science and engg', 'iv', '2014-08-24', '123', 'images/jpg/15201827242.jpg', '', '', ''),
(25, 'payalll', 'ddd', 'harsheee', '7033333333', 'vavavavavavavayavatmal44500', 'payal@gmail.com', '2018-03-24', 'female', 'computer science and engg', 'iv', '2018-03-10', '1234', 'images/jpg/15201835292.jpg', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_alumni`
--

CREATE TABLE `tbl_alumni` (
  `id` bigint(20) NOT NULL,
  `fld_enroll` varchar(255) NOT NULL DEFAULT '0',
  `fld_faxno` varchar(50) NOT NULL DEFAULT '0',
  `fld_yearofadmission` varchar(60) NOT NULL DEFAULT '0',
  `fld_presentaddress` varchar(255) NOT NULL DEFAULT '0',
  `fld_permanentaddress` varchar(255) NOT NULL DEFAULT '0',
  `fld_bloodgroup` varchar(50) NOT NULL DEFAULT '0',
  `fld_graduationyear` varchar(50) NOT NULL DEFAULT '0',
  `fld_percentage` varchar(50) NOT NULL DEFAULT '0',
  `fld_marksobtained` varchar(255) NOT NULL DEFAULT '0',
  `fld_degreeeclass` varchar(60) NOT NULL DEFAULT '0',
  `fld_designation` varchar(100) NOT NULL DEFAULT '0',
  `fld_officeaddress` varchar(255) NOT NULL DEFAULT '0',
  `fld_guardianname` varchar(255) NOT NULL DEFAULT '0',
  `fld_relation` varchar(255) NOT NULL DEFAULT '0',
  `fld_occupation` varchar(255) NOT NULL DEFAULT '0',
  `fld_seventhsem` varchar(200) NOT NULL DEFAULT '0',
  `fld_eighthsem` varchar(150) NOT NULL DEFAULT '0',
  `fld_examinationpass` varchar(50) NOT NULL DEFAULT '0',
  `fld_examscore` varchar(100) NOT NULL DEFAULT '0',
  `fld_collegename` varchar(100) NOT NULL DEFAULT '0',
  `fld_university` varchar(100) NOT NULL DEFAULT '0',
  `fld_organizationname` varchar(100) NOT NULL DEFAULT '0',
  `fld_course` varchar(100) NOT NULL DEFAULT '0',
  `fld_coursedetail` varchar(255) NOT NULL DEFAULT '0',
  `fld_employed` varchar(50) NOT NULL DEFAULT '0',
  `fld_firm` varchar(100) NOT NULL DEFAULT '0',
  `fld_achievement` varchar(150) NOT NULL DEFAULT '0',
  `fld_feelingaboutcollege` varchar(255) NOT NULL DEFAULT '0',
  `fld_departmenthelp` varchar(255) NOT NULL DEFAULT '0',
  `fld_opinionofstudent` varchar(255) NOT NULL DEFAULT '0',
  `fld_departmentpolicylike` varchar(255) NOT NULL DEFAULT '0',
  `fld_departmentpolicyunlike` varchar(255) NOT NULL DEFAULT '0',
  `fld_facilityfuillfillformdept` varchar(255) NOT NULL DEFAULT '0',
  `fld_policyattractstudent` varchar(255) NOT NULL DEFAULT '0',
  `fld_collegepolicylike` varchar(255) NOT NULL DEFAULT '0',
  `fld_collegepolicydislike` varchar(255) NOT NULL DEFAULT '0',
  `fld_supportforadmission` varchar(255) NOT NULL DEFAULT '0',
  `status` varchar(30) NOT NULL DEFAULT '0',
  `action` varchar(30) NOT NULL DEFAULT '0',
  `exdate` varchar(60) NOT NULL DEFAULT '0',
  `fld_email` varchar(150) NOT NULL DEFAULT '0',
  `fld_branch` varchar(255) NOT NULL DEFAULT '0',
  `fld_firstname` varchar(255) NOT NULL,
  `fld_lastname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_alumni`
--

INSERT INTO `tbl_alumni` (`id`, `fld_enroll`, `fld_faxno`, `fld_yearofadmission`, `fld_presentaddress`, `fld_permanentaddress`, `fld_bloodgroup`, `fld_graduationyear`, `fld_percentage`, `fld_marksobtained`, `fld_degreeeclass`, `fld_designation`, `fld_officeaddress`, `fld_guardianname`, `fld_relation`, `fld_occupation`, `fld_seventhsem`, `fld_eighthsem`, `fld_examinationpass`, `fld_examscore`, `fld_collegename`, `fld_university`, `fld_organizationname`, `fld_course`, `fld_coursedetail`, `fld_employed`, `fld_firm`, `fld_achievement`, `fld_feelingaboutcollege`, `fld_departmenthelp`, `fld_opinionofstudent`, `fld_departmentpolicylike`, `fld_departmentpolicyunlike`, `fld_facilityfuillfillformdept`, `fld_policyattractstudent`, `fld_collegepolicylike`, `fld_collegepolicydislike`, `fld_supportforadmission`, `status`, `action`, `exdate`, `fld_email`, `fld_branch`, `fld_firstname`, `fld_lastname`) VALUES
(1, '14447251', '123456789', '2014', 'aadjhaifbhusdbfudbvgerui', 'aadjhaifbhusdbfudbvgerui', 'ab', '2018', '65', '1000', 'first class', 'agudfsewf', 'kjeqwbfwebfewkj', 'aejfvhewkjhfv', 'qewfbhvewjv', 'dsaaaaaaansdkjsdjkvn jks', 'images/jpg/15200418132.jpg', 'images/jpg/15200418131519616211logo.jpg', 'gate', '10', 'weiufgowuegfiluwegfil', 'national', 'wefuygwyuy', 'yes', 'jhefgyuewuyew', 'no', '', '', 'satisfied', 'always', 'good', 'auyvdskuysefgkuyg', 'zliugfewru', 'yes fully', 'vlufgiulwgulgu', 'skfgukewg', 'ejfgewhy', 'yes', '0', '0', '0', 'student@gmail.com', 'computer science and engg', 'aishwarya', 'deshpande'),
(2, '14447252', '1234', '2013', 'aadjhaifbhusdbfudbvgerui', 'aadjhaifbhusdbfudbvgerui', 'ab+ve', '2017', '70', '1000', 'first class', 'aaaaaaaaa', 'aaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaa', 'dsaaaaaaansdkjsdjkvn jks', 'images/jpg/1519999584contact us.jpg', 'images/jpg/15200418131519616211logo.jpg', 'gate', '10', 'weiufgowuegfiluwegfil', 'national', 'wefuygwyuy', 'yes', 'jhefgyuewuyew', 'no', '0', '0', 'satisfied', 'always', 'good', 'auyvdskuysefgkuyg', 'zliugfewru', 'yes fully', '0vlufgiulwgulgu', 'skfgukewg', 'ejfgewhy', 'yes', '0', '0', '0', 'kalyani01@gmail.com', 'civil', 'kalyani', 'anjankar'),
(3, '1234567', '1111', '2012', 'wjdhawwwwwwwwwwwdgukw.q', 'aydshfvedcgu.kadiuaw.u', 'o', '2016', '68', '1000', 'first class', 'agudfsewf', 'jsadsugfulisegflw', 'mhdtdyhy,y', 'jhyfcyuh', 'yukdkytdfku', 'images/jpg/1519999584contact us.jpg', 'images/jpg/15199995842.jpg', 'gate', '9', 'weiufgowuegfiluwegfil', 'national', 'wefuygwyuy', 'yes', 'jhefgyuewuyew', 'no', '', '', 'satisfied', 'always', 'good', 'auyvdskuysefgkuyg', 'zliugfewru', 'yes fully', 'vlufgiulwgulgu', 'skfgukewg', 'ejfgewhy', 'yes', '0', '0', '0', 'akanksha@gmail.com', 'chemical', 'akanksha', 'karnewar'),
(4, '14447257', '223457', '2011', 'jdddddf,hassssscbgf.u', 'jdddddf,hassssscbgf.u', 'ab', '2015', '65', '1000', 'first class', 'agudfsewf', 'kjeqwbfwebfewkj', 'aejfvhewkjhfv', 'qewfbhvewjv', 'ewqfiugw', 'images/jpg/15200418132.jpg', 'images/jpg/15200418131519616211logo.jpg', 'gate', '10', 'weiufgowuegfiluwegfil', 'national', 'wefuygwyuy', 'yes', 'jhefgyuewuyew', 'no', '', '', 'satisfied', 'always', 'good', 'auyvdskuysefgkuyg', 'zliugfewru', 'yes fully', 'vlufgiulwgulgu', 'skfgukewg', 'ejfgewhy', 'yes', '0', '0', '0', 'nidhi@gmail.com', 'textile', 'nidhi', 'joshi'),
(7, '14447259', '12345678910', '2014', 'hguewfguyewguyefgluwf', 'ejgfuwefguwegfu', 'ab', '2018', '60', '0', 'first class', 'udfguds', 'sekufygushgijsdhjgfyusfyugguygefuhewjjk', 'hfiuewfhuiwefhi', 'wfegusd', 'fsdjfguh', 'images/jpg/15201520822.jpg', 'images/jpg/15201520821518454806logo.jpg', 'gate', '25', 'dsjfvhfbgh', 'national', 'sdjvh', 'yes', 'sdfguyds', 'no', '', 'dskfjbdsgfuyds', 'satisfied', 'always', 'good', 'snfiurgsdhgk', 'sdkjgfuguisdgf', 'yes fully', 'sdfgiuashrugf', 'sfdjgbfds', 'dskgj', 'yes', '0', '0', '0', 'rashmi@gmail.com', 'computer science and engg', 'rahmi', 'deshkar'),
(9, '14447260', '5678920123', '2014', 'jgfhgwhjebfhbhdsjghc', 'sadhvhsjjdsfgjugu', 'ab+ve', '2018', '60', '0', 'first class', 'dcgukj', 'ugdc', 'uggug', 'dskcu', 'dc', 'images/jpg/15201842521519616211logo.jpg', 'images/jpg/15201842522.jpg', 'gate', '10', 'kiduf', 'national', 'efiu', 'yes', 'aefuigiwl', 'yes', 'eksfgkuy', 'kuyfyuf', 'unsatisfied', 'always', 'not so good', 'jgkuyfgyfyf', 'liughiu', 'yes fully', 'khiluhioh;o', 'jhvkyufgu', 'jhvkuy', 'yes', '0', '0', '0', 'payal@gmail.com', 'computer science and engg', 'payalll', 'harsheee');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_campusrecruit`
--

CREATE TABLE `tbl_campusrecruit` (
  `id` bigint(100) NOT NULL,
  `fld_companyname` varchar(255) NOT NULL,
  `fld_batcheligible` varchar(255) NOT NULL DEFAULT '0',
  `fld_bracheligible` varchar(255) NOT NULL DEFAULT '0',
  `fld_jobprofile` varchar(255) NOT NULL DEFAULT '0',
  `fld_joblocation` varchar(255) NOT NULL DEFAULT '0',
  `fld_eligibilitycriteria` varchar(255) NOT NULL DEFAULT '0',
  `fld_salary` varchar(255) NOT NULL DEFAULT '0',
  `fld_reglink` varchar(255) NOT NULL DEFAULT '0',
  `fld_skillreqd` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `status` bigint(100) NOT NULL DEFAULT '0',
  `action` varchar(100) NOT NULL DEFAULT '0',
  `exdate` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_campusrecruit`
--

INSERT INTO `tbl_campusrecruit` (`id`, `fld_companyname`, `fld_batcheligible`, `fld_bracheligible`, `fld_jobprofile`, `fld_joblocation`, `fld_eligibilitycriteria`, `fld_salary`, `fld_reglink`, `fld_skillreqd`, `fld_email`, `status`, `action`, `exdate`) VALUES
(1, 'tcs', '2018', 'cse', 'developer', 'pune', '70', '500000', 'www.tcs.org', 'c,c++', 'student@gmail.com', 0, '0', '0'),
(3, 'amdocs', '2017,2018', 'cse', 'java developer', 'usa', '65% aggregate', '500000', 'www.amdocs.com', 'java concepts should be cleared', 'rashmi@gmail.com', 0, '0', '0'),
(7, 'wipro', '2018 2017 2015', 'cse', 'android developer', 'pune', '65%aggregaate', '400000', 'wipro.com', 'advance java', 'payal@gmail.com', 0, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE `tbl_company` (
  `id` bigint(100) NOT NULL,
  `fld_companyname` varchar(255) NOT NULL DEFAULT '0',
  `fld_designation` varchar(255) NOT NULL DEFAULT '0',
  `fld_location` varchar(255) NOT NULL DEFAULT '0',
  `fld_package` varchar(255) NOT NULL DEFAULT '0',
  `fld_joineddate` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `status` bigint(100) NOT NULL DEFAULT '0',
  `action` varchar(150) NOT NULL DEFAULT '0',
  `exdate` varchar(200) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`id`, `fld_companyname`, `fld_designation`, `fld_location`, `fld_package`, `fld_joineddate`, `fld_email`, `status`, `action`, `exdate`) VALUES
(1, 'wipro', 'developer', 'banglore', '600000', '2018-03-15', 'student@gmail.com', 0, '0', '0'),
(2, 'infosys', 'tester', 'hyderabad', '600000', '2018-03-14', 'akanksha@gmail.com', 0, '0', '0'),
(7, 'amdocs', 'software developer', 'usa', '700000', '2018-02-06', 'rashmi@gmail.com', 0, '0', '0'),
(11, 'wipro', 's/w developer', 'pune', '500000', '2018-03-23', 'payal@gmail.com', 0, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_eventgeneration`
--

CREATE TABLE `tbl_eventgeneration` (
  `id` bigint(50) NOT NULL,
  `fld_eventtitle` varchar(255) NOT NULL DEFAULT '0',
  `fld_description` varchar(255) NOT NULL DEFAULT '0',
  `fld_date` varchar(255) NOT NULL DEFAULT '0',
  `fld_starttime` varchar(255) NOT NULL DEFAULT '0',
  `status` varchar(50) NOT NULL DEFAULT '0',
  `action` varchar(60) NOT NULL DEFAULT '0',
  `exdate` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_eventgeneration`
--

INSERT INTO `tbl_eventgeneration` (`id`, `fld_eventtitle`, `fld_description`, `fld_date`, `fld_starttime`, `status`, `action`, `exdate`) VALUES
(1, 'euphoria2k18', 'parents meet dances dramas', '2018-01-20', '10:00am', '0', '0', '0'),
(2, 'technoextreme', 'national level technical event ', '2018-03-17', '10:00am', '0', '0', '0'),
(3, 'sfilata', 'fashion show paper presentation', '2018-03-23', '10:00am', '0', '0', '0'),
(4, 'iot expert lecture', 'guest lecture on Big data and iot', '2018-03-31', '11:am', '0', '0', '0'),
(5, 'smart photography', 'photographs ', '2018-02-02', '12pm', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fumd`
--

CREATE TABLE `tbl_fumd` (
  `id` bigint(100) NOT NULL,
  `fld_fundamount` varchar(255) NOT NULL DEFAULT '0',
  `fld_fundtype` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `status` bigint(100) NOT NULL DEFAULT '0',
  `action` varchar(255) NOT NULL DEFAULT '0',
  `exdate` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_fumd`
--

INSERT INTO `tbl_fumd` (`id`, `fld_fundamount`, `fld_fundtype`, `fld_email`, `status`, `action`, `exdate`) VALUES
(1, '6000', 'scholarship', 'student@gmail.com', 0, '0', '0'),
(4, '10000', 'donation', 'rashmi@gmail.com', 0, '0', '0'),
(8, '10000', 'donation', 'payal@gmail.com', 0, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_others`
--

CREATE TABLE `tbl_others` (
  `id` bigint(100) NOT NULL,
  `fld_uploadresume` text NOT NULL,
  `fld_facebooklink` varchar(255) NOT NULL,
  `fld_linkedinlink` varchar(255) NOT NULL,
  `fld_twitterlink` varchar(255) NOT NULL,
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `status` bigint(100) NOT NULL DEFAULT '0',
  `action` varchar(100) NOT NULL DEFAULT '0',
  `exdate` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_others`
--

INSERT INTO `tbl_others` (`id`, `fld_uploadresume`, `fld_facebooklink`, `fld_linkedinlink`, `fld_twitterlink`, `fld_email`, `status`, `action`, `exdate`) VALUES
(1, 'images/docs/1520138119Aishwarya Resume.docx', 'www.facebook.com', 'www.linkedin.com', 'www.teitter.com', 'student@gmail.com', 0, '0', '0'),
(3, 'images/docs/1520152164attachment.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'rashmi@gmail.com', 0, '0', '0'),
(7, 'images/docs/1520184302Cyber security.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'payal@gmail.com', 0, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pastevents`
--

CREATE TABLE `tbl_pastevents` (
  `id` bigint(100) NOT NULL,
  `fld_eventtitle` varchar(255) NOT NULL DEFAULT '0',
  `fld_description` varchar(255) NOT NULL DEFAULT '0',
  `fld_date` varchar(100) NOT NULL DEFAULT '0',
  `fld_pics` text NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT '0',
  `action` varchar(100) NOT NULL DEFAULT '0',
  `exdate` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pastevents`
--

INSERT INTO `tbl_pastevents` (`id`, `fld_eventtitle`, `fld_description`, `fld_date`, `fld_pics`, `status`, `action`, `exdate`) VALUES
(1, 'ganesh festival', 'ganapati poojan', '2017-09-14', 'images/jpg/1519720705logo.jpg', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staffreg`
--

CREATE TABLE `tbl_staffreg` (
  `id` bigint(20) NOT NULL,
  `fld_firstname` varchar(255) NOT NULL DEFAULT '0',
  `fld_middlename` varchar(255) NOT NULL DEFAULT '0',
  `fld_lastname` varchar(255) NOT NULL DEFAULT '0',
  `fld_contactno` varchar(20) NOT NULL DEFAULT '0',
  `fld_address` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `fld_dateofbirth` varchar(50) NOT NULL DEFAULT '0',
  `fld_gender` varchar(60) NOT NULL DEFAULT '0',
  `fld_designation` varchar(255) NOT NULL DEFAULT '0',
  `fld_password` varchar(50) NOT NULL DEFAULT '0',
  `fld_photo` text NOT NULL,
  `status` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `exdate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_staffreg`
--

INSERT INTO `tbl_staffreg` (`id`, `fld_firstname`, `fld_middlename`, `fld_lastname`, `fld_contactno`, `fld_address`, `fld_email`, `fld_dateofbirth`, `fld_gender`, `fld_designation`, `fld_password`, `fld_photo`, `status`, `action`, `exdate`) VALUES
(1, 'jitendra', 'h', 'saturwar', '8879223111', 'jdiet yavatmal 445001', 'admin@admin.com', '1971-06-14', 'male', 'hod', 'admin1234', 'images/jpg/151868813415186869822.jpg', '', '', ''),
(2, 'dinesh', 'n', 'chaudhari', '9422961063', 'jdiet yavatmal', 'dnchaudhari2007@rediffmail.com', '1975-01-01', 'male', 'professor', '1234', 'images/jpg/151868825515186869822.jpg', '', '', ''),
(3, 'sachin', 'm', 'inzalkar', '9561538975', 'jdiet yavatmal', 'sachininzalkar@gmail.com', '2018-01-18', 'male', 'assistant professor', '1234', 'images/jpg/151868836315186869822.jpg', '', '', ''),
(4, 'ahitesham', 'n', 'kazi', '9890461597', 'jdiet yavatmal', 'kazi_aihtesham@rediffmail.com', '2018-02-19', 'male', 'assistant professor', '1234', 'images/jpg/151868845615184910461518454806logo.jpg', '', '', ''),
(5, 'vivek', 'r', 'shelke', '9049093583', 'jdiet yavatmal', 'vvshelke@gmail.com', '2010-10-17', 'male', 'assistant professor', '1234', 'images/jpg/151903587215184910461518454806logo.jpg', '', '', ''),
(6, 'prasad', 'p', 'lokulwar', '7709811688', 'jdiet yavatmal', 'prasadengg16@gmail.com', '2012-11-16', 'male', 'assistant professor', '1234', 'images/jpg/151903716915186869822.jpg', '', '', ''),
(7, 'chetan', 's', 'dhamande', '9763540956', 'jdiet yavatmal', 'chetan.dhamande@gmail.com', '1972-02-15', 'male', 'assistant professor', '1234', 'images/jpg/1519313903DSCN1152.jpg', '', '', ''),
(8, 'avinash', 'p', 'jadhav', '9421786127', 'jdiet yavatmal', 'apjadhao@gmail.com', '1975-01-10', 'male', 'assistant professor', 'avinash123', 'images/jpg/1519616211logo.jpg', '', '', ''),
(9, 'staff', 'staff', 'staff', '1212121212', 'jdiet yavatmal', 'staff@gmail.com', '1983-06-13', 'male', 'assistant professor', 'staff1234', 'images/jpg/1519617920logo.jpg', '', '', ''),
(10, 'jjjjjj', 'kkkk', 'llll', '1000000000', 'kfbfbbfbsgfbv', 'xxx@gmail.com', '2018-03-29', 'female', 'dhdhiu', '123', 'images/jpg/15201492461519616211logo.jpg', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stureg`
--
ALTER TABLE `stureg`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_campusrecruit`
--
ALTER TABLE `tbl_campusrecruit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_company`
--
ALTER TABLE `tbl_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_eventgeneration`
--
ALTER TABLE `tbl_eventgeneration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fumd`
--
ALTER TABLE `tbl_fumd`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_others`
--
ALTER TABLE `tbl_others`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pastevents`
--
ALTER TABLE `tbl_pastevents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_staffreg`
--
ALTER TABLE `tbl_staffreg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stureg`
--
ALTER TABLE `stureg`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_campusrecruit`
--
ALTER TABLE `tbl_campusrecruit`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_company`
--
ALTER TABLE `tbl_company`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_eventgeneration`
--
ALTER TABLE `tbl_eventgeneration`
  MODIFY `id` bigint(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_fumd`
--
ALTER TABLE `tbl_fumd`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_others`
--
ALTER TABLE `tbl_others`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_pastevents`
--
ALTER TABLE `tbl_pastevents`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_staffreg`
--
ALTER TABLE `tbl_staffreg`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
