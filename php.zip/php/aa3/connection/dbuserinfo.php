<?php
$serverName="localhost";
$userName="root";
$password="";
$databaseName="projectdb";
?>