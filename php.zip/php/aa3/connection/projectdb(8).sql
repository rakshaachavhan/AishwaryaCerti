-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2018 at 05:50 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `stureg`
--

CREATE TABLE `stureg` (
  `ID` bigint(20) NOT NULL,
  `fld_firstname` varchar(255) NOT NULL DEFAULT '0',
  `fld_middlename` varchar(255) NOT NULL DEFAULT '0',
  `fld_lastname` varchar(255) NOT NULL DEFAULT '0',
  `fld_contactno` varchar(15) NOT NULL DEFAULT '0',
  `fld_address` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `fld_dob` varchar(100) NOT NULL DEFAULT '0',
  `fld_gender` varchar(20) NOT NULL DEFAULT '0',
  `fld_branch` varchar(40) NOT NULL DEFAULT '0',
  `fld_year` varchar(10) NOT NULL DEFAULT '0',
  `fld_doaddmission` varchar(20) NOT NULL DEFAULT '0',
  `fld_password` varchar(50) NOT NULL DEFAULT '0',
  `fld_image` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `action` varchar(10) NOT NULL,
  `exdate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stureg`
--

INSERT INTO `stureg` (`ID`, `fld_firstname`, `fld_middlename`, `fld_lastname`, `fld_contactno`, `fld_address`, `fld_email`, `fld_dob`, `fld_gender`, `fld_branch`, `fld_year`, `fld_doaddmission`, `fld_password`, `fld_image`, `status`, `action`, `exdate`) VALUES
(1, 'aishwaryaa', 'keshavrao', 'deshpande', '8983627713', 'yavatmal 4450011', 'student@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '12345', 'images/jpg/1518452665slide-4.jpg', '', '', ''),
(2, 'akanksha', 'gajanan', 'karnewar', '7776948293', 'vayyyyyyyyyyyyyyyyyyyy', 'akanksha@gmail.com', '1996-05-23', 'female', 'chemical', 'ii', '2018-02-21', '12345', 'images/jpg/1518452822logo_red.jpg', '', '', ''),
(3, 'apeksha', 'sandeep', 'dabre', '8983627713', 'yavatmal 445001', 'apeksha@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2018-02-20', '123', 'images/jpg/1518454806logo.jpg', '', '', ''),
(5, 'priya', 'm', 'kochar', '1313131313', 'yavatmal 445001', 'priya@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '1234', 'images/jpg/15184910461518454806logo.jpg', '', '', ''),
(6, 'sayali', 'vinod', 'tinkhede', '1212121212', 'yavatmal 445001', 'sayali@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '1234', 'images/jpg/1518491656DSCN1144.jpg', '', '', ''),
(7, 'pallavi', 'xxx', 'walke', '7507384205', 'yavatmal 445001', 'pallavi@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '1234', 'images/jpg/1518492201DSCN1145.jpg', '', '', ''),
(8, 'shrinidhi', 'umesh', 'bajpayee', '9130832599', 'yavatmal 445001', 'shrinidhi@gmail.com', '1996-05-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '12345', 'images/jpg/1518527913DSCN1149.jpg', '', '', ''),
(9, 'nidhi', 'milind', 'joshi', '7057830133', 'yavatmal 445001', 'nidhi@gmail.com', '1996-05-23', 'female', 'textile', 'iv', '2014-07-01', '123456', 'images/jpg/1518549392DSCN1148.jpg', '', '', ''),
(13, 'kalyani', 'virndraa', 'anjankar', '1111111111', 'laxmi nagar yavatmal', 'kalyani01@gmail.com', '2018-02-17', 'female', 'civil', 'iv', '2018-02-02', '1234', 'images/jpg/1519797241logo_red.jpg', '', '', ''),
(14, 'first', 'mnid', 'lasab', '5885555555', 'ascas ashbcj ahsb j', 'email@e.com', '1992-10-27', 'female', 'computer science and engg', 'i', '2018-02-01', '123456', 'images/jpg/1519823360logo.jpg', '', '', ''),
(21, 'rahmi', 'kishore', 'deshkar', '9099999999', 'ufguygfyguyg', 'rashmi@gmail.com', '1997-05-21', 'female', 'computer science and engg', 'iv', '2018-03-30', '123', 'images/jpg/15201518662.jpg', '', '', ''),
(22, 'aishwarya', 'dilip', 'shukla', '7099999999', 'nagpur400023', 'ashukla@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-23', '1234', 'images/jpg/15201819722.jpg', '', '', ''),
(23, 'nupoor', 'm', 'kale', '7066666666', 'kjsdhaisuhciusd', 'nupoor@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-31', '1234', 'images/jpg/15201823162.jpg', '', '', ''),
(24, 'radhika', 'g', 'dhalwar', '7011111111', 'vaadsfdrhfgh', 'rads@gmail.com', '1996-03-30', 'female', 'computer science and engg', 'iv', '2014-08-24', '123', 'images/jpg/15201827242.jpg', '', '', ''),
(25, 'payalll', 'ddd', 'harsheee', '7033333333', 'yavatmal44500', 'payal@gmail.com', '2018-03-24', 'female', 'computer science and engg', 'iv', '2018-03-10', '1234', 'images/jpg/15201835292.jpg', '', '', ''),
(27, 'vaishnaviii', 'jaywant', 'deshpande', '7100000000', 'balaji society yavatmal', 'vaishnavi@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-03', '123', 'images/jpg/15203480082.jpg', '', '', ''),
(28, 'shweta', 'aashutosh', 'deshpande', '5678888888', 'manish nagar nagpur', 'shweta@gmail.com', '2018-03-16', 'female', 'computer science and engg', 'iv', '2018-03-30', '123', 'images/jpg/15208563441519617920logo.jpg', '', '', ''),
(29, 'shambhavi', 'aashutosh', 'deshpande', '4566666666', 'manish nagpur', 'shambhavi@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-31', '123', 'images/jpg/15208587091518454806logo.jpg', '', '', ''),
(30, 'sampada', 'shyam', 'chande', '4322222222', 'dugfuygfyuyug', 'sampada@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-17', '123', 'images/jpg/15208608711519616211logo.jpg', '', '', ''),
(31, 'ambika', 'keashavrao', 'deshpande', '7030123430', 'nanded city pune', 'ambikadeshpande@gmail.com', '1991-09-30', 'female', 'computer science and engg', 'iv', '2013-02-07', '123', 'images/jpg/15212211471518454806logo.jpg', '', '', ''),
(32, 'ambika', 'k', 'deshpande', '7030900000', 'nanded city pune', 'ambika@gmail.com', '2018-03-03', 'female', 'computer science and engg', 'iv', '2018-03-31', '123', 'images/jpg/15212213472.jpg', '', '', ''),
(33, 'anagha', 'k', 'deshpande', '9767103740', 'asjfbguessaca', 'anagha@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-16', '123', 'images/jpg/15212229762.jpg', '', '', ''),
(34, 'anagha', 'keshavrao', 'deshpande', '9767103742', 'pune-678922', 'anaghadeshpande@gmail.com', '2018-02-05', 'female', 'computer science and engg', 'iv', '2018-03-15', '123', 'images/jpg/15212232092.jpg', '', '', ''),
(35, 'rahul', 'm', 'deshapnde', '9767103745', 'pune 67893', 'rahul@gmail.com', '2018-03-24', 'female', 'computer science and engg', 'iv', '2018-03-16', '123', 'images/jpg/15212281782.jpg', '', '', ''),
(36, 'aa', 'bb', 'cc', '1111111111', 'aliugfkysegfuyguy', 'studento1@gmail.com', '2018-03-22', 'female', 'computer science and engg', 'iv', '2018-03-24', '123', 'images/jpg/15220901362.jpg', '', '', ''),
(37, 'aa', 'bb', 'cc', '1111111111', 'ahgakyugfkyueg', 'student01@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-30', '123', 'images/jpg/15220913752.jpg', '', '', ''),
(38, 'aaa', 'bbbb', 'ccc', '7896543210', 'yavatmal4450011', 'aaabbb@gmail.com', '2018-03-31', 'female', 'computer science and engg', 'iv', '2018-03-30', '1234', 'images/jpg/15220947682.jpg', '', '', ''),
(39, 'aishwarya', 'keshavrao', 'deshpandee', '9657881460', 'gsyudgyuasgfuias', 'adeshpande@gmail.com', '2018-03-23', 'female', 'computer science and engg', 'iv', '2018-03-31', '12345', 'images/jpg/15220955152.jpg', '', '', ''),
(40, 'anish', 'abhay', 'deshpande', '3456789214', 'yavatmal 4450011', 'anishdeshpande@gmail.com', '2018-03-16', 'male', 'computer science and engg', 'iv', '2018-03-31', '123', 'images/jpg/15220965522.jpg', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_alumni`
--

CREATE TABLE `tbl_alumni` (
  `id` bigint(20) NOT NULL,
  `fld_enroll` varchar(255) NOT NULL DEFAULT '0',
  `fld_faxno` varchar(50) NOT NULL DEFAULT '0',
  `fld_yearofadmission` varchar(60) NOT NULL DEFAULT '0',
  `fld_presentaddress` varchar(255) NOT NULL DEFAULT '0',
  `fld_permanentaddress` varchar(255) NOT NULL DEFAULT '0',
  `fld_bloodgroup` varchar(50) NOT NULL DEFAULT '0',
  `fld_graduationyear` varchar(50) NOT NULL DEFAULT '0',
  `fld_percentage` varchar(50) NOT NULL DEFAULT '0',
  `fld_marksobtained` varchar(255) NOT NULL DEFAULT '0',
  `fld_degreeeclass` varchar(60) NOT NULL DEFAULT '0',
  `fld_designation` varchar(100) NOT NULL DEFAULT '0',
  `fld_officeaddress` varchar(255) NOT NULL DEFAULT '0',
  `fld_guardianname` varchar(255) NOT NULL DEFAULT '0',
  `fld_relation` varchar(255) NOT NULL DEFAULT '0',
  `fld_occupation` varchar(255) NOT NULL DEFAULT '0',
  `fld_seventhsem` varchar(200) NOT NULL DEFAULT '0',
  `fld_eighthsem` varchar(150) NOT NULL DEFAULT '0',
  `fld_examinationpass` varchar(50) NOT NULL DEFAULT '0',
  `fld_examscore` varchar(100) NOT NULL DEFAULT '0',
  `fld_collegename` varchar(100) NOT NULL DEFAULT '0',
  `fld_university` varchar(100) NOT NULL DEFAULT '0',
  `fld_organizationname` varchar(100) NOT NULL DEFAULT '0',
  `fld_course` varchar(100) NOT NULL DEFAULT '0',
  `fld_coursedetail` varchar(255) NOT NULL DEFAULT '0',
  `fld_employed` varchar(50) NOT NULL DEFAULT '0',
  `fld_firm` varchar(100) NOT NULL DEFAULT '0',
  `fld_achievement` varchar(150) NOT NULL DEFAULT '0',
  `fld_feelingaboutcollege` varchar(255) NOT NULL DEFAULT '0',
  `fld_departmenthelp` varchar(255) NOT NULL DEFAULT '0',
  `fld_opinionofstudent` varchar(255) NOT NULL DEFAULT '0',
  `fld_departmentpolicylike` varchar(255) NOT NULL DEFAULT '0',
  `fld_departmentpolicyunlike` varchar(255) NOT NULL DEFAULT '0',
  `fld_facilityfuillfillformdept` varchar(255) NOT NULL DEFAULT '0',
  `fld_policyattractstudent` varchar(255) NOT NULL DEFAULT '0',
  `fld_collegepolicylike` varchar(255) NOT NULL DEFAULT '0',
  `fld_collegepolicydislike` varchar(255) NOT NULL DEFAULT '0',
  `fld_supportforadmission` varchar(255) NOT NULL DEFAULT '0',
  `status` varchar(30) NOT NULL DEFAULT '0',
  `action` varchar(30) NOT NULL DEFAULT '0',
  `exdate` varchar(60) NOT NULL DEFAULT '0',
  `fld_email` varchar(150) NOT NULL DEFAULT '0',
  `fld_branch` varchar(255) NOT NULL DEFAULT '0',
  `fld_firstname` varchar(255) NOT NULL,
  `fld_lastname` varchar(255) NOT NULL,
  `fld_rollno` varchar(200) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_alumni`
--

INSERT INTO `tbl_alumni` (`id`, `fld_enroll`, `fld_faxno`, `fld_yearofadmission`, `fld_presentaddress`, `fld_permanentaddress`, `fld_bloodgroup`, `fld_graduationyear`, `fld_percentage`, `fld_marksobtained`, `fld_degreeeclass`, `fld_designation`, `fld_officeaddress`, `fld_guardianname`, `fld_relation`, `fld_occupation`, `fld_seventhsem`, `fld_eighthsem`, `fld_examinationpass`, `fld_examscore`, `fld_collegename`, `fld_university`, `fld_organizationname`, `fld_course`, `fld_coursedetail`, `fld_employed`, `fld_firm`, `fld_achievement`, `fld_feelingaboutcollege`, `fld_departmenthelp`, `fld_opinionofstudent`, `fld_departmentpolicylike`, `fld_departmentpolicyunlike`, `fld_facilityfuillfillformdept`, `fld_policyattractstudent`, `fld_collegepolicylike`, `fld_collegepolicydislike`, `fld_supportforadmission`, `status`, `action`, `exdate`, `fld_email`, `fld_branch`, `fld_firstname`, `fld_lastname`, `fld_rollno`) VALUES
(1, '14447251', '123456789', '2014', 'aadjhaifbhusdbfudbvgerui', 'aadjhaifbhusdbfudbvgerui', 'ab', '2018', '65', '1000', 'first class', 'agudfsewf', 'kjeqwbfwebfewkj', 'aejfvhewkjhfv', 'qewfbhvewjv', 'dsaaaaaaansdkjsdjkvn jks', 'images/jpg/15200418132.jpg', 'images/jpg/15200418131519616211logo.jpg', 'gate', '10', 'weiufgowuegfiluwegfil', 'national', 'wefuygwyuy', 'yes', 'jhefgyuewuyew', 'no', '', '', 'satisfied', 'always', 'good', 'auyvdskuysefgkuyg', 'zliugfewru', 'yes fully', 'vlufgiulwgulgu', 'skfgukewg', 'ejfgewhy', 'yes', '0', '0', '0', 'student@gmail.com', 'computer science and engg', 'aishwaryaa', 'deshpande', '1311'),
(2, '14447252', '1234', '2013', 'aadjhaifbhusdbfudbvgerui', 'aadjhaifbhusdbfudbvgerui', 'ab+ve', '2017', '70', '1000', 'first class', 'aaaaaaaaa', 'aaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaaaaaaa', 'dsaaaaaaansdkjsdjkvn jks', 'images/jpg/1519999584contact us.jpg', 'images/jpg/15200418131519616211logo.jpg', 'gate', '10', 'weiufgowuegfiluwegfil', 'national', 'wefuygwyuy', 'yes', 'jhefgyuewuyew', 'no', '0', '0', 'satisfied', 'always', 'good', 'auyvdskuysefgkuyg', 'zliugfewru', 'yes fully', '0vlufgiulwgulgu', 'skfgukewg', 'ejfgewhy', 'yes', '0', '0', '0', 'kalyani01@gmail.com', 'civil', 'kalyani', 'anjankar', '1411'),
(3, '1234567', '1111', '2012', 'wjdhawwwwwwwwwwwdgukw.q', 'aydshfvedcgu.kadiuaw.u', 'o', '2016', '68', '1000', 'first class', 'agudfsewf', 'jsadsugfulisegflw', 'mhdtdyhy,y', 'jhyfcyuh', 'yukdkytdfku', 'images/jpg/1519999584contact us.jpg', 'images/jpg/15199995842.jpg', 'gate', '9', 'weiufgowuegfiluwegfil', 'national', 'wefuygwyuy', 'yes', 'jhefgyuewuyew', 'no', '', '', 'satisfied', 'always', 'good', 'auyvdskuysefgkuyg', 'zliugfewru', 'yes fully', 'vlufgiulwgulgu', 'skfgukewg', 'ejfgewhy', 'yes', '0', '0', '0', 'akanksha@gmail.com', 'chemical', 'akanksha', 'karnewar', '1511'),
(4, '14447257', '223457', '2011', 'jdddddf,hassssscbgf.u', 'jdddddf,hassssscbgf.u', 'ab', '2015', '65', '1000', 'first class', 'agudfsewf', 'kjeqwbfwebfewkj', 'aejfvhewkjhfv', 'qewfbhvewjv', 'ewqfiugw', 'images/jpg/15200418132.jpg', 'images/jpg/15200418131519616211logo.jpg', 'gate', '10', 'weiufgowuegfiluwegfil', 'national', 'wefuygwyuy', 'yes', 'jhefgyuewuyew', 'no', '', '', 'satisfied', 'always', 'good', 'auyvdskuysefgkuyg', 'zliugfewru', 'yes fully', 'vlufgiulwgulgu', 'skfgukewg', 'ejfgewhy', 'yes', '0', '0', '0', 'nidhi@gmail.com', 'textile', 'nidhi', 'joshi', '1611'),
(7, '14447259', '12345678910', '2014', 'hguewfguyewguyefgluwf', 'ejgfuwefguwegfu', 'ab', '2018', '60', '1000', 'first class', 'udfguds', 'sekufygushgijsdhjgfyusfyugguygefuhewjjk', 'hfiuewfhuiwefhi', 'wfegusd', 'fsdjfguh', 'images/jpg/15201520822.jpg', 'images/jpg/15201520821518454806logo.jpg', 'gate', '25', 'dsjfvhfbgh', 'national', 'sdjvh', 'yes', 'sdfguyds', 'no', '', 'dskfjbdsgfuyds', 'satisfied', 'always', 'good', 'snfiurgsdhgk', 'sdkjgfuguisdgf', 'yes fully', 'sdfgiuashrugf', 'sfdjgbfds', 'dskgj', 'yes', '0', '0', '0', 'rashmi@gmail.com', 'computer science and engg', 'rahmi', 'deshkar', '1711'),
(9, '14447260', '5678920123', '2014', 'jgfhgwhjebfhbhdsjghc', 'sadhvhsjjdsfgjugu', 'ab+ve', '2017', '60', '1000', 'first class', 'dcgukj', 'ugdc', 'uggug', 'dskcu', 'dc', 'images/jpg/15201842521519616211logo.jpg', 'images/jpg/15201842522.jpg', 'gate', '10', 'kiduf', 'national', 'efiu', 'yes', 'aefuigiwl', 'yes', 'eksfgkuy', 'kuyfyuf', 'unsatisfied', 'always', 'not so good', 'jgkuyfgyfyf', 'liughiu', 'yes fully', 'khiluhioh;o', 'jhvkyufgu', 'jhvkuy', 'yes', '0', '0', '0', 'payal@gmail.com', 'computer science and engg', 'payalll', 'harsheee', '1811'),
(11, '1234567', '12345678911', '2013', 'vsahcjb,ascvyjhs', 'sdfuigudsy', 'asjgdckusycgf', 'askdjcnkjsdbvk', '70', '1000', 'distinction', 'asfgyu', 'askfgukyfgyu', 'saiudf', 'askch', 'dacvhj', 'images/jpg/15203481851519616211logo.jpg', 'images/jpg/15203481851518452822logo_red.jpg', 'gate', '21', 'dscuisdglv', 'national', 'ukydsgvdsyu', 'yes', 'dsjvkshdy', 'yes', 'sdiucgsdiulf', 'cdkjxbvjdbs', 'satisfied', 'always', 'good', 'kvchsilduhvul', 'zdkjvbdls', 'yes fully', 'cavscvuyl', 'cdbu', 'zxkcjbgdu', 'yes', '0', '0', '0', 'vaishnavi@gmail.com', 'computer science and engg', 'vaishnaviii', 'deshpande', '1911'),
(12, '14447270', '2678888888888', '2014', 'jhbfhejfve', 'fkewfhiubfuiew', 'ab', '2018', '70', '1000', 'first class', 'dsfjh', 'zkjcbjh', 'zxc.kjbkj', 'xz,ck n', 'xzc., c', 'images/jpg/15208567732.jpg', 'images/jpg/15208567732.jpg', 'gate', '10', 'fguysgfuyglsidfuik', 'national', 'sadasfd', 'yes', 'fdsiugsdgl', 'yes', 'kuyfuyfiygkuhvgkuyguk', 'jygfytfytfutfdtrf', 'satisfied', 'always', 'good', 'uygyfygukhli', 'dsfkjksdgfuds', 'yes fully', 'dsjbjhdsbh', 'ljfyfkyuvf', 'dskfhdsuguf', 'yes', '0', '0', '0', 'shweta@gmail.com', 'computer science and engg', 'shweta', 'deshpande', '10117'),
(13, '', '', '', '', '', '', '', '', '1000', '', '', '', '', '', '', 'images/jpg/default.jpg', 'images/jpg/default.jpg', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '0', '0', 'shambhavi@gmail.com', 'computer science and engg', 'shambhavi', 'deshpande', '0'),
(14, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'sampada@gmail.com', 'computer science and engg', 'sampada', 'chande', '0'),
(15, '164479160590', '2345678900', '2014', 'osjadoajfioasjijo', 'fsaihaisuhiuahsf', 'ab', '2017', '65', '1100', 'distinction', 'nothing', 'aifhiaoehoihoidc', 'siofhiasuhf', 'skifchuasif', 'sakfhoius', 'images/jpg/15212218231518454806logo.jpg', 'images/jpg/15212218231519616211logo.jpg', 'gate', 'asiugtdu', 'saiufgu', 'national', 'saufg', 'yes', 'saiudga8u', 'yes', 'askjdgukya', 'ajsdugfakgdsufky', 'satisfied', 'always', 'good', 'lsahfioasdhf', 'asdkifhiuadsfh', 'yes fully', 'asufguays', 'iasufyseu8oi', 'asiufgieu', 'yes', '0', '0', '0', 'ambikadeshpande@gmail.com', 'computer science and engg', 'ambika', 'deshpande', '31332'),
(16, '164479160592', '', '2011', 'nanded city pune', 'nanded city pune', 'ab', '2015', '65', '1210', 'distinction', 'developer', 'infosys hyderabad', 'sameer', 'kulkarni', 'engineer', 'images/jpg/15212277592.jpg', 'images/jpg/15212277592.jpg', 'gate', '25', 'ramdev baba', 'national', 'ramdev baba', 'yes', 'big data hadoop', 'yes', 'infosys hyderabad', 'no', 'satisfied', 'always', 'good', 'all', 'none', 'yes fully', 'all', 'all', 'none', 'yes', '0', '0', '0', 'ambika@gmail.com', 'computer science and engg', 'ambika', 'deshpande', '6789'),
(17, '164479160591', '1111111111', '2010', 'chinchwad pune', 'chinchwad pune', 'ab', '2014', '60', '900', 'first class', 'developer', 'wipro pune', 'rahul', 'husband', 'engineer', 'images/jpg/15212256132.jpg', 'images/jpg/15212256132.jpg', 'gate', '23', 'coep', 'national', 'coep', 'yes', 'oracle', 'yes', 'good experience', 'no', 'satisfied', 'always', 'good', 'all', 'nothing', 'yes fully', 'all', 'all', 'nothing', 'yes', '0', '0', '0', 'anagha@gmail.com', 'computer science and engg', 'anagha', 'deshpande', '313340'),
(18, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'anaghadeshpande@gmail.com', 'computer science and engg', 'anagha', 'deshpande', '0'),
(19, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'rahul@gmail.com', 'computer science and engg', 'rahul', 'deshapnde', '0'),
(20, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'studento1@gmail.com', 'computer science and engg', 'aa', 'cc', '0'),
(21, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'student01@gmail.com', 'computer science and engg', 'aa', 'cc', '0'),
(22, '164479160596', '', '2014', 'asj,gcaksudfkyuas', 'saudyfdyafsd', 'ab', '2018', '65', '1200', 'first class', 'developer', 'usgduyasgfyuga', 'bbb', 'father', 'farmer', 'images/jpg/15220951302.jpg', 'images/jpg/15220951302.jpg', 'gate', '25', 'ramdev baba', 'national', 'hhihduiwdgiw', 'yes', 'big data', 'no', '', '', 'satisfied', 'always', 'good', 'all', 'none', 'yes fully', 'all', 'all', 'none', 'yes', '0', '0', '0', 'aaabbb@gmail.com', 'computer science and engg', 'aaa', 'ccc', '111334'),
(23, '164479160598', '3333444455', '2014', 'adfyufduyw', 'asjvdagsfyuasfuy', 'ab', '2018', '65', '1000', 'first class', 'developer', 'gfdyuawduyqw', 'keahavrao', 'father', 'farmer', 'images/jpg/15220959132.jpg', 'images/jpg/15220959132.jpg', 'gate', '25', 'ramdevbaba engineering college', 'national', 'ramdevbaba engineering college', 'yes', 'big data', 'yes', 'auajudwguya', 'huigug', 'satisfied', 'always', 'good', 'all', 'none', 'yes fully', 'all', 'all', 'none', 'yes', '0', '0', '0', 'adeshpande@gmail.com', 'computer science and engg', 'aishwarya', 'deshpandee', '8926'),
(24, '1644789065', '2223334445', '2014', 'auigfuyeugfu', 'auegfyuegwf87', 'o', '2018', '65', '1000', 'first class', 'developer', 'pune890245', 'abhay', 'father', 'food inspector', 'images/jpg/15220969772.jpg', 'images/jpg/15220969772.jpg', 'gate', '25', 'rtm', 'national', 'rtm', 'yes', 'big data', 'no', '', 'cisco certification', 'satisfied', 'always', 'good', 'all', 'none', 'yes fully', 'all', 'all', 'none', 'yes', '0', '0', '0', 'anishdeshpande@gmail.com', 'computer science and engg', 'anish', 'deshpande', '45678');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_campusrecruit`
--

CREATE TABLE `tbl_campusrecruit` (
  `id` bigint(100) NOT NULL,
  `fld_companyname` varchar(255) NOT NULL DEFAULT '0',
  `fld_batcheligible` varchar(255) NOT NULL DEFAULT '0',
  `fld_bracheligible` varchar(255) NOT NULL DEFAULT '0',
  `fld_jobprofile` varchar(255) NOT NULL DEFAULT '0',
  `fld_joblocation` varchar(255) NOT NULL DEFAULT '0',
  `fld_eligibilitycriteria` varchar(255) NOT NULL DEFAULT '0',
  `fld_salary` varchar(255) NOT NULL DEFAULT '0',
  `fld_reglink` varchar(255) NOT NULL DEFAULT '0',
  `fld_skillreqd` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `fld_firstname` varchar(255) NOT NULL DEFAULT '0',
  `fld_lastname` varchar(255) NOT NULL DEFAULT '0',
  `status` bigint(100) NOT NULL DEFAULT '0',
  `action` varchar(100) NOT NULL DEFAULT '0',
  `exdate` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_campusrecruit`
--

INSERT INTO `tbl_campusrecruit` (`id`, `fld_companyname`, `fld_batcheligible`, `fld_bracheligible`, `fld_jobprofile`, `fld_joblocation`, `fld_eligibilitycriteria`, `fld_salary`, `fld_reglink`, `fld_skillreqd`, `fld_email`, `fld_firstname`, `fld_lastname`, `status`, `action`, `exdate`) VALUES
(1, 'syntel', '2018', 'cse/it', 'software developer', 'banglore', '65% aggregate', '400000', 'syntel.com', 'c,java,c++', 'student@gmail.com', 'aishwaryaa', 'deshpande', 1, '0', '0'),
(3, 'amdocs', '2017,2018', 'cse', 'java developer', 'usa', '65% aggregate', '500000', 'www.amdocs.com', 'java concepts should be cleared', 'rashmi@gmail.com', 'rahmi', 'deshkar', 1, '0', '0'),
(7, 'wipro', '2018 2017 2015', 'cse', 'android developer', 'pune', '65%aggregaate', '400000', 'wipro.com', 'advance java', 'payal@gmail.com', 'payalll', 'harsheee', 1, '0', '0'),
(8, 'infosys', '2017', 'cse', 'developer', 'hyderabad', '65% aggregate', '400000', 'infosys.com', 'c,c++,java', 'vaishnavi@gmail.com', 'vaishnaviii', 'deshpande', 0, '0', '0'),
(9, 'infosys', '2017,2018', 'cse,it', 'developer', 'hyderabad', '65% aggregate', '500000', 'infosys.com', 'c,c++,java', 'shweta@gmail.com', 'shweta', 'deshpande', 0, '0', '0'),
(10, '0', '0', '0', '0', '0', '0', '0', '0', '0', 'shambhavi@gmail.com', 'shambhavi', 'deshpande', 0, '0', '0'),
(11, '0', '0', '0', '0', '0', '0', '0', '0', '0', 'sampada@gmail.com', 'sampada', 'chande', 0, '0', '0'),
(12, 'techmahindra', '2016,2017,2018', 'cse it', 'developer', 'pune', '65%aggregate', '400000', 'techm.com', 'c,java,c++,php', 'ambikadeshpande@gmail.com', 'ambika', 'deshpande', 1, '0', '0'),
(13, 'infosys', '2018', 'cse/it', 'program analyst', 'hyderabad', '65% aggregate', '500000', 'infosys.com', 'c,java,c++', 'ambika@gmail.com', 'ambika', 'deshpande', 1, '0', '0'),
(14, 'wipro', '2018', 'cse,it', 'software developer', 'pune', '60% aggregate', '300000', 'wipro.com', 'c,java,c++', 'anagha@gmail.com', 'anagha', 'deshpande', 1, '0', '0'),
(15, '0', '0', '0', '0', '0', '0', '0', '0', '0', 'anaghadeshpande@gmail.com', 'anagha', 'deshpande', 0, '0', '0'),
(16, '0', '0', '0', '0', '0', '0', '0', '0', '0', 'rahul@gmail.com', 'rahul', 'deshapnde', 0, '0', '0'),
(17, '0', '0', '0', '0', '0', '0', '0', '0', '0', 'studento1@gmail.com', 'aa', 'cc', 0, '0', '0'),
(18, '0', '0', '0', '0', '0', '0', '0', '0', '0', 'student01@gmail.com', 'aa', 'cc', 0, '0', '0'),
(19, 'tcs', '2018 passing batch', 'cse/it', 'developer', 'pune', '65% aggregate', '500000', 'tcs.org', 'c,java,c++', 'aaabbb@gmail.com', 'aaa', 'ccc', 0, '0', '0'),
(20, 'tcs', '2018 passing', 'cse/it', 'developer', 'pune', '65% aggregate', '500000', 'tcs.org', 'c,java,c++', 'adeshpande@gmail.com', 'aishwarya', 'deshpandee', 0, '0', '0'),
(21, 'tcs', '2018 passing', 'cse/it', 'developer', 'pune', '65% aggregate throughout be', '500000', 'tcs.org', 'c,java,c++', 'anishdeshpande@gmail.com', 'anish', 'deshpande', 0, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE `tbl_company` (
  `id` bigint(100) NOT NULL,
  `fld_companyname` varchar(255) NOT NULL DEFAULT '0',
  `fld_designation` varchar(255) NOT NULL DEFAULT '0',
  `fld_location` varchar(255) NOT NULL DEFAULT '0',
  `fld_package` varchar(255) NOT NULL DEFAULT '0',
  `fld_joineddate` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `status` bigint(100) NOT NULL DEFAULT '0',
  `action` varchar(150) NOT NULL DEFAULT '0',
  `exdate` varchar(200) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`id`, `fld_companyname`, `fld_designation`, `fld_location`, `fld_package`, `fld_joineddate`, `fld_email`, `status`, `action`, `exdate`) VALUES
(1, 'syntel', 'software developer', 'banglore', '400000', '2018-03-30', 'student@gmail.com', 0, '0', '0'),
(2, 'infosys', 'tester', 'hyderabad', '600000', '2018-03-14', 'akanksha@gmail.com', 0, '0', '0'),
(7, 'amdocs', 'software developer', 'usa', '700000', '2018-02-06', 'rashmi@gmail.com', 0, '0', '0'),
(11, 'wipro', 's/w developer', 'pune', '500000', '2018-03-23', 'payal@gmail.com', 0, '0', '0'),
(13, 'infosys', 'developer', 'hyderabad', '500000', '2018-03-24', 'vaishnavi@gmail.com', 0, '0', '0'),
(14, 'infosys', 'developer', 'hyderabad', '500000', '2018-03-30', 'shweta@gmail.com', 0, '0', '0'),
(15, '0', '0', '0', '0', '0', 'shambhavi@gmail.com', 0, '0', '0'),
(16, '0', '0', '0', '0', '0', 'sampada@gmail.com', 0, '0', '0'),
(17, 'tech mahindra', 'software developer', 'pune', '500000', '2018-01-18', 'ambikadeshpande@gmail.com', 0, '0', '0'),
(18, 'infosys', 'developer', 'hyderabad', '500000', '2018-03-30', 'ambika@gmail.com', 0, '0', '0'),
(19, 'wipro', 'developer', 'pune', '500000', '2018-03-15', 'anagha@gmail.com', 0, '0', '0'),
(20, '0', '0', '0', '0', '0', 'anaghadeshpande@gmail.com', 0, '0', '0'),
(21, '0', '0', '0', '0', '0', 'rahul@gmail.com', 0, '0', '0'),
(22, '0', '0', '0', '0', '0', 'studento1@gmail.com', 0, '0', '0'),
(23, '0', '0', '0', '0', '0', 'student01@gmail.com', 0, '0', '0'),
(24, 'tcs', 'developer', 'banglore', '600000', '2018-01-04', 'aaabbb@gmail.com', 0, '0', '0'),
(25, 'tcs', 'developer', 'pune', '600000', '2018-01-18', 'adeshpande@gmail.com', 0, '0', '0'),
(26, 'tcs', 'developer', 'pune', '500000', '2018-03-30', 'anishdeshpande@gmail.com', 0, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_eventgeneration`
--

CREATE TABLE `tbl_eventgeneration` (
  `id` bigint(50) NOT NULL,
  `fld_eventtitle` varchar(255) NOT NULL DEFAULT '0',
  `fld_description` varchar(255) NOT NULL DEFAULT '0',
  `fld_date` varchar(255) NOT NULL DEFAULT '0',
  `fld_starttime` varchar(255) NOT NULL DEFAULT '0',
  `status` varchar(50) NOT NULL DEFAULT '0',
  `action` varchar(60) NOT NULL DEFAULT '0',
  `exdate` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_eventgeneration`
--

INSERT INTO `tbl_eventgeneration` (`id`, `fld_eventtitle`, `fld_description`, `fld_date`, `fld_starttime`, `status`, `action`, `exdate`) VALUES
(4, 'expert lecture', 'lecture on big data', '2018-03-31', '10:30am', '0', '0', '0'),
(5, 'euphoria 2k19', 'dances dramas', '2019-03-12', '11:00am', '0', '0', '0'),
(6, 'asdf', 'dffggggggggg', '2018-12-12', '10pm', '0', '0', '0'),
(7, 'farewll2k18', 'dgfuydgfguysdgfuy', '2018-04-07', '4pm', '0', '0', '0'),
(8, 'grand farewell2k18', 'farewelll to students of final', '2018-03-30', '5pm', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fumd`
--

CREATE TABLE `tbl_fumd` (
  `id` bigint(100) NOT NULL,
  `fld_fundamount` varchar(255) NOT NULL DEFAULT '0',
  `fld_fundtype` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `fld_firstname` varchar(255) NOT NULL DEFAULT '0',
  `fld_lastname` varchar(255) NOT NULL DEFAULT '0',
  `status` bigint(100) NOT NULL DEFAULT '0',
  `action` varchar(255) NOT NULL DEFAULT '0',
  `exdate` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_fumd`
--

INSERT INTO `tbl_fumd` (`id`, `fld_fundamount`, `fld_fundtype`, `fld_email`, `fld_firstname`, `fld_lastname`, `status`, `action`, `exdate`) VALUES
(1, '1223', 'scholarship', 'student@gmail.com', 'aishwaryaa', 'deshpande', 1, '0', '0'),
(4, '10000', 'donation', 'rashmi@gmail.com', 'rahmi', 'deahkar', 1, '0', '0'),
(8, '10000', 'donation', 'payal@gmail.com', 'payalll', 'harsheee', 1, '0', '0'),
(9, '5000', 'sponsership', 'vaishnavi@gmail.com', 'vaishnaviii', 'deshpande', 1, '0', '0'),
(10, '0', '0', 'shweta@gmail.com', 'shweta', 'deshpande', 0, '0', '0'),
(11, '0', '0', 'shambhavi@gmail.com', 'shambhavi', 'deshpande', 0, '0', '0'),
(12, '0', '0', 'sampada@gmail.com', 'sampada', 'chande', 0, '0', '0'),
(13, '6000', 'scholarship', 'ambikadeshpande@gmail.com', 'ambika', 'deshpande', 1, '0', '0'),
(14, '5000', 'scholarship', 'ambika@gmail.com', 'ambika', 'deshpande', 1, '0', '0'),
(15, '7000', 'sponsership', 'anagha@gmail.com', 'anagha', 'deshpande', 1, '0', '0'),
(16, '0', '0', 'anaghadeshpande@gmail.com', 'anagha', 'deshpande', 0, '0', '0'),
(17, '0', '0', 'rahul@gmail.com', 'rahul', 'deshapnde', 0, '0', '0'),
(18, '0', '0', 'studento1@gmail.com', 'aa', 'cc', 0, '0', '0'),
(19, '0', '0', 'student01@gmail.com', 'aa', 'cc', 0, '0', '0'),
(20, '5000', 'sponsership', 'aaabbb@gmail.com', 'aaa', 'ccc', 0, '0', '0'),
(21, '5000', 'scholarship', 'adeshpande@gmail.com', 'aishwarya', 'deshpandee', 0, '0', '0'),
(22, '5000', 'scholarship', 'anishdeshpande@gmail.com', 'anish', 'deshpande', 0, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_others`
--

CREATE TABLE `tbl_others` (
  `id` bigint(100) NOT NULL,
  `fld_uploadresume` text NOT NULL,
  `fld_facebooklink` varchar(255) NOT NULL,
  `fld_linkedinlink` varchar(255) NOT NULL,
  `fld_twitterlink` varchar(255) NOT NULL,
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `status` bigint(100) NOT NULL DEFAULT '0',
  `action` varchar(100) NOT NULL DEFAULT '0',
  `exdate` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_others`
--

INSERT INTO `tbl_others` (`id`, `fld_uploadresume`, `fld_facebooklink`, `fld_linkedinlink`, `fld_twitterlink`, `fld_email`, `status`, `action`, `exdate`) VALUES
(1, 'images/docs/default.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'student@gmail.com', 0, '0', '0'),
(3, 'images/docs/1520152164attachment.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'rashmi@gmail.com', 0, '0', '0'),
(7, 'images/docs/1520184302Cyber security.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'payal@gmail.com', 0, '0', '0'),
(9, 'images/docs/1520348266attachment.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'vaishnavi@gmail.com', 0, '0', '0'),
(10, 'images/docs/default.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'shweta@gmail.com', 0, '0', '0'),
(11, '', '', '', '', 'shambhavi@gmail.com', 0, '0', '0'),
(12, '', '', '', '', 'sampada@gmail.com', 0, '0', '0'),
(13, 'images/docs/default.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'ambikadeshpande@gmail.com', 0, '0', '0'),
(14, 'images/docs/default.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'ambika@gmail.com', 0, '0', '0'),
(15, 'images/docs/default.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'anagha@gmail.com', 0, '0', '0'),
(16, '', '', '', '', 'anaghadeshpande@gmail.com', 0, '0', '0'),
(17, '', '', '', '', 'rahul@gmail.com', 0, '0', '0'),
(18, '', '', '', '', 'studento1@gmail.com', 0, '0', '0'),
(19, '', '', '', '', 'student01@gmail.com', 0, '0', '0'),
(20, 'images/docs/default.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'aaabbb@gmail.com', 0, '0', '0'),
(21, 'images/docs/default.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'adeshpande@gmail.com', 0, '0', '0'),
(22, 'images/docs/default.docx', 'facebook.com', 'linkedin.com', 'twitter.com', 'anishdeshpande@gmail.com', 0, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pastevents`
--

CREATE TABLE `tbl_pastevents` (
  `id` bigint(100) NOT NULL,
  `fld_eventtitle` varchar(255) NOT NULL DEFAULT '0',
  `fld_description` varchar(255) NOT NULL DEFAULT '0',
  `fld_date` varchar(100) NOT NULL DEFAULT '0',
  `fld_pics` text NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT '0',
  `action` varchar(100) NOT NULL DEFAULT '0',
  `exdate` varchar(100) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pastevents`
--

INSERT INTO `tbl_pastevents` (`id`, `fld_eventtitle`, `fld_description`, `fld_date`, `fld_pics`, `status`, `action`, `exdate`) VALUES
(1, 'ganesh festival', 'ganapati poojan', '2017-09-14', 'images/jpg/1519720705logo.jpg', '0', '0', '0'),
(2, 'euphoria2k18', 'parents meet dances dramas', '2018-01-20', '', '0', '0', '0'),
(3, 'smart photography', 'photographs ', '2018-02-02', '', '0', '0', '0'),
(4, 'iot expert lecture', 'guest lecture on Big data and iot', '2018-03-8', '', '0', '0', '0'),
(5, 'sfilata', 'fashion show paper presentation', '2018-03-9', '', '0', '0', '0'),
(6, 'xxx', 'yyyzzznnnmm', '2016-11-03', '', '0', '0', '0'),
(7, 'technoextreme', 'national level technical event ', '2018-03-17', '', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staffreg`
--

CREATE TABLE `tbl_staffreg` (
  `id` bigint(20) NOT NULL,
  `fld_firstname` varchar(255) NOT NULL DEFAULT '0',
  `fld_middlename` varchar(255) NOT NULL DEFAULT '0',
  `fld_lastname` varchar(255) NOT NULL DEFAULT '0',
  `fld_contactno` varchar(20) NOT NULL DEFAULT '0',
  `fld_address` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `fld_dateofbirth` varchar(50) NOT NULL DEFAULT '0',
  `fld_gender` varchar(60) NOT NULL DEFAULT '0',
  `fld_designation` varchar(255) NOT NULL DEFAULT '0',
  `fld_password` varchar(50) NOT NULL DEFAULT '0',
  `fld_photo` text NOT NULL,
  `status` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `exdate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_staffreg`
--

INSERT INTO `tbl_staffreg` (`id`, `fld_firstname`, `fld_middlename`, `fld_lastname`, `fld_contactno`, `fld_address`, `fld_email`, `fld_dateofbirth`, `fld_gender`, `fld_designation`, `fld_password`, `fld_photo`, `status`, `action`, `exdate`) VALUES
(1, 'jitendra', 'h', 'saturwar', '8879223111', 'jdiet yavatmal 4450011', 'admin@admin.com', '1971-06-14', 'male', 'hod', 'admin123', 'images/jpg/151868813415186869822.jpg', '', '', ''),
(2, 'dinesh', 'n', 'chaudhari', '9422961063', 'jdiet yavatmal', 'dnchaudhari2007@rediffmail.com', '1975-01-01', 'male', 'professor', '1234', 'images/jpg/151868825515186869822.jpg', '', '', ''),
(3, 'sachin', 'm', 'inzalkar', '9561538975', 'jdiet yavatmal', 'sachininzalkar@gmail.com', '2018-01-18', 'male', 'assistant professor', '1234', 'images/jpg/151868836315186869822.jpg', '', '', ''),
(4, 'ahitesham', 'n', 'kazi', '9890461597', 'jdiet yavatmal', 'kazi_aihtesham@rediffmail.com', '2018-02-19', 'male', 'assistant professor', '1234', 'images/jpg/151868845615184910461518454806logo.jpg', '', '', ''),
(5, 'vivek', 'r', 'shelke', '9049093583', 'jdiet yavatmal', 'vvshelke@gmail.com', '2010-10-17', 'male', 'assistant professor', '1234', 'images/jpg/151903587215184910461518454806logo.jpg', '', '', ''),
(6, 'prasad', 'p', 'lokulwar', '7709811688', 'jdiet yavatmal', 'prasadengg16@gmail.com', '2012-11-16', 'male', 'assistant professor', '1234', 'images/jpg/151903716915186869822.jpg', '', '', ''),
(7, 'chetan', 's', 'dhamande', '9763540956', 'jdiet yavatmal', 'chetan.dhamande@gmail.com', '1972-02-15', 'male', 'assistant professor', '1234', 'images/jpg/1519313903DSCN1152.jpg', '', '', ''),
(8, 'avinash', 'p', 'jadhav', '9421786127', 'jdiet yavatmal', 'apjadhao@gmail.com', '1975-01-10', 'male', 'assistant professor', 'avinash123', 'images/jpg/1519616211logo.jpg', '', '', ''),
(9, 'staffs', 'staff', 'staffs', '1212121211', 'jdiet yavatmall4450011', 'staff@gmail.com', '1983-06-13', 'male', 'assistant professor', 'staff1234', 'images/jpg/1519617920logo.jpg', '', '', ''),
(10, 'jjjjjj', 'kkkk', 'llll', '1000000000', 'kfbfbbfbsgfbv', 'xxx@gmail.com', '2018-03-29', 'female', 'dhdhiu', '123', 'images/jpg/15201492461519616211logo.jpg', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stureg`
--
ALTER TABLE `stureg`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_campusrecruit`
--
ALTER TABLE `tbl_campusrecruit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_company`
--
ALTER TABLE `tbl_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_eventgeneration`
--
ALTER TABLE `tbl_eventgeneration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fumd`
--
ALTER TABLE `tbl_fumd`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_others`
--
ALTER TABLE `tbl_others`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pastevents`
--
ALTER TABLE `tbl_pastevents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_staffreg`
--
ALTER TABLE `tbl_staffreg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stureg`
--
ALTER TABLE `stureg`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `tbl_campusrecruit`
--
ALTER TABLE `tbl_campusrecruit`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `tbl_company`
--
ALTER TABLE `tbl_company`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `tbl_eventgeneration`
--
ALTER TABLE `tbl_eventgeneration`
  MODIFY `id` bigint(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_fumd`
--
ALTER TABLE `tbl_fumd`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tbl_others`
--
ALTER TABLE `tbl_others`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tbl_pastevents`
--
ALTER TABLE `tbl_pastevents`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_staffreg`
--
ALTER TABLE `tbl_staffreg`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
