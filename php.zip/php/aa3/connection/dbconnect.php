<?php
include "dbuserinfo.php";
 $conObj=new mysqli($serverName,$userName,$password,$databaseName);

if ($conObj->connect_error)
{
    die("Connection failed: " . $conObj->connect_error);
}    
?>