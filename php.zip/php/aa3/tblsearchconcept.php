<div class="col-md-12">
                <div class="table-responsive">
                   <table class="table table-striped" >
                       <tr>
                          
                              <th>Enrollment No</th>

                              <th>Name of Alumni</th>
                              <th>Year of Admission</th>
                              <th>Graduation Year</th>
                              <th>Percentage</th>
                              <th>Marks Obtained</th>
                              <th>Date of Birth</th>
                              <th>7th Sem Marksheet</th>
                              <th>8th Sem Marksheet</th>
                              <th>8th Sem Roll No</th>
                              <th>Branch</th>
                              <th>Verify</th>
                          
                       </tr>
                      
<?php
include "connection/dbconnect.php";
//$varEmail=$_SESSION["varSesEmail"];
$pc=mysqli_real_escape_string($conObj,trim($_REQUEST['pc']));
 $varShowQ="";

 if($pc==2014)
 {
$varShowQ="SELECT * FROM tbl_alumni WHERE fld_graduationyear=2014 AND fld_rollno<>'0'";
 }
 else if($pc==2015)
 {
$varShowQ="SELECT * FROM tbl_alumni WHERE fld_graduationyear=2015 AND fld_rollno<>'0'";
 }
 else if($pc==2016)
 {
$varShowQ="SELECT * FROM tbl_alumni WHERE fld_graduationyear=2016 AND fld_rollno<>'0'";;
 }
 else if($pc==2017)
 {
$varShowQ="SELECT * FROM tbl_alumni WHERE fld_graduationyear=2017 AND fld_rollno<>'0'";
 }
 else if($pc==2018)
 {
$varShowQ="SELECT * FROM tbl_alumni WHERE fld_graduationyear=2018 AND fld_rollno<>'0'";
 }
 else if($pc=="All")
 {
$varShowQ="SELECT * FROM tbl_alumni WHERE fld_rollno<>'0'";
 }

$res=mysqli_query($conObj,$varShowQ);

while ($data=mysqli_fetch_array($res))
{
   
$varEmail=trim($data['fld_email']);
$varShowR="SELECT * FROM stureg WHERE fld_email='$varEmail'";

$res5=mysqli_query($conObj,$varShowR);
$data5=mysqli_fetch_array($res5);

$varEmail=trim($data5['fld_email']);

    echo <<<aish

    <tr> 
    
    <td>$data[fld_enroll]</td>
    <td>$data[fld_firstname] $data[fld_lastname]</td>
    
    <td>$data[fld_yearofadmission]</td>
    <td>$data[fld_graduationyear]</td>
    <td>$data[fld_percentage]</td>
    <td>$data[fld_marksobtained]</td>
    <td>$data5[fld_dob]</td>
    <td><a href="$data[fld_seventhsem]" target="_self"><img src="$data[fld_seventhsem]" class="img img-responsive"></a></td>
    <td><a href="$data[fld_eighthsem]" target="_self"><img src="$data[fld_eighthsem]" class="img img-responsive"></a></td>
    <td>$data[fld_rollno]</td>
    <td>$data[fld_branch]</td>
    <td><a href="verification.php?QEmail=$varEmail"><button type="submit" class="btn btn-info" name="btn_verfiy">Verify</button></a>
    <br>
    <a href="alumni_personalshow.php?QEmail=$varEmail"><button type="submit" class="btn btn-info" name="btn_verfiy">Personal Details</button></a>
    <br>
    <a href="alumnishow.php?QEmail=$varEmail"><button type="submit" class="btn btn-info" name="btn_verfiy">Alumni Details</button></a>
    </td>
    
    </tr> 

aish;

}

?>
  </table>
                </div>
                </div>