<?php
if(session_id())
{
  

}
else
{
  session_start();
}
//error_reporting('all');
include "connection/dbconnect.php";
$varID=@$_SESSION["varSesEmail"];
$varTable=@$_SESSION["varSesTableName"];
$varUserType=@$_SESSION["varSesUserType"];
$varShowQ="SELECT * FROM $varTable WHERE fld_email='$varID'";
$res=mysqli_query($conObj,$varShowQ);
$data=mysqli_fetch_array($res);
?>


<html>
<head>
	<title>Search alumni</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .panel-body
{
	background-color: #f5f5f5;
	border: 2px solid white;
	
}


  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	background-color: #e65651;
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}

.table-striped
{
  border: px solid black;


}


  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div >
				<div class="col-md-10">
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
				</div>
				
			</div>
				<div class="col-md-12 menus1">
					<?php
						if($varUserType=="HOD")
						{
							include "hodnavigation.php";
						}
						else if($varUserType=="Alumni Incharge")
						{
							include "staffnavigation.php";		
						}
					
				?>
				
						
                           

						
			</div>
            
            	<div class="container">

					<div class="row">
					   <div class="col-md-4" style="height: 200px; "><br/>
					   	<div class="form-group">
									<label class="col-md-2 control-label"></label>
									<div class="col-md-10 input Group container">
										<div class="input-group">
											<span class="input-group-addon">
												<i class="glyphicon glyphicon-"></i>
											</span>
											<select name="branch" class="form-control selectpicker" placeholder="branch" class="form-control" type="text" id="idconceptCategory1">
							              <option value="All" >Please select your Branch</option>
							              <option value="computer science and engg">Computer science and Engg</option>
							              <option value="mechanical">Mechanical</option> 
							              <option value="information technology">Information Technology</option>
							              <option value="civil">civil</option> 
							              <option value="chemical">Chemical</option>
							              <option value="textile">Textile</option> 
							              <option value="electronics and telecommunication">Electronics and Telecommunication</option>
							              <option value="electrical">Electrical</option> 
							            </select>
										</div>
									</div>
								</div>
					   </div>
			   
						   <div class="col-md-4" style="height: 200px; "><br/>
						   	<form action="alumni_search.php" method="post" >
						   	<div class="form-group">
										<label class="col-md-2 control-label"></label>
										<div class="col-md-10 input Group container">
											<div class="input-group">
												<span class="input-group-addon">
													<i class="glyphicon glyphicon-search"></i>
												</span>
												<input name="search_box"  class="form-control" type="text" placeholder="Search Here "/>
												<span><button type="submit" class="btn btn-default" name="btn_sub_search">Submit</button></span>
											</div>
										</div>
									</div>
							</form>
						   </div>
			   
			   
							   <div class="col-md-4" style="height:200px;  "><br/>
							   	<div class="form-group">
					        <label class="col-md-3 control-label"></label>
					        <div class="col-md-9 selectContainer">
					          <div class="input-group"> 
					          <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
					            <select name="year" class="form-control selectpicker" class="form-control" type="text" id="idconceptCategory">
					              <option value="All" >Please select Graduation year</option>
					              <option value="2014">2014</option>
					              <option value="2015">2015</option> 
					              <option value="2016">2016</option>
					              <option value="2017">2017</option> 
					              <option value="2018">2018</option>
					            </select>
					          </div>
					        </div>
					      </div>
					      </div>

			   </div>
			</div>
		</div>
			
	


         
			<div class="row" id="ShowData">
			<?php
$con=mysqli_connect("localhost","root","","projectdb");			
if(isset($_POST["btn_sub_search"])){
extract($_POST);

$sql="select * from tbl_alumni where fld_rollno<>'0' and (fld_firstname=\"$search_box\" or fld_lastname=\"$search_box\")";

$result=@mysqli_query($con,$sql);

$nor=@mysqli_num_rows($result);

if($nor>=1){
	?>
	<center>
	<table class="table table-striped ">
	<tr>
		   <th>Enrollment No</th>

                              <th>Name of Alumni</th>
                              <th>Year of Admission</th>
                              <th>Graduation Year</th>
                              <th>Percentage</th>
                              <th>Marks Obtained</th>
                              <th>Date of Birth</th>
                              <th>7th Sem Marksheet</th>
                              <th>8th Sem Marksheet</th>
                              <th>8th Sem Roll No</th>
                              <th>Branch</th>
                              <th>Verify</th>
		
	</tr>
	<?php
while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
extract($row);
		
$sql1="select fld_dob from stureg where fld_email=\"$fld_email\"";

$result1=@mysqli_query($con,$sql1);

$nor1=@mysqli_num_rows($result1);

if($nor1>=1){
	while($row1=mysqli_fetch_array($result1,MYSQLI_ASSOC)){
		
		extract($row1);
	}
}
		?>
		<tr>
			<td><?php if(isset($fld_enroll)){echo"$fld_enroll";} ?></td>
			<td><?php if(isset($fld_firstname)){echo"$fld_firstname";} ?> <?php if(isset($fld_lastname)){echo"$fld_lastname";} ?></td>
			<td><?php if(isset($fld_yearofadmission)){echo"$fld_yearofadmission";} ?></td>
			<td><?php if(isset($fld_graduationyear)){echo"$fld_graduationyear";} ?></td>
			<td><?php if(isset($fld_percentage)){echo"$fld_percentage";} ?></td>
			<td><?php if(isset($fld_marksobtained)){echo"$fld_marksobtained";} ?></td>
			<td><?php if(isset($fld_dob)){echo"$fld_dob";} ?></td>
			<td><a href="<?php if(isset($fld_seventhsem)){echo"$fld_seventhsem";} ?>" target="_self"><img src="<?php if(isset($fld_seventhsem)){echo"$fld_seventhsem";} ?>" class="img img-responsive"></a></td>
			<td><a href="<?php if(isset($fld_eighthsem)){echo"$fld_eighthsem";} ?>" target="_self"><img src="<?php if(isset($fld_eighthsem)){echo"$fld_eighthsem";} ?>" class="img img-responsive"></a></td>
			<td><?php if(isset($fld_rollno)){echo"$fld_rollno";} ?></td>
			<td><?php if(isset($fld_branch)){echo"$fld_branch";} ?></td>
			<td>
	<a href="verification.php?QEmail=<?php if(isset($fld_email)){echo"$fld_email";} ?>"><button type="submit" class="btn btn-info" name="btn_verfiy">Verify</button></a>
    <a href="alumni_personalshow.php?QEmail=<?php if(isset($fld_email)){echo"$fld_email";} ?>"><button type="submit" class="btn btn-info" name="btn_verfiy">Personal Details</button></a>
    <a href="alumnishow.php?QEmail=<?php if(isset($fld_email)){echo"$fld_email";} ?>"><button type="submit" class="btn btn-info" name="btn_verfiy">Alumni Details</button></a>
			</td>
		</tr>
		<?php
	}
	?>
	</center>
	</table>
	<?php
	
}
}

?>
            </div>
		
			
		</div>
	
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>
<script type="text/javascript">
     $(function() 
{
  $('#idconceptCategory').change(function()
  {
            $("#ShowData").hide('slow');   

    $( "#idconceptCategory option:selected" ).each(function()
    {
      var vCategory=$(this).val();
       

          
           $.post("tblsearchconcept.php?pc="+vCategory, function(pageAllData, status)
           {
                    $("#ShowData").show('slow');
                    $("#ShowData").html(pageAllData);

             });
        
       
   });

     
});

  });
      $(function() 
{
 
 $('#idconceptCategory1').change(function()
  {
            $("#ShowData").hide('slow');   

    $( "#idconceptCategory1 option:selected" ).each(function()
    {
      var vCategory=$(this).val();
       

          
           $.post("tblsearchconcept1.php?pc="+vCategory, function(pageAllData, status)
           {
                    $("#ShowData").show('slow');
                    $("#ShowData").html(pageAllData);

             });
        
       
   });

     
});

  });
 
 


     </script>


</body>
</html>