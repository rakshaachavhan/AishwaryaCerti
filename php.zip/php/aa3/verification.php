<?php 
date_default_timezone_set("Asia/Kolkata");
$varDate=date("d/m/Y");

?>
<html>
<head>
	<title>verification form</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  <style type="text/css">

   .header
  {
    background-color: white;
  }
  
  .menus1
  {
    background-color: #e65651;
    text-align: center;
  }
  .navbar-inverse
  {
    background-color: #e65651;
    border: none;
  }

  h1
  {
    color: black;
    font-size: 18px;
    text-align: left;
    margin-left: 0px;
  }
  .img1
  {
    height: 130px;
  }

  .nav
  {
    
    font-weight: bolder;
    font-style: white;
    
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
  
  background-color: ;
  
  border: 2px solid white;
  
}
.content
{
  text-align: justify;
  padding-left: 10px;
  padding-top: 10px;
  background-color: white;
  


}
.footer
{
  text-align: center;
  background-color: #e65651;
  color: white;
  font-weight: bolder;
  padding-top: 3px;
  
  height: 30px;
  font-size: 18px;
 
}


</style>
</head>
<body>




<div class="container">
                <div class="col-md-12"><br/>
                    <div class="panel panel-body">
                    <br/>
              
            <form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">

              <h1 style="text-align: right;">Date:<span><?php echo $varDate ?></span></h1>
                   <p><h1>Dear Sir/Mam,<br/>
                    With reference to your mail I am sending this verification details please go through it.</h1></p> 

                   <br/><br/><br/><br/>
                    <fieldset>
                <legend><h1><center> Applicant Details</center></h1></legend>
              </fieldset>



              <div class="">
             <table class="table table-striped table-responsive">
                 <tr>
                      
                       <th>Name of Student</th>
                       <th>Branch</th>
                       <th>Pass out year</th>
                       <th>Enrollment No.</th>
                       <th>8th Sem Roll No</th>
                       <th>Percentage</th>
                       <th>Marks Obtained</th>
                       <th>Date of Birth</th>

                 </tr>
                 <?php
include "connection/dbconnect.php";
//$varEmail=$_SESSION["varSesEmail"];
$varEmail=$_REQUEST['QEmail'];
$varShowQ="SELECT * FROM tbl_alumni WHERE fld_email='$varEmail'";

$res=mysqli_query($conObj,$varShowQ);


$data=mysqli_fetch_array($res);   
$varEmail=$_REQUEST['QEmail'];
$varShowR="SELECT * FROM stureg WHERE fld_email='$varEmail'";

$res5=mysqli_query($conObj,$varShowR);

$data5=mysqli_fetch_array($res5);

   


    echo <<<aish

    <tr> 
    
    
    <td>$data5[fld_firstname] $data5[fld_lastname]</td>
    <td>$data5[fld_branch]</td>
    <td>$data[fld_graduationyear]</td>
    
    <td>$data[fld_enroll]</td>
    <td>$data[fld_rollno]</td>
    
    <td>$data[fld_percentage]</td>
    <td>$data[fld_marksobtained]</td>
    <td>$data5[fld_dob]</td>
    
    
    
    
    </tr> 

aish;



?>

                 
               </table>
              </div>  



             <fieldset>
                <legend><h1><center> Verifier Details</center></h1></legend>
              </fieldset>

              <div class="table-responsive">
             <table class="table table-striped" style="border: 2px solid black; text-align: center;">
                      
                      <tr ><th>Verifier Name</th>
                       <td>Prof. J. H. Saturwar</td></tr>

                        <tr><th>Designation</th>
                       <td>Head and Associate Professor</td></tr>

                       <tr><th>Contact No.</th>
                       <td>08879223111</td></tr>

                       <tr><th>Email ID</th>
                       <td>jsaturwar@gmail.com</td></tr>


                        <tr><th>sign</th>
                       <td>
                         
            


                       </td></tr>

                        <tr><th>Stamp</th>
                       <td></td></tr>



                 
               </table>
              </div> 


              <div class="form-group">
                <div class=" inputGroupContainer">
                <center><a href="alumni_search.php"><button type="button" class="btn btn-primary btn-group-lg" name="sub"><< Back</button></a> &nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-primary btn-group-lg" name="sub" onclick="window.print()">Print</button></center>
              </div>
			 
            </div>
			
















</form>
          </div>  
                  
                </div>
               </div>







<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>


</body>
</html>







