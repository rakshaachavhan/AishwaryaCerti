<html>
<head>
	<title>staff upcoming campus </title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	background-color: ;
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}


  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div >
				<div class="col-md-10">
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
				</div>-
				
			</div>
				<div class="col-md-12 menus1">
				<?php
				include "alumninavigation.php";
				?>
	            </div>

                
               <div class="row">
			<div class="col-md-12"> <br/>
	            <fieldset><legend><center>Upcoming Campus List</center></legend></fieldset>

			    <div class="table-responsive">
			       <table class="table table-striped">
			           <tr>
			           	     <th>Name of Alumni</th>
                       <th>Fund Amount</th>
                       <th>Fund Type</th>
                       
			           </tr>
                   <?php
include "connection/dbconnect.php";
//$varEmail=$_SESSION["varSesEmail"];
$varShowQ="SELECT * FROM tbl_fumd WHERE status='1'";

$res=mysqli_query($conObj,$varShowQ);

while ($data=mysqli_fetch_array($res))
{
   
$varEmail=$data['fld_email'];
$varShowR="SELECT * FROM stureg WHERE fld_email='$varEmail'";

$res5=mysqli_query($conObj,$varShowR);

$data5=mysqli_fetch_array($res5);

   


    echo <<<aish

    <tr> 
    
    
    <td>$data5[fld_firstname] $data5[fld_lastname]</td>
    
    <td>$data[fld_fundamount]</td>
    <td>$data[fld_fundtype]</td>
    
    
    
    <td><form method="post">
    <input type="hidden" name="emailhide" value="$varEmail">
    </form></td>
    
    </tr> 

aish;

}

?>   
			       </table>
			    </div>
			    </div>
            </div>
		




	    </div>
	</div>
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>


</body>
</html>