<?php
if(session_id())
{
  

}
else
{
  session_start();
}
//error_reporting('all');
include "connection/dbconnect.php";
$varID=@$_SESSION["varSesEmail"];
$varTable=@$_SESSION["varSesTableName"];
$varUserType=@$_SESSION["varSesUserType"];
$varShowQ="SELECT * FROM $varTable WHERE fld_email='$varID'";
$res=mysqli_query($conObj,$varShowQ);
$data=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Alumni Registration</title>
 <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">

  
  .header
  {
  	background-color: white;
  }
  
  .menus1 
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}
.panel-body
{
	background-color: #f5f5f5;
}
.panel-footer
{
	padding-left: 120px;
}
.panel-heading
{
	text-align: center;

}
.panel-title
{
	font-weight: bolder;
	font-size: 25px;
}
.panel
{

	margin-top: 20px;
	width: 100%;

}
.img
{
	width: 100%;
	height: 350px;
}
.collegex
{
	 background:url('../images/jpg/slide-7.jpg') no-repeat center center;
	 background-attachment: fixed;
	
}





  </style>
</head>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
										<div class="col-md-2">
											<img src="images/jpg/logo.jpg" class="img1 img-responsive">
										</div class="col-md-10">
				
										<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
		   </div>
		   <div class="col-md-12 menus1">
				<?php
				include "alumninavigation.php";
				?>
			</div>


			<div class="row">
				 
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="panel panel-body">
							
						<form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">
							<fieldset>
								<legend><center>Alumni Profile</center></legend>
							</fieldset>

				
							
							

							<div class="form-group">
								<label class="col-md-3 control-label">Enrollment No</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon"></i>
										</span>
										<input name="enrollmentno" placeholder="Enrollment No" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Fax No</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon"></i>
										</span>
										<input name="faxno" placeholder="Fax No" class="form-control" type="text">
									</div>
								</div>
							</div>

							

				      		<div class="form-group">
								<label class="col-md-3 control-label">Year of Admission</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-calender"></i>
										</span>
										<input name="YearofAdmission" placeholder="Year of Admission" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Present Address</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-home"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="Present"></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Permanent Address</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-home"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="Permanent"></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Blood Group</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="BloodGroup" placeholder="Blood Group" class="form-control" type="text">
									</div>
								</div>
							</div>


							<div class="form-group">
								<label class="col-md-3 control-label">Graduation Year</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-calender"></i>
										</span>
										<input name="GraduationYear" placeholder="Graduation Year" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Percentage</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-pencil"></i>
										</span>
										<input name="Percentage" placeholder="Percentage" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">8th Sem Roll No:</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-pencil"></i>
										</span>
										<input name="rno" placeholder="Roll No" class="form-control" type="text">
									</div>
								</div>
							</div>


							<div class="form-group">
								<label class="col-md-3 control-label">Marks Obtained</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-pencil"></i>
										</span>
										<input name="marks" placeholder="marks" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">Class of Degree</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="ClassofDegree" class="form-control selectpicker" placeholder="Class of Degree" class="form-control" type="text" >
						              <option value=" " >Please select appropriate class</option>
						              <option>Distinction</option>
						              <option>First class</option> 
						              <option>Second class</option>
						              <option>Third Class</option>  
						            </select>
						          </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">Designation</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="Designation" placeholder="Designation" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Office Address</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-home"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="officeaddress"></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Guardian Name</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-user"></i>
										</span>
										<input name="GuardianName" placeholder="Guardian Name" class="form-control" type="text">
									</div>
								</div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">Relation</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-user"></i>
										</span>
										<input name="Relation" placeholder="Relation" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Occupation</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="Occupation" placeholder="Occupation" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Seventh Sememster Marsheet</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-paperclip"></i>
										</span>
										<input type="file" name="applicantphoto" accept="image/jpg" />
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Eighth Sememster Marsheet</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-paperclip"></i>
										</span>
										<input type="file" name="applicantphoto1" accept="image/jpg" />
									</div>
								</div>
							</div>

						    <legend><center>Personal interests and other Achivements</center></legend>

						    <div class="form-group">
						        <label class="col-md-3 control-label">Have you passed any of the examinations?</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="University1" class="form-control selectpicker" placeholder="" class="form-control" type="text" >
						              <option value=" " >Please select your exam</option>
						              <option>GATE</option>
						              <option>GRE</option>
						              <option>IELTS</option>
						              <option>TOEFL</option> 
						            </select>
						          </div>
						        </div>
					        </div>

					        <div class="form-group">
								<label class="col-md-3 control-label">if yes,write your score</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="writeyourscore" placeholder="write your score" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
									<label class="col-md-3 control-label">Write name of the college where admission sought
									</label>
									<div class="col-md-9 input Group container">
										<div class="input-group">
											<span class="input-group-addon">
												<i class="glyphicon glyphicon-"></i>
											</span>
											<textarea class="form-control" rows="2" id="comment" name="clgname"></textarea>
										</div>
									</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">University</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="University" class="form-control selectpicker" placeholder="University" class="form-control" type="text" >
						              <option value=" " >Please select your university</option>
						              <option>National</option>
						              <option>Abroad</option> 
						            </select>
						          </div>
						        </div>
						    </div>

							<div class="form-group">
								<label class="col-md-3 control-label">Name of organization</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="nameoforganization" placeholder="Name of organization" class="form-control" type="text">
									</div>
								</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">Have you passed any advance course?</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="course" class="form-control selectpicker" placeholder="" class="form-control" type="text" >
						              <option value=" " >Please select one option</option>
						              <option>Yes</option>
						              <option>No</option>
						                
						            </select>
						          </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">
									Write details about course
								</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="cdetails"></textarea>
									</div>
							    </div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">Are you Employed?</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="course1" class="form-control selectpicker" placeholder="" class="form-control" type="text" >
						              <option value=" " >Please select one option</option>
						              <option>Yes</option>
						              <option>No</option>
						                
						            </select>
						          </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">Write about firm/organization
								</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="firm"></textarea>
									</div>
								</div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">
									Any other achievement
								</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="achievement"></textarea>
									</div>
								</div>
							</div>

						    <legend><center>Feed back form</center></legend>

						    <div class="form-group">
						        <label class="col-md-3 control-label"> 
						            What are your feeling about college during last four years?
						        </label>
						        <div class="col-md-9 selectContainer">
						           <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="feeling" class="form-control selectpicker" placeholder="" class="form-control" type="text" >
							              <option value=" " >Please select one option</option>
							              <option>Satisfied</option>
							              <option>Unsatisfied</option>
							              <option>Need to change</option>
							            </select>
						            </div>
						        </div>
						    </div>

						    <div class="form-group">
						        <label class="col-md-3 control-label">
						              Is your department helping you to improve your results?
						        </label>
						        <div class="col-md-9 selectContainer">
						            <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="helping" class="form-control selectpicker" placeholder="" class="form-control" type="text" >
							              <option value=" " >Please select one option</option>
							              <option>Always</option>
							              <option>Sometimes</option>
							              <option>Never</option>
							            </select>
						            </div>
						        </div>
						    </div>

						    <div class="form-group">
						        <label class="col-md-3 control-label">
						           What is the opinion of other departmental students have regarding our department?
						       </label>
						        <div class="col-md-9 selectContainer">
						            <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="opinion" class="form-control selectpicker" placeholder="" class="form-control" type="text" >
							              <option value=" " >Please select one option</option>
							              <option>Good</option>
							              <option>Not so good</option>
							              <option>Bad</option>
							            </select>
						            </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">The policies of department you like?</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="policy"></textarea>
									</div>
								</div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">The policies of department you dislike?</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="dept"></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">
											The facilities you expect from college authorities are fulfilled?
								</label>
						        <div class="col-md-9 selectContainer">
						            <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="facilities2" class="form-control selectpicker" placeholder="" class="form-control" type="text" >
							              <option value=" " >Please select one option</option>
							              <option>Yes fully</option>
							              <option>Not all</option>
							              <option>Nothing</option>
							            </select>
						            </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">The policies of college will attract students for admission?</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="p1"></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">The policies of college you like?</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="p2"></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">
								   The policies of college you dislike?
								</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="aishu"></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">
											Would you like to support your college for first/second year admissions?
								</label>
						       <div class="col-md-9 selectContainer">
							        <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="p4" class="form-control selectpicker" placeholder="" class="form-control" type="text" >
							              <option value=" " >Please select one option</option>
							              <option>Yes</option>
							              <option>No</option>
							            </select>
							        </div>
						       </div>
						    </div>

						   
							<div class="form-group">
								<div class=" inputGroupContainer">
									<center><button type="submit" class="btn btn-primary btn-group-lg" name="sub">Submit</button></center>
								</div>
							</div>

					</form>
					
				</div>
			</div>
 
			</div>


		    <div class="col-md-12 footer" >
				<p>Copyright &copy; abc. All rights are reserved</p>
			</div>

		</div>
	</div>

<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>

 <script type="text/javascript">
 
   $(document).ready(function() {
    $('#reg_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {

            GuardianName: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply Guardian Name'
                    	},
                    	regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'First Name can only consist of Alphabets'
                        }

                    }
                },
                Relation: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply Relation With the Guardian'
                    	},
                    	regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'First Name can only consist of Alphabets'
                        }

                    }
                },
                Occupation: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply Guardian Occupation'
                    	},
                    	

                    }
                },

                Designation: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply Guardian Occupation'
                    	},
                    	

                    }
                },
                
                

               enrollmentno: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply enroll or PRN'
                    	},
                    	regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'Please write valid enroll or PRN'
                        },
                        stringLength: {
                        min: 8,
                        max: 12,
                        message: 'The digit must be between %s and %s'
                    },

                    }
                },
                rno: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply ROll No'
                    	},
                    	regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'Please write valid Roll No'
                        },
                       

                    }
                },

                marks: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply ROll No'
                    	},
                    	regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'Please write valid Roll No'
                        },
                       

                    }
                },

                faxno: {
                    validators: {
                        
                    	regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'Please write valid faxno'
                        },
                        stringLength: {
                        min: 10,
                        max: 10,
                        message: 'The digit must be between %s and %s'
                    },

                    }
                },
                Present: {
                validators: {
                      stringLength: {
                        min: 10,
                        max: 200,
                        message:'Please enter at least %s characters and no more than %s'
                    },
                    notEmpty: {
                        message: 'Please supply a present address'
                    }
                    }
                 },	
                 Permanent: {
                validators: {
                      stringLength: {
                        min: 10,
                        max: 200,
                        message:'Please enter at least %s characters and no more than %s'
                    },
                    notEmpty: {
                        message: 'Please supply a permanent address'
                    }
                    }
                 },	

                 officeaddress: {
                validators: {
                      stringLength: {
                        min: 10,
                        max: 200,
                        message:'Please enter at least %s characters and no more than %s'
                    },
                    notEmpty: {
                        message: 'Please supply a office address'
                    }
                    }
                 },	

	 
             YearofAdmission: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your date of admission'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'Please write valid Year Of Admission'
                        },
            },
                 },

                 GraduationYear: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your graduation year'
                    },
                    regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'Please write valid Graduation Year'
                        },
            },
        },
       Percentage: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your Percentage'
                    }
            },
        },

        feeling: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },

        helping: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },

        opinion: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },

        policy: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },
         dept: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },

        facilities2: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },

        p1: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },

        p2: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },

        aishu: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },

        p4: {
                validators: {
                    notEmpty: {
                        message: 'Please Supply this field'
                    }
            },
        },

        ClassofDegree: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your Percentage'
                    }
            },
        },



            BloodGroup: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply Blood Group'
                    	},
                    	regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'Enter valid Blood Group'
                        }
                    	 

                    }
                },

                 applicantphoto: {
                validators: {
                    notEmpty: {
                        message: 'Please select an Applicant Photos'
                    },
                    file: {
                        extension: 'jpeg,jpg',
                        type: 'image/jpeg',
                       // maxSize: 2097152,   // 2048 * 102
                        message: 'The selected file is not valid only valid .jpeg,.jpg file'
                    }
                }
            },

             applicantphoto1: {
                validators: {
                    notEmpty: {
                        message: 'Please select an Applicant Photos'
                    },
                    file: {
                        extension: 'jpeg,jpg',
                        type: 'image/jpeg',
                       // maxSize: 2097152,   // 2048 * 102
                        message: 'The selected file is not valid only valid .jpeg,.jpg file'
                    }
                }
            },
                
            
        

          
                     
       
            
            }
        })
    
  
});



 </script>


</body>
</html>

<?php
 include "connection/dbconnect.php";
 		if (isset($_POST['sub']))
 		{
 	$varEnrollmentNo=trim($_POST['enrollmentno']);
    $varEnrollmentNo=mysqli_real_escape_string($conObj,strtolower($varEnrollmentNo));

    $varFaxNo=trim($_POST['faxno']);
    $varFaxNo=mysqli_real_escape_string($conObj,strtolower($varFaxNo));

    $varYearofAdmission=trim($_POST['YearofAdmission']);
    $varYearofAdmission=mysqli_real_escape_string($conObj,strtolower($varYearofAdmission));

    $varPresentAddress=trim($_POST['Present']);
    $varPresentAddress=mysqli_real_escape_string($conObj,strtolower($varPresentAddress));

    $varPermanentAddress=trim($_POST['Permanent']);
    $varPermanentAddress=mysqli_real_escape_string($conObj,strtolower($varPermanentAddress));

    $varBloodGroup=trim($_POST['BloodGroup']);
    $varBloodGroup=mysqli_real_escape_string($conObj,strtolower($varBloodGroup));

    $varGraduationYear=trim($_POST['GraduationYear']);
    $varGraduationYear=mysqli_real_escape_string($conObj,strtolower($varGraduationYear));

    $varPercentage=trim($_POST['Percentage']);
    $varPercentage=mysqli_real_escape_string($conObj,strtolower($varPercentage));

    $varClassOfDeg=trim($_POST['ClassofDegree']);
    $varClassOfDeg=mysqli_real_escape_string($conObj,strtolower( $varClassOfDeg));

    $varDesignation=trim($_POST['Designation']);
    $varDesignation=mysqli_real_escape_string($conObj,strtolower($varDesignation));

    $varOfficeAddress=trim($_POST['officeaddress']);
    $varOfficeAddress=mysqli_real_escape_string($conObj,strtolower($varOfficeAddress));

    $varGuardianName=trim($_POST['GuardianName']);
    $varGuardianName=mysqli_real_escape_string($conObj,strtolower($varGuardianName));

    $varRelation=trim($_POST['Relation']);
    $varRelation=mysqli_real_escape_string($conObj,strtolower($varRelation));

    $varOccupation=trim($_POST['Occupation']);
    $varOccupation=mysqli_real_escape_string($conObj,strtolower($varOccupation));

    $varfld_examinationpass=trim($_POST['University1']);
    $varfld_examinationpass=mysqli_real_escape_string($conObj,strtolower($varfld_examinationpass));

    $varfld_examscore=trim($_POST['writeyourscore']);
    $varfld_examscore=mysqli_real_escape_string($conObj,strtolower($varfld_examscore));

    $varfld_collegename=trim($_POST['clgname']);
    $varfld_collegename=mysqli_real_escape_string($conObj,strtolower($varfld_collegename));

    $varfld_university=trim($_POST['University']);
    $varfld_university=mysqli_real_escape_string($conObj,strtolower($varfld_university));

    $varfld_rollno=trim($_POST['rno']);
    $varfld_rollno=mysqli_real_escape_string($conObj,strtolower($varfld_rollno));

    $varfld_organizationname=trim($_POST['nameoforganization']);
    $varfld_organizationname=mysqli_real_escape_string($conObj,strtolower($varfld_organizationname));

    $varfld_coursedetail=trim($_POST['cdetails']);
    $varfld_coursedetail=mysqli_real_escape_string($conObj,strtolower($varfld_coursedetail));

    $varfld_course=trim($_POST['course']);
    $varfld_course=mysqli_real_escape_string($conObj,strtolower($varfld_course));

    $varfld_employed=trim($_POST['course1']);
    $varfld_employed=mysqli_real_escape_string($conObj,strtolower($varfld_employed));

    $varfld_firm=trim($_POST['firm']);
    $varfld_firm=mysqli_real_escape_string($conObj,strtolower($varfld_firm));

    $varfld_achievement=trim($_POST['achievement']);
    $varfld_achievement=mysqli_real_escape_string($conObj,strtolower($varfld_achievement));

    $varfld_feelingaboutcollege=trim($_POST['feeling']);
    $varfld_feelingaboutcollege=mysqli_real_escape_string($conObj,strtolower($varfld_feelingaboutcollege));

    $varfld_departmenthelp=trim($_POST['helping']);
    $varfld_departmenthelp=mysqli_real_escape_string($conObj,strtolower($varfld_departmenthelp));

    $varfld_opinionofstudent=trim($_POST['opinion']);
    $varfld_opinionofstudent=mysqli_real_escape_string($conObj,strtolower($varfld_opinionofstudent));

    $varfld_departmentpolicylike=trim($_POST['policy']);
    $varfld_departmentpolicylike=mysqli_real_escape_string($conObj,strtolower($varfld_departmentpolicylike));

    $varfld_departmentpolicyunlike=trim($_POST['dept']);
    $varfld_departmentpolicyunlike=mysqli_real_escape_string($conObj,strtolower($varfld_departmentpolicyunlike));

    $varfld_facilityfuillfillformdept=trim($_POST['facilities2']);
    $varfld_facilityfuillfillformdept=mysqli_real_escape_string($conObj,strtolower($varfld_facilityfuillfillformdept ));

   

    $varfld_policyattractstudent=trim($_POST['p1']);
    $varfld_policyattractstudent=mysqli_real_escape_string($conObj,strtolower($varfld_policyattractstudent));

    $varfld_marksobtained=trim($_POST['marks']);
    $varfld_marksobtained=mysqli_real_escape_string($conObj,strtolower($varfld_marksobtained));

    $varfld_collegepolicylike=trim($_POST['p2']);
    $varfld_collegepolicylike=mysqli_real_escape_string($conObj,strtolower($varfld_collegepolicylike));

	$varfld_collegepolicydislike=trim($_POST['aishu']);
	$varfld_collegepolicydislike=mysqli_real_escape_string($conObj,strtolower($varfld_collegepolicydislike));

	$varfld_supportforadmission=trim($_POST['p4']);
    $varfld_supportforadmission=mysqli_real_escape_string($conObj,strtolower($varfld_supportforadmission));

    $fname1=$_FILES['applicantphoto']['name'];
    $ftname1=$_FILES['applicantphoto']['tmp_name'];


        $allowed =  array('gif','png' ,'jpg');
        $ext = pathinfo($fname1, PATHINFO_EXTENSION);

        if(!in_array($ext,$allowed))
        {
            $path1="images/jpg/default.jpg";
        }
        else
        {
          $path1="images/jpg/".time().$fname1;
          $f=copy($ftname1, $path1);
        }

    $fname2=$_FILES['applicantphoto1']['name'];
    $ftname2=$_FILES['applicantphoto1']['tmp_name'];


        $allowed =  array('gif','png' ,'jpg');
        $ext = pathinfo($fname2, PATHINFO_EXTENSION);

        if(!in_array($ext,$allowed))
        {
            $path2="images/jpg/default.jpg";
        }
        else
        {
          $path2="images/jpg/".time().$fname2;
          $f=copy($ftname2, $path2);
        }

   
$varEmail=$_SESSION["varSesEmail"];
    
    $varUpdateQuery="UPDATE tbl_alumni SET fld_enroll='$varEnrollmentNo',fld_faxno='$varFaxNo',fld_yearofadmission='$varYearofAdmission',fld_presentaddress='$varPresentAddress',fld_permanentaddress='$varPermanentAddress',fld_bloodgroup='$varBloodGroup',fld_graduationyear='$varGraduationYear',fld_percentage='$varPercentage',fld_degreeeclass='$varClassOfDeg',fld_designation='$varDesignation',fld_officeaddress='$varOfficeAddress',fld_guardianname='$varGuardianName',fld_relation='$varRelation',fld_occupation='$varOccupation',fld_seventhsem='$path1',fld_eighthsem='$path2',fld_examinationpass='$varfld_examinationpass',fld_examscore='$varfld_examscore',fld_collegename='$varfld_collegename',fld_university='$varfld_university',fld_organizationname='$varfld_organizationname',fld_course='$varfld_course',fld_coursedetail='$varfld_coursedetail',fld_employed='$varfld_employed',fld_firm='$varfld_firm',fld_achievement='$varfld_achievement',fld_feelingaboutcollege='$varfld_feelingaboutcollege',fld_departmenthelp='$varfld_departmenthelp',fld_opinionofstudent='$varfld_opinionofstudent',fld_departmentpolicylike='$varfld_departmentpolicylike',fld_departmentpolicyunlike='$varfld_departmentpolicyunlike',fld_facilityfuillfillformdept='$varfld_facilityfuillfillformdept',fld_policyattractstudent='$varfld_policyattractstudent',fld_collegepolicylike='$varfld_collegepolicylike',fld_supportforadmission='$varfld_supportforadmission',fld_collegepolicydislike='$varfld_collegepolicydislike',fld_rollno='$varfld_rollno',fld_marksobtained='$varfld_marksobtained'WHERE fld_email='$varEmail'";

   echo $varUpdateQuery;

    if($conObj->query($varUpdateQuery) === TRUE)
        {
            echo "<script>alert('Data UPDATE...')</script>";
            echo "<script>location='alumnireg.php'</script>";
        }
        else
        {
        echo "<script>alert('Error: " . $varUpdateQuery . " - - > " . $conObj->error."')</script>";
        echo "location='alumnireg.php'";
        }


 		}

 ?>

