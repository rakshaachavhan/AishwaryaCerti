-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2018 at 03:59 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `stureg`
--

CREATE TABLE `stureg` (
  `ID` bigint(20) NOT NULL,
  `fld_firstname` varchar(255) NOT NULL DEFAULT '0',
  `fld_middlename` varchar(255) NOT NULL DEFAULT '0',
  `fld_lastname` varchar(255) NOT NULL DEFAULT '0',
  `fld_contactno` varchar(15) NOT NULL DEFAULT '0',
  `fld_address` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `fld_dob` varchar(100) NOT NULL DEFAULT '0',
  `fld_gender` varchar(20) NOT NULL DEFAULT '0',
  `fld_branch` varchar(40) NOT NULL DEFAULT '0',
  `fld_year` varchar(10) NOT NULL DEFAULT '0',
  `fld_doaddmission` varchar(20) NOT NULL DEFAULT '0',
  `fld_password` varchar(50) NOT NULL DEFAULT '0',
  `fld_image` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `action` varchar(10) NOT NULL,
  `exdate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stureg`
--

INSERT INTO `stureg` (`ID`, `fld_firstname`, `fld_middlename`, `fld_lastname`, `fld_contactno`, `fld_address`, `fld_email`, `fld_dob`, `fld_gender`, `fld_branch`, `fld_year`, `fld_doaddmission`, `fld_password`, `fld_image`, `status`, `action`, `exdate`) VALUES
(1, 'aishwarya', 'varMiddleName', 'deshpande', '5555555555', 'asdvdv mnsd vn', 'jdvgyu@gmail.com', '2018-02-07', 'female', 'mechanical', 'ii', '2018-02-21', '123', 'images/jpg/1518452665slide-4.jpg', '', '', ''),
(2, 'kalyani', 'varMiddleName', 'asiudbv', '5555555556', 'ajudcyausvdyuqwvcytdc', 'jdvgyu@gmail.com', '2018-02-14', 'female', 'computer science and engg', 'ii', '2018-02-21', '123', 'images/jpg/1518452822logo_red.jpg', '', '', ''),
(3, 'aishwarya', 'varMiddleName', 'deshpande', '8989898989', 'please enter at least 10 characters and no more than 200', 'jdvgyu@gmail.com', '2018-02-22', 'female', 'computer science and engg', 'iv', '2018-02-20', '123', 'images/jpg/1518454806logo.jpg', '', '', ''),
(5, 'aishwarya', 'keshavrao', 'deshpande', '8788269727', 'c-c chahul apartment shire-lay-out yavatmal', 'aishukd1996@gmail.com', '1996-05-25', 'female', 'computer science and engg', 'iv', '2014-07-01', 'aishukd@2596', 'images/jpg/15184910461518454806logo.jpg', '', '', ''),
(6, 'kalyani', 'virendra', 'anjankar', '8275313771', 'laxmi nagar yavatmal', 'kalyanianjankar@gmail.com', '1997-02-01', 'female', 'computer science and engg', 'iv', '2014-07-01', 'kalyani@01', 'images/jpg/1518491656DSCN1144.jpg', '', '', ''),
(7, 'nidhi', 'milind', 'joshi', '8686868686', 'bajoria nagar yavatmal', 'nidhi@gmail.com', '1996-11-22', 'female', 'computer science and engg', 'iv', '2014-07-01', 'nidhi', 'images/jpg/1518492201DSCN1145.jpg', '', '', ''),
(8, 'shrinidhi', 'umesh', 'bajpyee', '9130832599', '35 sahakar nagar yavatmal', 'bajpayeeshrinidhi35@gmail.com', '1996-12-23', 'female', 'computer science and engg', 'iv', '2014-07-01', '12345', 'images/jpg/1518527913DSCN1149.jpg', '', '', ''),
(9, 'akanksha', 'gajanan', 'karnewar', '7575757575', 'please supply a description about yourself', 'akankash@gmail.com', '1996-02-26', 'female', 'computer science and engg', 'iv', '2014-07-01', '123456', 'images/jpg/1518549392DSCN1148.jpg', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_alumni`
--

CREATE TABLE `tbl_alumni` (
  `id` bigint(20) NOT NULL,
  `fld_enroll` varchar(255) NOT NULL DEFAULT '0',
  `fld_faxno` varchar(50) NOT NULL DEFAULT '0',
  `fld_yearofadmission` varchar(60) NOT NULL DEFAULT '0',
  `fld_presentaddress` varchar(255) NOT NULL DEFAULT '0',
  `fld_permanentaddress` varchar(255) NOT NULL DEFAULT '0',
  `fld_bloodgroup` varchar(50) NOT NULL DEFAULT '0',
  `fld_graduationyear` varchar(50) NOT NULL DEFAULT '0',
  `fld_percentage` varchar(50) NOT NULL DEFAULT '0',
  `fld_degreeeclass` varchar(60) NOT NULL DEFAULT '0',
  `fld_designation` varchar(100) NOT NULL DEFAULT '0',
  `fld_officeaddress` varchar(255) NOT NULL DEFAULT '0',
  `fld_guardianname` varchar(255) NOT NULL DEFAULT '0',
  `fld_relation` varchar(255) NOT NULL DEFAULT '0',
  `fld_occupation` varchar(255) NOT NULL DEFAULT '0',
  `fld_seventhsem` text NOT NULL,
  `fld_eighthsem` text NOT NULL,
  `fld_examinationpass` varchar(50) NOT NULL DEFAULT '0',
  `fld_examscore` varchar(100) NOT NULL DEFAULT '0',
  `fld_collegename` varchar(100) NOT NULL DEFAULT '0',
  `fld_university` varchar(100) NOT NULL DEFAULT '0',
  `fld_organizationname` varchar(100) NOT NULL DEFAULT '0',
  `fld_course` varchar(100) NOT NULL DEFAULT '0',
  `fld_coursedetail` varchar(255) NOT NULL DEFAULT '0',
  `fld_employed` varchar(50) NOT NULL DEFAULT '0',
  `fld_firm` varchar(100) NOT NULL DEFAULT '0',
  `fld_achievement` varchar(150) NOT NULL DEFAULT '0',
  `fld_feelingaboutcollege` varchar(255) NOT NULL DEFAULT '0',
  `fld_departmenthelp` varchar(255) NOT NULL DEFAULT '0',
  `fld_opinionofstudent` varchar(255) NOT NULL DEFAULT '0',
  `fld_departmentpolicylike` varchar(255) NOT NULL DEFAULT '0',
  `fld_departmentpolicyunlike` varchar(255) NOT NULL DEFAULT '0',
  `fld_facilityfuillfillformdept` varchar(255) NOT NULL DEFAULT '0',
  `fld_policyattractstudent` varchar(255) NOT NULL DEFAULT '0',
  `fld_collegepolicylike` varchar(255) NOT NULL DEFAULT '0',
  `fld_collegepolicydislike` varchar(255) NOT NULL DEFAULT '0',
  `fld_supportforadmission` varchar(255) NOT NULL DEFAULT '0',
  `status` varchar(30) NOT NULL,
  `action` varchar(30) NOT NULL,
  `exdate` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staffreg`
--

CREATE TABLE `tbl_staffreg` (
  `id` bigint(20) NOT NULL,
  `fld_firstname` varchar(255) NOT NULL DEFAULT '0',
  `fld_middlename` varchar(255) NOT NULL DEFAULT '0',
  `fld_lastname` varchar(255) NOT NULL DEFAULT '0',
  `fld_contactno` varchar(20) NOT NULL DEFAULT '0',
  `fld_address` varchar(255) NOT NULL DEFAULT '0',
  `fld_email` varchar(255) NOT NULL DEFAULT '0',
  `fld_dateofbirth` varchar(50) NOT NULL DEFAULT '0',
  `fld_gender` varchar(60) NOT NULL DEFAULT '0',
  `fld_designation` varchar(255) NOT NULL DEFAULT '0',
  `fld_password` varchar(50) NOT NULL DEFAULT '0',
  `fld_photo` text NOT NULL,
  `status` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `exdate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_staffreg`
--

INSERT INTO `tbl_staffreg` (`id`, `fld_firstname`, `fld_middlename`, `fld_lastname`, `fld_contactno`, `fld_address`, `fld_email`, `fld_dateofbirth`, `fld_gender`, `fld_designation`, `fld_password`, `fld_photo`, `status`, `action`, `exdate`) VALUES
(1, 'asoicb', 'abxjj', 'deshpande', '2345678901', 'ggggggggggggggggggggggg', 'aishukd1996@gmail.com', '2018-02-23', 'female', 'ghjutreddfvg', '1234', 'images/jpg/151868813415186869822.jpg', '', '', ''),
(2, 'asoicb', 'abxjj', 'deshpande', '2345678901', 'restfugkjhkhgtrsf', 'aishukd1996@gmail.com', '2018-01-30', 'female', 'sklcklksa', '1234', 'images/jpg/151868825515186869822.jpg', '', '', ''),
(3, 'asoicb', 'abxjj', 'deshpande', '2345678901', 'gcasgyfkduaslijdhli', 'aishukd1996@gmail.com', '2018-01-18', 'female', 'awiuffguhfvh', '1234', 'images/jpg/151868836315186869822.jpg', '', '', ''),
(4, 'aishwarya', 'keshavrao', 'deshpande', '8788269727', 'shire lay out yavatmal', 'atgfy@gmail.com', '2018-02-19', 'female', 'ksdvnnndsinvio', '1234', 'images/jpg/151868845615184910461518454806logo.jpg', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stureg`
--
ALTER TABLE `stureg`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_staffreg`
--
ALTER TABLE `tbl_staffreg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stureg`
--
ALTER TABLE `stureg`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_alumni`
--
ALTER TABLE `tbl_alumni`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_staffreg`
--
ALTER TABLE `tbl_staffreg`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
