<?php
$con=mysqli_connect("localhost","root","","projectdb");	

$sql = ("SELECT * FROM tbl_eventgeneration");

$result=@mysqli_query($con,$sql);

$nor=@mysqli_num_rows($result);

if($nor>=1){
	
	while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		
		extract($row);

$event_date= new Datetime($fld_date);

$today= new Datetime();

if($event_date<$today){
	
$sql1 = ("INSERT INTO tbl_pastevents(fld_eventtitle,fld_description,fld_date) 

VALUES('$fld_eventtitle','$fld_description','$fld_date')");

if(mysqli_query($con,$sql1)){ 

$sql = ("DELETE FROM tbl_eventgeneration where id='{$id}'");

if(mysqli_query($con,$sql)){ 


}else{

die(mysqli_error($con));

}

}else{

die(mysqli_error($con));

}

}
}
	
}

?>
<html>
<head>
	<title>Event generation</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	background-color:#f5f5f5 ;
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}


  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div >
				<div class="col-md-10">
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
				</div>-
				
			</div>
				<div class="col-md-12 menus1">
				<?php
				include "hodnavigation.php";
				?>
	            </div>


	            <div class="container">
	            <div class="col-md-7">
	            <br>
	            	<table class="table table-responsive table-bordered">
	            		<tr>
	            			
	            			<th>Event Title</th>
	            			<th>Event Description</th>
	            			<th>Event Date</th>
	            			<th>Event Time</th>

	            			 
	            		</tr>

<?php
include "connection/dbconnect.php";
$varShowQ="SELECT * FROM tbl_eventgeneration";
$res=mysqli_query($conObj,$varShowQ);

while ($data=mysqli_fetch_array($res))
{
    echo <<<raj

    <tr> 
    
    <td>$data[1]</td>
    <td>$data[2]</td>
    <td>$data[3]</td>
    <td>$data[4]</td>
    
    </tr> 

raj;

}

?>


	            	</table>
	            </div>
	             	<div class="col-md-5"><br/>
	             	    <div class="panel panel-body">
							
						<form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">
							<fieldset>
								<legend><center>Event Generation</center></legend>
							</fieldset>

	             	    <div class="form-group">
							<label class="col-md-3 control-label">Event Title</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-font"></i>
									</span>
									<input name="etitle" placeholder="Event Title" class="form-control" type="text">
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label">Description</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-font"></i>
									</span>
									<input name="edescription" placeholder="Description" class="form-control" type="text">
								</div>
							</div>
						</div>


						<div class="form-group">
							<label class="col-md-3 control-label">Date</label>
							<div class="col-md-9 selectContainer">
								<div class="input-group date" id="datetimePicker">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-calendar"></i>
									</span>
									<input type="date" class="form-control" name="edate" />
								</div>
							</div>
						</div>


						<div class="form-group">
							<label class="col-md-3 control-label">Start Time</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input name="etime" placeholder="Start Time" class="form-control" type="text">
								</div>
							</div>
						</div>

						<div class="form-group">
							<div class=" inputGroupContainer">
								<center><button type="submit" class="btn btn-primary btn-group-lg" name="sub">Save</button></center>
							</div>
						</div>


						</form>
					</div>	
	             		
	             	</div>
	             </div>





	             
							



	             






















































</div>
	</div>
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
  <script src="bootstrap37/js/bootstrap-timepicker.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>
<script type="text/javascript">
	
jQuery(document).ready(function() {
             
	// Time Picker
				jQuery('.timepicker').timepicker({showMeridian: false,minuteStep: 15});
                jQuery('#timepicker').timepicker({defaultTIme: false});
                jQuery('#timepicker2').timepicker({showMeridian: false});
                jQuery('#timepicker3').timepicker({minuteStep: 15});
              });   
</script>
<script type="text/javascript">
 
   $(document).ready(function() {
    $('#reg_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {

            etitle: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply First Name'
                    	},
                    	

                    }
                },
                
                
                

               
                edescription: {
                validators: {
                      stringLength: {
                        min: 10,
                        max: 30,
                        message:'Please enter at least %s characters and no more than %s'
                    },
                    notEmpty: {
                        message: 'Please supply a description about event'
                    }
                    }
                 },	
	 
             edate: {
                validators: {
                    notEmpty: {
                        message: 'Please supply date'
                    }
            },
                 },
                 etime: {
                validators: {
                    notEmpty: {
                        message: 'Please supply Start Time'
                    }
            },
        },



            
                     
       
            
            }
        })
    
  
});



 </script>

</body>
</html>

<?php
include "connection/dbconnect.php";
 if (isset($_POST['sub']))
 {
 	$varEventTitle=trim($_POST['etitle']);
    $varEventTitle=mysqli_real_escape_string($conObj,strtolower($varEventTitle));

    $varEventDescription=trim($_POST['edescription']);
   $varEventDescription=mysqli_real_escape_string($conObj,strtolower($varEventDescription));

    $varDate=trim($_POST['edate']);
    $varDate=mysqli_real_escape_string($conObj,strtolower($varDate));

    $varStartTime=trim($_POST['etime']);
    $varStartTime=mysqli_real_escape_string($conObj,strtolower($varStartTime));

    

    $varInsertQuery= "INSERT INTO tbl_eventgeneration(fld_eventtitle,fld_date,fld_starttime,fld_description) VALUES('$varEventTitle','$varDate','$varStartTime','$varEventDescription')";
   echo $varInsertQuery;

    if($conObj->query($varInsertQuery) === TRUE)
        {
            echo "<script>alert('Data Stored...')</script>";
            echo "<script>location='hod_upcomingevents.php'</script>";
        }
        else
        {
        echo "<script>alert('Error: " . $varInsertQuery . " - - > " . $conObj->error."')</script>";
        echo "location='hod_upcomingevents.php'";
        }


 		}

?>