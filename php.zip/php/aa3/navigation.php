<nav class="navbar navbar-inverse">
					<div class="container">
						
					<button type="button" data-target="#navbar-collapse-1" data-toggle="collapse" class="navbar-toggle">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					
					<div class="collapse navbar-collapse" id="navbar-collapse-1">
						<ul class="nav navbar-nav" >
						<li>
							<a href="index.php" style="color:white;">Home</a>
						</li>
						
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:white;">
							Events<b class="caret"></b></a>
							<ul class="dropdown-menu">
							<li>
							   <a href="upcomingEvents.php">Upcoming Events</a></li>
							 <li>
							   <a href="pastEvents.php">Past Events</a></li>
							   </ul> 
						</li>
						
						<li>
							<a href="AboutUs.php" style="color:white;">About Us</a>
						</li>
						<li>
							<a href="ContactUs.php" style="color:white;">Contact Us</a>
						</li>
						</ul>

						<ul class="nav navbar-nav navbar-right">
						

						<li>
							<a href="logout.php"  style="color:white;"></a>
						</li>

						</ul>

					
					</div>
					</div>
				</nav>