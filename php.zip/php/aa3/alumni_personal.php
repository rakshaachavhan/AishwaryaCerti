<?php
if(session_id())
{
  

}
else
{
  session_start();
}
//error_reporting('all');
include "connection/dbconnect.php";
$varID=@$_SESSION["varSesEmail"];
$varTable=@$_SESSION["varSesTableName"];
$varUserType=@$_SESSION["varSesUserType"];
$varShowQ="SELECT * FROM $varTable WHERE fld_email='$varID'";
$res=mysqli_query($conObj,$varShowQ);
$data=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Registration</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  .form-group
  {
  	padding: 0px;
  	margin:0px;
  }
  
  .header
  {
  	background-color: white;
  }
  
  .menus1 
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}
.panel-body
{
	background-color: #f5f5f5;
}
.panel-footer
{
	padding-left: 120px;
}
.panel-heading
{
	text-align: center;

}
.panel-title
{
	font-weight: bolder;
	font-size: 25px;
}
.panel
{

	margin-top: 20px;
	width: 100%;

}
.img
{
	width: 100%;
	height: 350px;
}
.collegex
{
	 background:url('../images/jpg/slide-7.jpg') no-repeat center center;
	 background-attachment: fixed;
	
 }
.form-groups
{
	padding: 0px;
	margin: 0px;
}

  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
										<div class="col-md-2">
											<img src="images/jpg/logo.jpg" class="img1 img-responsive">
										</div class="col-md-10">
				
										<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
		   </div>
		   <div class="col-md-12 menus1">
				<?php
				include "alumninavigation.php";
				?>
			</div>

			<div class="row">
				 
				<div class="col-md-3"></div>
				<div class="col-md-6">
					<div class="panel panel-body">
							
						<form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">
						<fieldset>
							<legend><center>Personal Details</center></legend>
						</fieldset>

						<div class="form-group">
							<label class="col-md-3 control-label">First Name</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-user"></i>
									</span>
									<input name="firstname" placeholder="First Name" class="form-control" type="text" value="<?php echo $data['fld_firstname']; ?>">
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-md-3 control-label">Middle Name</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-user"></i>
									</span>
									<input name="midname" placeholder="Middle Name" class="form-control" type="text" value="<?php echo $data['fld_middlename']; ?>">
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label">Last Name</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-user"></i>
									</span>
									<input name="lastname" placeholder="Last Name" class="form-control" type="text" value="<?php echo $data['fld_lastname']; ?>">
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-md-3 control-label">Contact No</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-phone"></i>
									</span>
									<input name="contactno" placeholder="Contact No" class="form-control" type="text" minlength="10" maxlength="10" value="<?php echo $data['fld_contactno']; ?>">
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-md-3 control-label">Address</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-home"></i>
									</span>
									<textarea class="form-control" rows="2" id="comment" name="address" ><?php echo $data['fld_address'];?></textarea>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-md-3 control-label">E-mail ID</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-envelope"></i>
									</span>
									<input name="email" placeholder="email" class="form-control" type="text" readonly value="<?php echo $data['fld_email']; ?>">
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-md-3 control-label">Date of Birth</label>
							<div class="col-md-9 selectContainer">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-calendar"></i>
									</span>
									<input name="dob" placeholder="Date of Birth" class="form-control" type="date" value="<?php echo $data['fld_dob']; ?>">
								</div>
							</div>
						</div>






						<div class="form-group">
					        <label class="col-md-3 control-label">Gender</label>
					        <div class="col-md-9 selectContainer">
					          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
					            <select name="gender" class="form-control selectpicker" placeholder="gender" class="form-control" type="text" >
					              <option><?php echo $data['fld_gender']; ?></option>
					              <option>Female</option>
					              <option>Male</option> 
					            </select>
					          </div>
					        </div>
					      </div>


						<div class="form-group">
					        <label class="col-md-3 control-label">Branch</label>
					        <div class="col-md-9 selectContainer">
					          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-education"></i></span>
					            <select name="branch" class="form-control selectpicker" placeholder="branch" class="form-control" type="text" >
					              <option><?php echo $data['fld_branch']; ?></option>
					              <option>Computer science and Engg</option>
					              <option>Mechanical</option> 
					              <option>Information Technology</option>
					              <option>civil</option> 
					              <option>Chemical</option>
					              <option>Textile</option> 
					              <option>Electronics and Telecommunication</option>
					              <option>Electrical</option> 
					            </select>
					          </div>
					        </div>
					      </div>

						<div class="form-group">
					        <label class="col-md-3 control-label">Year</label>
					        <div class="col-md-9 selectContainer">
					          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-education"></i></span>
					            <select name="year" class="form-control selectpicker" placeholder="year" class="form-control" type="text" >
					              <option><?php echo $data['fld_year']; ?></option>
					              <option>I</option>
					              <option>II</option> 
					              <option>III</option>
					              <option>IV</option> 
					            </select>
					          </div>
					        </div>
					      </div>


                 		<div class="form-group">
							<label class="col-md-3 control-label">Date of Admission</label>
							<div class="col-md-9 selectContainer">
								<div class="input-group date" id="datetimePicker">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-calendar"></i>
									</span>
									<input type="date" class="form-control" name="doa" 
									value="<?php echo $data['fld_doaddmission']; ?>">
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label"> Change Password</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-lock"></i>
									</span>
									<input class="form-control" id="userPw" type="" placeholder="password" 
                       name="password" data-minLength="5"
                       data-error="some error"
                        value="<?php echo $data['fld_password']; ?>" required/>
		                       <span class="glyphicon form-control-feedback"></span>
		                		<span class="help-block with-errors"></span>
								</div>
							</div>
						</div>

						

						


						<div class="form-group">
							<div class=" inputGroupContainer">
								<center><button type="submit" class="btn btn-primary btn-group-lg" name="sub">Update</button></center>
							</div>
						</div>

					</form>
					
					</div>
				</div>
 
		    </div>
		
		   
		
			
			<div class="col-md-12 footer" >
				<p>Copyright &copy; abc. All rights are reserved</p>
			</div>


		</div>
	</div>

	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>
		<script type="text/javascript">
 
   $(document).ready(function() {
    $('#reg_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {

            firstname: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply First Name'
                    	},
                    	regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'First Name can only consist of Alphabets'
                        }

                    }
                },
                midname: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply First Name'
                    	},
                    	regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'First Name can only consist of Alphabets'
                        }

                    }
                },
                lastname: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply First Name'
                    	},
                    	regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'First Name can only consist of Alphabets'
                        }

                    }
                },
                
                

                contactno: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply mobile'
                    	},
                    	regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'Mobile can only consist of digits'
                        },
                        stringLength: {
                        min: 10,
                        max: 10,
                        message: 'The digit of Mobile must be between %s and %s'
                    },

                    }
                },
                address: {
                validators: {
                      stringLength: {
                        min: 10,
                        max: 200,
                        message:'Please enter at least %s characters and no more than %s'
                    },
                    notEmpty: {
                        message: 'Please supply a description about yourself'
                    }
                    }
                 },	
	 email: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your email address'
                    },
                    emailAddress: {
                        message: 'Please supply a valid email address'
                    }
                }
            },
             doa: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your date of admission'
                    }
            },
                 },
                 dob: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your date of admission'
                    }
            },
        },



            gender: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply Gender'
                    	}
                    	 

                    }
                },
                branch: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply branch'
                    	}
                    	 

                    }
                },
                year: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply year'
                    	}
                    	 

                    }
                },
                
            password: {
            validators: {
                identical: {
                    field: 'confirmPassword',
                    message: 'Confirm your password below - type same password please'
                }
            }
        },
        applicantphoto: {
                validators: {
                    notEmpty: {
                        message: 'Please select an Applicant Photos'
                    },
                    file: {
                        extension: 'jpeg,jpg',
                        type: 'image/jpeg',
                       // maxSize: 2097152,   // 2048 * 102
                        message: 'The selected file is not valid only valid .jpeg,.jpg file'
                    }
                }
            },

          
         
                     
       
            
            }
        })
    
  
});



 </script>

</body>
</html>
 

 <?php
 include "connection/dbconnect.php";
 		if (isset($_POST['sub']))
 		{
 	$varFirstName=trim($_POST['firstname']);
    $varFirstName=mysqli_real_escape_string($conObj,strtolower($varFirstName));

    $varMiddleName=trim($_POST['midname']);
    $varMiddleName=mysqli_real_escape_string($conObj,strtolower($varMiddleName));

    $varLastName=trim($_POST['lastname']);
    $varLastName=mysqli_real_escape_string($conObj,strtolower($varLastName));

    $varMobileNumber=trim($_POST['contactno']);
    $varMobileNumber=mysqli_real_escape_string($conObj,strtolower($varMobileNumber));

    $varAddress=trim($_POST['address']);
    $varAddress=mysqli_real_escape_string($conObj,strtolower($varAddress));

    $varEmail=trim($_POST['email']);
    $varEmail=mysqli_real_escape_string($conObj,strtolower($varEmail));

    $varDateOfBirth=trim($_POST['dob']);
    $varDateOfBirth=mysqli_real_escape_string($conObj,strtolower($varDateOfBirth));

    $varGender=trim($_POST['gender']);
    $varGender=mysqli_real_escape_string($conObj,strtolower($varGender));

    $varBranch=trim($_POST['branch']);
    $varBranch=mysqli_real_escape_string($conObj,strtolower($varBranch));

    $varYear=trim($_POST['year']);
    $varYear=mysqli_real_escape_string($conObj,strtolower($varYear));

    $varDateOfAdmission=trim($_POST['doa']);
    $varDateOfAdmission=mysqli_real_escape_string($conObj,strtolower($varDateOfAdmission));

    $varPassword=trim($_POST['password']);
    $varPassword=mysqli_real_escape_string($conObj,strtolower($varPassword));

    

$varUpdateQuery= "UPDATE $varTable SET fld_firstname='$varFirstName',fld_middlename='$varMiddleName',fld_lastname='$varLastName',fld_contactno='$varMobileNumber',fld_address='$varAddress',fld_dob='$varDateOfBirth',fld_gender='$varGender',fld_branch='$varBranch',fld_year='$varYear',fld_doaddmission='$varDateOfAdmission',fld_password='$varPassword' WHERE fld_email='$varEmail'";

   //echo $varUpdateQuery;

    if($conObj->query($varUpdateQuery) === TRUE)
        {
        	$varUpdateQuery1="UPDATE tbl_alumni SET fld_firstname='$varFirstName',fld_lastname='$varLastName',fld_branch='$varBranch' WHERE fld_email='$varEmail'";
        	if ($conObj->query($varUpdateQuery1) === TRUE) 
        	{
        		echo "<script>alert('Data UPDATE...')</script>";
            	echo "<script>location='alumni_personal.php'</script>";
        	}
        	else
	        {
	        echo "<script>alert('Error: " . $varUpdateQuery1 . " - - > " . $conObj->error."')</script>";
	        echo "location='alumni_personal.php'";
	        }

	        $varUpdateQuery1="UPDATE tbl_campusrecruit SET fld_firstname='$varFirstName',fld_lastname='$varLastName' WHERE fld_email='$varEmail'";
        	if ($conObj->query($varUpdateQuery1) === TRUE) 
        	{
        		echo "<script>alert('Data UPDATE...')</script>";
            	echo "<script>location='alumni_personal.php'</script>";
        	}
        	else
	        {
	        echo "<script>alert('Error: " . $varUpdateQuery1 . " - - > " . $conObj->error."')</script>";
	        echo "location='alumni_personal.php'";
	        }

	        $varUpdateQuery1="UPDATE tbl_fumd SET fld_firstname='$varFirstName',fld_lastname='$varLastName' WHERE fld_email='$varEmail'";
        	if ($conObj->query($varUpdateQuery1) === TRUE) 
        	{
        		echo "<script>alert('Data UPDATE...')</script>";
            	echo "<script>location='alumni_personal.php'</script>";
        	}
        	else
	        {
	        echo "<script>alert('Error: " . $varUpdateQuery1 . " - - > " . $conObj->error."')</script>";
	        echo "location='alumni_personal.php'";
	        }
            
        }
        else
        {
        echo "<script>alert('Error: " . $varUpdateQuery . " - - > " . $conObj->error."')</script>";
        echo "location='alumni_personal.php'";
        }




 		}

 ?>