<?php
 include "connection/dbconnect.php";
 		if (isset($_POST['sub']))
 		{
 	$varFirstName=trim($_POST['firstname']);
    $varFirstName=mysqli_real_escape_string($conObj,strtolower($varFirstName));

    $varMiddleName=trim($_POST['midname']);
    $varMiddleName=mysqli_real_escape_string($conObj,strtolower($varMiddleName));

    $varLastName=trim($_POST['lastname']);
    $varLastName=mysqli_real_escape_string($conObj,strtolower($varLastName));

    $varMobileNumber=trim($_POST['contactno']);
    $varMobileNumber=mysqli_real_escape_string($conObj,strtolower($varMobileNumber));

    $varAddress=trim($_POST['address']);
    $varAddress=mysqli_real_escape_string($conObj,strtolower($varAddress));

    $varEmail=trim($_POST['email']);
    $varEmail=mysqli_real_escape_string($conObj,strtolower($varEmail));

    $varDateOfBirth=trim($_POST['dob']);
    $varDateOfBirth=mysqli_real_escape_string($conObj,strtolower($varDateOfBirth));

    $varGender=trim($_POST['gender']);
    $varGender=mysqli_real_escape_string($conObj,strtolower($varGender));

    $varDesignation=trim($_POST['designation']);
    $varDesignation=mysqli_real_escape_string($conObj,strtolower( $varDesignation));

    $varPassword=trim($_POST['password']);
    $varPassword=mysqli_real_escape_string($conObj,strtolower($varPassword));

    $fname=$_FILES['applicantphoto']['name'];
    $ftname=$_FILES['applicantphoto']['tmp_name'];


        $allowed =  array('gif','png' ,'jpg');
        $ext = pathinfo($fname, PATHINFO_EXTENSION);

        if(!in_array($ext,$allowed))
        {
            $path="images/jpg/default.jpg";
        }
        else
        {
          $path="images/jpg/".time().$fname;
          $f=copy($ftname, $path);
        }

    $varInsertQuery= "INSERT INTO tbl_staffreg(fld_firstname,fld_middlename,fld_lastname,fld_contactno,fld_address,fld_email,fld_dateofbirth,fld_gender,fld_designation,fld_password,fld_photo ) VALUES('$varFirstName','$varMiddleName','$varLastName','$varMobileNumber','$varAddress','$varEmail','$varDateOfBirth','$varGender','$varDesignation','$varPassword','$path')";

   echo $varInsertQuery;

    if($conObj->query($varInsertQuery) === TRUE)
        {
            echo "<script>alert('Data Stored...')</script>";
            echo "<script>location='staffreg.php'</script>";
        }
        else
        {
        echo "<script>alert('Error: " . $varInsertQuery . " - - > " . $conObj->error."')</script>";
        echo "location='staffreg.php'";
        }


 		}

 ?>