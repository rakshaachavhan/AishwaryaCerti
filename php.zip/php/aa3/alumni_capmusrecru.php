<?php
if(session_id())
{
  

}
else
{
  session_start();
}
//error_reporting('all');
include "connection/dbconnect.php";
$varID=@$_SESSION["varSesEmail"];
$varTable=@$_SESSION["varSesTableName"];
$varUserType=@$_SESSION["varSesUserType"];
$varShowQ="SELECT * FROM $varTable WHERE fld_email='$varID'";
$res=mysqli_query($conObj,$varShowQ);
$data=mysqli_fetch_array($res);
?>
<html>
<head>
	<title>campus recru</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
  .panel-body
{
	background-color: #f5f5f5;
	border: 2px solid white;
	
}

 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	background-color: ;
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}


  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div >
				<div class="col-md-10">
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
				</div>-
				
			</div>
				<div class="col-md-12 menus1">
				<?php
				include "alumninavigation.php";
				?>
	            </div>


	            <div class="container">
	            <div class="col-md-2"></div>
	             	<div class="col-md-8"><br/>
	             	    <div class="panel panel-body">
							
						<form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">
							<fieldset>
								<legend><center>About Campus Recruitment</center></legend>
							</fieldset>

	             	    <div class="form-group">
							<label class="col-md-3 control-label">Company Name</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input name="cname" placeholder="" class="form-control" type="text">
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label">Batches Eligible</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<textarea class="form-control" rows="2" id="comment" name="batches"></textarea>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label">Branches Eligible</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<textarea class="form-control" rows="2" id="comment" name="branches"></textarea>
								</div>
							</div>
						</div>
						
						<div class="form-group">
							<label class="col-md-3 control-label">Job Profile</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input name="jobprofile" placeholder="" class="form-control" type="text" >
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label">Job Location</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input name="joblocation" placeholder="" class="form-control" type="text" >
								</div>
							</div>
						</div>


						<div class="form-group">
							<label class="col-md-3 control-label">Eligibility Criteria</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<textarea class="form-control" rows="2" id="comment" name="criteria"></textarea>
								</div>
							</div>
						</div>


						<div class="form-group">
							<label class="col-md-3 control-label">Salary Package</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input name="salary" placeholder="" class="form-control" type="text">
								</div>
							</div>
						</div>


						<div class="form-group">
							<label class="col-md-3 control-label">Registration Link</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input name="reglink" placeholder="" class="form-control" type="text">
								</div>
							</div>
						</div>


						<div class="form-group">
							<label class="col-md-3 control-label">Skills Required</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<textarea class="form-control" rows="2" id="comment" name="skill"></textarea>
								</div>
							</div>
						</div>

                     <div class="row">
                          <div class="col-md-2"></div>
                          <div class="col-md-8">
						 <div class="form-group">
							<div class=" inputGroupContainer">
								<center>
								<button type="submit" class="btn btn-primary btn-group-lg" name="sub">Send to Admin</button>
								</center>
							</div>
						</div>
						</div>
						<div class="col-md-2"></div>

					</div>

						

						</form>
					</div>
				</div>
				<div class="col-md-2"></div>
			</div>

</div>
	</div>
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>
 <script type="text/javascript">
 
   $(document).ready(function() {
    $('#reg_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {

            cname: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply Company Name'
                    	},
                    	regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'Enter valid company name'
                        }

                    }
                },
                midname: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply First Name'
                    	},
                    	regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'First Name can only consist of Alphabets'
                        }

                    }
                },
                lastname: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply First Name'
                    	},
                    	regexp: {
                        regexp: /^[a-zA-Z]+$/,
                        message: 'First Name can only consist of Alphabets'
                        }

                    }
                },
                
                salary: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply mobile'
                    	},
                    	regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'Salary can only consist of digits'
                        },
                        
                    }
                },

                skill: {
                validators: {
                      
                    notEmpty: {
                        message: 'Please supply a description about yourself'
                    }
                    }
                 },

	 reglink: {
                validators: {
                    notEmpty: {
                        message: 'Please supply link'
                    },
                    
                }
            },

            criteria: {
                validators: {
                    notEmpty: {
                        message: 'Please supply criteria'
                    }
            },
                 },

        joblocation: {
              validators: {
                   notEmpty: {
                        message: 'Please supply job location'
                    }
            },
        },



            jobprofile: {
                    validators: {
                        notEmpty: {
                        message: 'Please Enter Job Profile'
                    	}
                    	 

                    }
                },

                branches: {
                    validators: {
                        notEmpty: {
                        message: 'Please enter eligible branches'
                    	}
                    	 

                    }
                },

                batches: {
                    validators: {
                        notEmpty: {
                        message: 'Please Enter Eligible Batches'
                    	}
                    	 

                    }
                },
                
            
        

          
         
                     
       
            
            }
        })
    
  
});



 </script>



</body>
</html>

<?php
 include "connection/dbconnect.php";
 		if (isset($_POST['sub']))
 		{
 	$varComapnyName=trim($_POST['cname']);
    $varComapnyName=mysqli_real_escape_string($conObj,strtolower($varComapnyName));

    $varBatchesEligible=trim($_POST['batches']);
    $varBatchesEligible=mysqli_real_escape_string($conObj,strtolower($varBatchesEligible));

    $varBranchesEligible=trim($_POST['branches']);
    $varBranchesEligible=mysqli_real_escape_string($conObj,strtolower($varBranchesEligible));

    $varJobProfile=trim($_POST['jobprofile']);
    $varJobProfile=mysqli_real_escape_string($conObj,strtolower($varJobProfile));

    $varJobLocation=trim($_POST['joblocation']);
    $varJobLocation=mysqli_real_escape_string($conObj,strtolower($varJobLocation));

    $varEligibilityCriteria=trim($_POST['criteria']);
    $varEligibilityCriteria=mysqli_real_escape_string($conObj,strtolower($varEligibilityCriteria));

    $varSalary=trim($_POST['salary']);
    $varSalary=mysqli_real_escape_string($conObj,strtolower($varSalary));

    $varRegLink=trim($_POST['reglink']);
    $varRegLink=mysqli_real_escape_string($conObj,strtolower($varRegLink));

    $varSkillRequired=trim($_POST['skill']);
    $varSkillRequired=mysqli_real_escape_string($conObj,strtolower($varSkillRequired));

    

    
    $varEmail=$_SESSION["varSesEmail"];
    
    



    $varUpdateQuery="UPDATE tbl_campusrecruit SET fld_companyname='$varComapnyName',fld_batcheligible='$varBatchesEligible',fld_bracheligible='$varBranchesEligible',fld_jobprofile ='$varJobProfile',fld_joblocation='$varJobLocation',fld_eligibilitycriteria='$varEligibilityCriteria',fld_salary='$varSalary',fld_reglink='$varRegLink',fld_skillreqd='$varSkillRequired',status='0'WHERE fld_email='$varEmail'";

   echo $varUpdateQuery;

    if($conObj->query($varUpdateQuery) === TRUE)
        {
            echo "<script>alert('Sent To Admin...')</script>";
            echo "<script>location='alumni_capmusrecru.php'</script>";
        }
        else
        {
        echo "<script>alert('Error: " . $varUpdateQuery . " - - > " . $conObj->error."')</script>";
        echo "location='alumni_capmusrecru.php'";
        }


 		}

 ?>

