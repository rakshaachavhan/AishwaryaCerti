<?php
if(session_id())
{
  

}
else
{
  session_start();
}
//error_reporting('all');
include "connection/dbconnect.php";
$varID=@$_SESSION["varSesEmail"];
$varTable=@$_SESSION["varSesTableName"];
$varUserType=@$_SESSION["varSesUserType"];
$varShowQ="SELECT * FROM $varTable WHERE fld_email='$varID'";
$res=mysqli_query($conObj,$varShowQ);
$data=mysqli_fetch_array($res);
?>
<html>
<head>
	<title>Resume alumni</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .panel-body
{
	background-color: #f5f5f5;
	border: 2px solid white;
	
}


  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	background-color: ;
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}


  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div >
				<div class="col-md-10">
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
				</div>-
				
			</div>
				<div class="col-md-12 menus1">
				<?php
				include "alumninavigation.php";
				?>
	          </div>


	          <div class="container">
	             	<div class="col-md-12">
	             	    <div class="panel panel-body">
							
						<form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">
							<fieldset>
								<legend><center>Resume</center></legend>
							</fieldset></br>

							<div class="form-group">
							<label class="col-md-5 control-label">Upload resume</label>
							<div class="col-md-7 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-paperclip"></i>
									</span>
									<input type="file" name="resume" accept="image/docs" />
								</div>
							</div>
						</div>
						<br/>


						<fieldset>
								<legend><center>Other Links</center></legend>
							</fieldset>
							<div class="form-group">
							<label class="col-md-5 control-label">Facebook Profile Link</label>
							<div class="col-md-7 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input type="text" name="facebook" accept="image/jpg" />
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-5 control-label">LinkedIn Profile Link</label>
							<div class="col-md-7 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input type="text" name="linkedin" accept="image/jpg" />
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-5 control-label">Twitter Profile Link</label>
							<div class="col-md-7 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input type="text" name="twitter" accept="image/docs" />
								</div>
							</div>
						</div>

						<div class="form-group">
							<div class=" inputGroupContainer">
								<center><button type="submit" class="btn btn-primary btn-group-lg" name="sub">Submit</button></center>
							</div>
						</div>

							

						</form>
					</div>
				</div>
			</div>			







               







































</div>
	</div>
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>
 <script type="text/javascript">
 
   $(document).ready(function() {
    $('#reg_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {

            

               facebook: {
                validators: {
                    notEmpty: {
                        message: 'Please supply Facebook Profile Link'
                    },
                    
                }
            },

            twitter: {
                validators: {
                    notEmpty: {
                        message: 'Please supply twitter Profile Link'
                    },
                    
                }
            },

            linkedin: {
                validators: {
                    notEmpty: {
                        message: 'Please supply linkedIn Profile Link'
                    },
                    
                }
            },
                
            
        applicantphoto: {
                validators: {
                    notEmpty: {
                        message: 'Please select your resume'
                    },
                    file: {
                        extension: 'doc,docx,pdf',
                        
                       // maxSize: 2097152,   // 2048 * 102
                        message: 'The selected file is not valid only valid .doc,.docx,.pdf file'
                    }
                }
            },

          
         
                     
       
            
            }
        })
    
  
});



 </script>



</body>
</html>
<?php
 include "connection/dbconnect.php";
 		if (isset($_POST['sub']))
 		{
 	$varFacebook=trim($_POST['facebook']);
    $varFacebook=mysqli_real_escape_string($conObj,strtolower($varFacebook));

    $varTwitter=trim($_POST['twitter']);
    $varTwitter=mysqli_real_escape_string($conObj,strtolower($varTwitter));

    $varLinkedIn=trim($_POST['linkedin']);
    $varLinkedIn=mysqli_real_escape_string($conObj,strtolower($varLinkedIn));

     $fname=$_FILES['resume']['name'];
    $ftname=$_FILES['resume']['tmp_name'];


        $allowed =  array('docx','pdf');
        $ext = pathinfo($fname, PATHINFO_EXTENSION);

        if(!in_array($ext,$allowed))
        {
            $path="images/docs/default.docx";
        }
        else
        {
          $path="images/docs/".time().$fname;
          $f=copy($ftname, $path);
        }

    

    
    $varEmail=$_SESSION["varSesEmail"];
    
    $varUpdateQuery="UPDATE tbl_others SET fld_uploadresume='$path',fld_facebooklink='$varFacebook',fld_linkedinlink='$varLinkedIn',fld_twitterlink='$varTwitter'WHERE fld_email='$varEmail'";

   echo $varUpdateQuery;

    if($conObj->query($varUpdateQuery) === TRUE)
        {
            echo "<script>alert('Updated')</script>";
            echo "<script>location='alumni_others.php'</script>";
        }
        else
        {
        echo "<script>alert('Error: " . $varUpdateQuery . " - - > " . $conObj->error."')</script>";
        echo "location='alumni_others.php'";
        }


 		}

 ?>
