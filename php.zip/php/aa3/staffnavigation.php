<nav class="navbar navbar-inverse">
					<div class="container">
						
					<button type="button" data-target="#navbar-collapse-1" data-toggle="collapse" class="navbar-toggle">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					
					<div class="collapse navbar-collapse" id="navbar-collapse-1">
						<ul class="nav navbar-nav" >
						<li>
							<a href="staff_edit.php" style="color:white;">Profile</a>
						</li>
						<li>
							<a href="staff_PastEvent.php"  style="color:white;">
							Events</a>
							
						</li>
						
						<li>
							<a href="staff_Campus.php" style="color:white;">Campus</a>
						</li>
						<li>
							<a href="alumni_search.php" style="color:white;">Alumni</a>
						</li>
						
						</ul>

						<ul class="nav navbar-nav navbar-right">
						<li>
							<a href="logout.php"  style="color:white;">LogOut</a>
						</li>
						</ul>

					</div>
					</div>
				</nav>