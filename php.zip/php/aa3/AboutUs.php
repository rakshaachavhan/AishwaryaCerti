<html>
<head>
	<title>About Us</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1 
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}
.panel-body
{
	background-color: #f5f5f5;
}
.panel-footer
{
	padding-left: 120px;
}
.panel-heading
{
	text-align: center;

}
.panel-title
{
	font-weight: bolder;
	font-size: 25px;
}
.panel
{

	margin-top: 10px;
	width: 100%;

}
.img
{
	width: 100%;
	height: 520px;
}
#about
{
	text-align: justify;
}



  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div class="col-md-10">
				
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
		   </div>
		   <div class="col-md-12 menus1">
				<?php
					include "navigation.php";
					?>
			</div>
			<div class="row">
			<div class="col-md-7">
				<img src="images/jpg/slide-7.jpg" class="img img-responsive">
		    </div>
		    <div class="col-md-5">
		    	<div class="panel panel-body">
		    		<h2>About Us</h2>
		    		<p id="about">The internet has indeed become a major breakthrough in our world today. If you desire the growth, success, and want a large participation in anything then you need to ensure it is on the internet. Any organization that deals on large amount of data of necessity requires an online application to manage it effectively. This system can be used as an application for the Alumni Information Database to manage the college information and student’sinformation. The system is an online application that can be accessed throughout the organization with proper login provided, which will give better service to the users.As the modern organizations are automated and computers are working as per the instructions, it becomes essential forthe coordination of human beings, commodity and computers in a modern organization. Colleges need to maintain the information very accurately and up to date. This information helps the students to search the products very efficiently.Many big cities where life is busy needs many kind of transactions are taking place within few minutes of time. So, this online information helps one to complete this task within the time. A student can search the information through internet by viewing the details.</p>
		    	</div>
		    </div>
		    </div>

		
			
			<div class="col-md-12 footer" >
				<p>Copyright &copy; abc. All rights are reserved</p>
			</div>
		</div>
	</div>
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>
 <script type="text/javascript">
</body>
</html>