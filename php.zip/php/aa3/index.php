<?php
if(session_id())
{
  

}
else
{
  session_start();
}

      if(!(isset($_SESSION['varSesLogin'])))
      {
  
         
?>
<html>
<head>
	<title>Login Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1 
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}
.panel-body
{
	background-color: #f5f5f5;
}
.panel-footer
{
	padding-left: 120px;
}
.panel-heading
{
	text-align: center;

}
.panel-title
{
	font-weight: bolder;
	font-size: 25px;
}
.panel
{

	margin-top: 20px;
	width: 100%;

}
.img
{
	width: 100%;
	height: 400px;
}
.marquee
{
	background-color:  #e65651;
	background-color: #e65651;
	
	border: 2px solid white;
	height: 350px;
}



  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div >
				<div class="col-md-10">
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
				</div>
		   </div>
		   <div class="col-md-12 menus1">
				<?php
					include "navigation.php";
					?>
					</div>
					<div>
				<!-- Start WOWSlider.com BODY section -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="data1/images/jawaharlaldardainstituteofengineeringandtechnologyjdietyavatmal.jpg" alt="slider jquery" title id="wows1_0"/></li>
		<li><img src="data1/images/slide4.jpg" alt="slide-4" title id="wows1_1"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="jawaharlal-darda-institute-of-engineering-and-technology-jdiet-yavatmal"><span><img src="data1/tooltips/jawaharlaldardainstituteofengineeringandtechnologyjdietyavatmal.jpg" alt="jawaharlal-darda-institute-of-engineering-and-technology-jdiet-yavatmal"/>1</span></a>
		<a href="#" title="slide-4"><span><img src="data1/tooltips/slide4.jpg" alt="slide-4"/>2</span></a>
	</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">jquery carousel</a> by WOWSlider.com v8.8</div>
<div class="ws_shadow"></div>
</div>	
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
<!-- End WOWSlider.com BODY section -->
			</div>
		
			
			
			<div class="col-md-4 panel-body marquee">
				
					<marquee direction="up" onmouseover="this.stop()" onmouseout="this.start()"  behavior="alternate" style="height: 350px;">

						<ul class="events nav">
							<?php
include "connection/dbconnect.php";
$varShowQ="SELECT * FROM tbl_eventgeneration";
$res=mysqli_query($conObj,$varShowQ);

while ($data=mysqli_fetch_array($res))
{
    echo <<<aish

    
    <li>$data[1]</li>
    
    

aish;

}

?>
						</ul>
					</marquee>
				
			</div>
			<div class="col-md-1"></div>
		    <div class="col-md-6">
		    	
				
					<form role="form" id="login" method="post">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h3 class="panel-title">LogIn</h3>
							</div>
							<div class="panel-body">
								<div class="row">
									
									<div class="form-group">
								        <label class="col-md-3 control-label">Login As</label>
								        <div class="col-md-9 selectContainer">
								          <div class="input-group"> <span class="input-group-addon"> </span>
								            <select name="loginas" class="form-control selectpicker" placeholder="gender" class="form-control" type="text" >
								              <option value=" " >Select User</option>
								              <option>Alumni Incharge</option>
								              <option>Student</option> 
								              <option>HOD</option> 
								            </select>
								          </div>
								        </div>
								      </div>

										<div class="form-group">
											<label class="col-md-3 control-label">Username</label>
											<div class="col-md-9 ">
												<div class="input-group">
													<span class="input-group-addon">	</span>
														<input name="username" class="form-control" type="text">
												
												</div>
											</div>
										</div>
										<br><br>
										<div class="form-group">
											<label class="col-md-3 control-label">Password</label>
											<div class="col-md-9 inputGroupContainer">
												<div class="input-group">
													<span class="input-group-addon"></span>
														<input name="password" class="form-control" type="Password">
													
												</div>
											</div>
										</div>
										<br><br>
										<div class="form-group blocked-form">
											<div class=" inputGroupContainer">
												<center><button type="submit" name="btnlogin" id="btnlogin" class="btn btn-info btn-group-lg">LogIn</button></center>
											</div>
										</div>
									
								</div>
							</div>
							<div class="panel-footer">
								<center>
								<a href="forgotpassword.php" class="btn btn-info btn-group-lg" >Forgot Password</a>
								<a href="register.php" class="btn btn-info btn-group-lg" >Register</a>
								</center>							
							</div>
						</div>
					</form>
				
			
		    </div>

		    <div class="col-md-1"></div>

		    

		
			
			<div class="col-md-12 footer" >
				<p>Copyright &copy; abc. All rights are reserved</p>
			</div>
		</div>
	</div>
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>
		<script type="text/javascript">
 
   $(document).ready(function() {
    $('#login').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {

	username: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your email address'
                    },
                    emailAddress: {
                        message: 'Please supply a valid email address'
                    }
                }
            },
             loginas: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply user type'
                    	}
                    	 

                    }
                },
         
           Password: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply correct Password'
                    	}
                    	 

                    }
                },
            }
        })
    
  
});



 </script>
</body>
</html>
 <?php
  error_reporting('all');
  include 'connection/dbconnect.php';
 if (isset($_POST['btnlogin']))
 {
      $varUserName=mysqli_real_escape_string($conObj,trim($_POST['username']));
      $varPassword=mysqli_real_escape_string($conObj,trim($_POST['password']));

      $varUserType=mysqli_real_escape_string($conObj,trim($_POST['loginas']));

      if($varUserType=="Alumni Incharge" OR $varUserType=="HOD")
      {
      	$varTable="tbl_staffreg";
      }
      else if($varUserType=="Student")
      {
 		$varTable="stureg";     	
      }

      $varCheckLogin="SELECT * FROM $varTable WHERE fld_email='$varUserName' AND fld_password='$varPassword'";
 
$varResult=mysqli_query($conObj,$varCheckLogin);

if(mysqli_num_rows($varResult)==1)
{
      session_start();
      $arrData=mysqli_fetch_array($varResult);
      $_SESSION["varSesLogin"]="LoginSuccess";
      $_SESSION["varSesEmail"]=$arrData['fld_email'];
       $_SESSION["varSesUserType"]=$varUserType;
      
      if($varUserType=="Alumni Incharge" OR $varUserType=="HOD")
      {
      	 $_SESSION["varSesTableName"]="tbl_staffreg";
      	echo "<script>location='staff_editxx.php'</script>";
      }
      else if($varUserType=="Student")
      {
      	$_SESSION["varSesTableName"]="stureg";
 		echo "<script>location='alumni_edit.php'</script>";     	
      }

      
 
}
else
{
        echo "<script>alert('login fail')</script>";
        echo "<script>location='index.php'</script>";

}

  }




}
else
{

      echo "<script>location='oldindex.php'</script>";

}
 ?>
