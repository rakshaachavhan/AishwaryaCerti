<html>
<head>
	<title>Past Event</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	background-color:#f5f5f5 ;
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}


  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div >
				<div class="col-md-10">
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
				</div>-
				
			</div>
				<div class="col-md-12 menus1">
				<?php
				include "hodnavigation.php";
				?>
	            </div>


	             <div class="container">
	             	<div class="col-md-12"><br/>
	             	    <div class="panel panel-body">
							
						<form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">
							<fieldset>
								<legend><center> Previous Event</center></legend>
							</fieldset>


							<div class="form-group">
							<label class="col-md-3 control-label">Event Title</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-"></i>
									</span>
									<input name="ename" placeholder="Past Events" class="form-control" type="text">
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label">Description</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-pencil"></i>
									</span>
									<textarea class="form-control" rows="2" id="comment" name="description"></textarea>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label class="col-md-3 control-label">Date</label>
							<div class="col-md-9 selectContainer">
								<div class="input-group date" id="datetimePicker">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-calendar"></i>
									</span>
									<input type="date" class="form-control" name="edate" />
								</div>
							</div>
						</div>
						

                            <div class="form-group">
							<label class="col-md-3 control-label">Add Event's Pics</label>
							<div class="col-md-9 input Group container">
								<div class="input-group">
									<span class="input-group-addon">
										<i class="glyphicon glyphicon-paperclip"></i>
									</span>
									<input type="file" name="ephoto" accept="image/jpg" multiple />
								</div>
							</div>
						</div>





						<div class="form-group">
							<div class=" inputGroupContainer">
								<center><button type="submit" class="btn btn-primary btn-group-lg" name="sub">Save</button></center>
							</div>
						</div>


						</form>
					</div>	
	             		
	             	</div>
	             </div>








	           




	             
							



	             






















































</div>
	</div>
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>


</body>
</html>



<?php
include "connection/dbconnect.php";
 if (isset($_POST['sub']))
 {
 	$varEventTitle=trim($_POST['ename']);
    $varEventTitle=mysqli_real_escape_string($conObj,strtolower($varEventTitle));

    $varDate=trim($_POST['edate']);
    $varDate=mysqli_real_escape_string($conObj,strtolower($varDate));

    $varDescription=trim($_POST['description']);
    $varDescription=mysqli_real_escape_string($conObj,strtolower($varDescription));

    $fname=$_FILES['ephoto']['name'];
    $ftname=$_FILES['ephoto']['tmp_name'];


        $allowed =  array('gif','png' ,'jpg');
        $ext = pathinfo($fname, PATHINFO_EXTENSION);

        if(!in_array($ext,$allowed))
        {
            $path="images/jpg/default.jpg";
        }
        else
        {
          $path="images/jpg/".time().$fname;
          $f=copy($ftname, $path);
        }

    

    $varInsertQuery= "INSERT INTO tbl_pastevents(fld_eventtitle,fld_description,fld_date,fld_pics ) VALUES('$varEventTitle','$varDescription','$varDate','$path')";
   //echo $varInsertQuery;

    if($conObj->query($varInsertQuery) === TRUE)
        {
            echo "<script>alert('Data Stored...')</script>";
            echo "<script>location='hod_pastevents.php'</script>";
        }
        else
        {
        echo "<script>alert('Error: " . $varInsertQuery . " - - > " . $conObj->error."')</script>";
        echo "location='hod_pastevents.php'";
        }


 		}

?>