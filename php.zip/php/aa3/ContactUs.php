<html>
<head>
	<title>Contact Us</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1 
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}
.panel-body
{
	background-color: #f5f5f5;

}

.panel-heading
{
	text-align: left;

}

.panel
{

	margin-top: 10px;
	width: 100%;
	background-color: #f5f5f5;

}
.img
{
	width: 100%;
	height: 350px;
}



  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div class="col-md-10">
				
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
		   </div>
		   <div class="col-md-12 menus1">
				<?php
					include "navigation.php";
					?>
			</div>
			<div class="row">
				<div class="col-md-7">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7479.402337753276!2d78.08703065887244!3d20.395207470584005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd3e60bf463c293%3A0x6a8e897278236160!2sJawaharlal+Darda+Institute+Of+Engineering+And+Technology!5e0!3m2!1sen!2sin!4v1517937083728" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				</div>
				<div class="col-md-5">
					<div class="panel panel-heading">
						<h3>Contact Us</h3>
					</div>
					<div class="panel-body">
						Akanksha G. Karnewar<br>
						akankshakarnewar97@gmail.com<br>
						+91 7776948293
					</div>
					<div class="panel-body">
						Aishwarya K. Deshpande<br>
						aishukd1996@gmail.com<br>
						+91 8788269727
					</div>
					<div class="panel-body">
						Aayush Pisalkar<br>
						aayush.pialkar@gmail.com<br>
						+91 8087608000
					</div>
				</div>
			</div>

			<div class="col-md-12 footer" >
				<p>Copyright &copy; abc. All rights are reserved</p>
			</div>
		</div>
	</div>
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>
 <script type="text/javascript">

</body>
</html>