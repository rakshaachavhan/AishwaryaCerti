<?php
if(session_id())
{
  

}
else
{
  session_start();
}
//error_reporting('all');
include "connection/dbconnect.php";
$varID=@$_SESSION["varSesEmail"];
$varTable=@$_SESSION["varSesTableName"];
$varUserType=@$_SESSION["varSesUserType"];
$varShowQ="SELECT * FROM $varTable WHERE fld_email='$varID'";
$res=mysqli_query($conObj,$varShowQ);
$data=mysqli_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Alumni Registration</title>
 <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">

  
  .header
  {
  	background-color: white;
  }
  
  .menus1 
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}
.panel-body
{
	background-color: #f5f5f5;
}
.panel-footer
{
	padding-left: 120px;
}
.panel-heading
{
	text-align: center;

}
.panel-title
{
	font-weight: bolder;
	font-size: 25px;
}
.panel
{

	margin-top: 20px;
	width: 100%;

}
.img
{
	width: 100%;
	height: 350px;
}
.collegex
{
	 background:url('../images/jpg/slide-7.jpg') no-repeat center center;
	 background-attachment: fixed;
	
}





  </style>
</head>
</head>
<body>
	<div class="container">
		<div class="row">
			
		   


			<div class="row">
				 
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="panel panel-body">
							
						<form class="form-horizontal" id="reg_form" method="post" enctype="multipart/form-data">
							 <?php
include "connection/dbconnect.php";
//$varEmail=$_SESSION["varSesEmail"];
$varEmail=$_REQUEST['QEmail'];
$varShowQ="SELECT * FROM tbl_alumni WHERE fld_email='$varEmail'";

$res=mysqli_query($conObj,$varShowQ);
$data=mysqli_fetch_array($res);   
$varEmail=$_REQUEST['QEmail'];
$varShowR="SELECT * FROM stureg WHERE fld_email='$varEmail'";
$res5=mysqli_query($conObj,$varShowR);
$data5=mysqli_fetch_array($res5);
?>
							<fieldset>
								<legend><center>Alumni Profile</center></legend>
							</fieldset>

				
							
							

							<div class="form-group">
								<label class="col-md-3 control-label">Enrollment No</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon"></i>
										</span>
										<input name="enrollmentno" placeholder="Enrollment No" class="form-control" type="text" value="<?php echo $data['fld_enroll']; ?>" readonly>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Fax No</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon"></i>
										</span>
										<input name="faxno" placeholder="Fax No" class="form-control" type="text" value="<?php echo $data['fld_faxno']; ?>" readonly>
									</div>
								</div>
							</div>

							

				      		<div class="form-group">
								<label class="col-md-3 control-label">Year of Admission</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-calender"></i>
										</span>
										<input name="YearofAdmission" placeholder="Year of Admission" class="form-control" type="text" value="<?php echo $data['fld_yearofadmission']; ?>" readonly>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Present Address</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-home"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="Present" readonly><?php echo $data['fld_presentaddress']; ?></textarea value="" >
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Permanent Address</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-home"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="Permanent" value="" readonly><?php echo $data['fld_permanentaddress']; ?></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Blood Group</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="BloodGroup" placeholder="Blood Group" class="form-control" type="text" value="<?php echo $data['fld_bloodgroup']; ?>" readonly>
									</div>
								</div>
							</div>


							<div class="form-group">
								<label class="col-md-3 control-label">Graduation Year</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-calender"></i>
										</span>
										<input name="GraduationYear" placeholder="Graduation Year" class="form-control" type="text" value="<?php echo $data['fld_graduationyear']; ?>" readonly>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Percentage</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-pencil"></i>
										</span>
										<input name="Percentage" placeholder="Percentage" class="form-control" type="text" value="<?php echo $data['fld_percentage']; ?>" readonly>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Marks Obtained</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-pencil"></i>
										</span>
										<input name="marks" placeholder="marks" class="form-control" type="text" value="<?php echo $data['fld_marksobtained']; ?>" readonly>
									</div>
								</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">Class of Degree</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="ClassofDegree" class="form-control selectpicker" placeholder="Class of Degree" class="form-control" type="text" value="" readonly >
						              <option value=" " ><?php echo $data['fld_degreeeclass']; ?></option>
						              <option>Distinction</option>
						              <option>First class</option> 
						              <option>Second class</option>
						              <option>Third Class</option>  
						            </select>
						          </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">Designation</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="Designation" placeholder="Designation" class="form-control" type="text" value="<?php echo $data['fld_designation']; ?>" readonly>
									</div>
								</div>
							</div>
							<br><br>
							<div class="form-group">
								<label class="col-md-3 control-label">Office Address</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-home"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="officeaddress" readonly><?php echo $data['fld_officeaddress']; ?></textarea value="" >
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Guardian Name</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-user"></i>
										</span>
										<input name="GuardianName" placeholder="Guardian Name" class="form-control" type="text" value="<?php echo $data['fld_guardianname']; ?>" readonly>
									</div>
								</div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">Relation</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-user"></i>
										</span>
										<input name="Relation" placeholder="Relation" class="form-control" type="text" value="<?php echo $data['fld_relation']; ?>" readonly>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">Occupation</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="Occupation" placeholder="Occupation" class="form-control" type="text" value="<?php echo $data['fld_occupation']; ?>" readonly>
									</div>
								</div>
							</div>

							

						    <legend><center>Personal interests and other Achivements</center></legend>

						    <div class="form-group">
						        <label class="col-md-3 control-label">Have you passed any of the examinations?</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="University1" class="form-control selectpicker" placeholder="" class="form-control" type="text" readonly >
						              <option value=" " ><?php echo $data['fld_examinationpass']; ?></option>
						              <option>GATE</option>
						              <option>GRE</option>
						              <option>IELTS</option>
						              <option>TOEFL</option> 
						            </select>
						          </div>
						        </div>
					        </div>

					        <div class="form-group">
								<label class="col-md-3 control-label">if yes,write your score</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="writeyourscore" placeholder="write your score" class="form-control" type="text" value="<?php echo $data['fld_examscore']; ?>" readonly>
									</div>
								</div>
							</div>

							<div class="form-group">
									<label class="col-md-3 control-label">Write name of the college where admission sought
									</label>
									<div class="col-md-9 input Group container">
										<div class="input-group">
											<span class="input-group-addon">
												<i class="glyphicon glyphicon-"></i>
											</span>
											<textarea class="form-control" rows="2" id="comment" name="clgname" value readonly>"<?php echo $data['fld_collegename']; ?></textarea>
										</div>
									</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">University</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="University" class="form-control selectpicker" placeholder="University" class="form-control" type="text" readonly >
						              <option value=" " ><?php echo $data['fld_university']; ?> </option>
						              <option>National</option>
						              <option>Abroad</option> 
						            </select>
						          </div>
						        </div>
						    </div>

							<div class="form-group">
								<label class="col-md-3 control-label">Name of organization</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<input name="nameoforganization" placeholder="Name of organization" class="form-control" type="text" value="<?php echo $data['fld_organizationname']; ?>" readonly>
									</div>
								</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">Have you passed any advance course?</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="course" class="form-control selectpicker" placeholder="" class="form-control" type="text" readonly>
						              <option value=" " ><?php echo $data['fld_course']; ?></option>
						              <option>Yes</option>
						              <option>No</option>
						                
						            </select>
						          </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">
									Write details about course
								</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="cdetails" readonly><?php echo $data['fld_coursedetail']; ?></textarea value="" >
									</div>
							    </div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">Are you Employed?</label>
						        <div class="col-md-9 selectContainer">
						          <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
						            <select name="course1" class="form-control selectpicker" placeholder="" class="form-control" type="text" readonly >
						              <option value=" "><?php echo $data['fld_employed']; ?></option>
						              <option>Yes</option>
						              <option>No</option>
						                
						            </select>
						          </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">Write about firm/organization
								</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="firm" value="" readonly><?php echo $data['fld_firm']; ?></textarea>
									</div>
								</div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">
									Any other achievement
								</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="achievement" value="" readonly><?php echo $data['fld_achievement']; ?></textarea>
									</div>
								</div>
							</div>
							
						    <legend><center>Feed back form</center></legend>

						    <div class="form-group">
						        <label class="col-md-3 control-label"> 
						            What are your feeling about college during last four years?
						        </label>
						        <div class="col-md-9 selectContainer">
						           <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="feeling" class="form-control selectpicker" placeholder="" class="form-control" type="text" readonly>
							              <option value=" " ><?php echo $data['fld_feelingaboutcollege']; ?></option>
							              <option>Satisfied</option>
							              <option>Unsatisfied</option>
							              <option>Need to change</option>
							            </select>
						            </div>
						        </div>
						    </div>

						    <div class="form-group">
						        <label class="col-md-3 control-label">
						              Is your department helping you to improve your results?
						        </label>
						        <div class="col-md-9 selectContainer">
						            <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="helping" class="form-control selectpicker" placeholder="" class="form-control" type="text" readonly>
							              <option value=" " ><?php echo $data['fld_departmenthelp']; ?></option>
							              <option>Always</option>
							              <option>Sometimes</option>
							              <option>Never</option>
							            </select>
						            </div>
						        </div>
						    </div>

						    <div class="form-group">
						        <label class="col-md-3 control-label">
						           What is the opinion of other departmental students have regarding our department?
						       </label>
						        <div class="col-md-9 selectContainer">
						            <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="opinion" class="form-control selectpicker" placeholder="" class="form-control" type="text" readonly>
							              <option value=" " ><?php echo $data['fld_opinionofstudent']; ?></option>
							              <option>Good</option>
							              <option>Not so good</option>
							              <option>Bad</option>
							            </select>
						            </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">The policies of department you like?</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="policy" value="" readonly><?php echo $data['fld_departmentpolicylike']; ?></textarea>
									</div>
								</div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">The policies of department you dislike?</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="dept" value="" readonly><?php echo $data['fld_departmentpolicyunlike']; ?></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">
											The facilities you expect from college authorities are fulfilled?
								</label>
						        <div class="col-md-9 selectContainer">
						            <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="facilities2" class="form-control selectpicker" placeholder="" class="form-control" type="text" readonly>
							              <option value=" " ><?php echo $data['fld_facilityfuillfillformdept']; ?></option>
							              <option>Yes fully</option>
							              <option>Not all</option>
							              <option>Nothing</option>
							            </select>
						            </div>
						        </div>
						    </div>

						    <div class="form-group">
								<label class="col-md-3 control-label">The policies of college will attract students for admission?</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="p1" valu="" readonly><?php echo $data['fld_policyattractstudent']; ?></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">The policies of college you like?</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="p2" value="" readonly><?php echo $data['fld_collegepolicylike']; ?></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
								<label class="col-md-3 control-label">
								   The policies of college you dislike?
								</label>
								<div class="col-md-9 input Group container">
									<div class="input-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-"></i>
										</span>
										<textarea class="form-control" rows="2" id="comment" name="aishu" value="" readonly><?php echo $data['fld_collegepolicydislike']; ?></textarea>
									</div>
								</div>
							</div>

							<div class="form-group">
						        <label class="col-md-3 control-label">
											Would you like to support your college for first/second year admissions?
								</label>
						       <div class="col-md-9 selectContainer">
							        <div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-"></i></span>
							            <select name="p4" class="form-control selectpicker" placeholder="" class="form-control" type="text" readonly>
							              <option value=" " ><?php echo $data['fld_supportforadmission']; ?></option>
							              <option>Yes</option>
							              <option>No</option>
							            </select>
							        </div>
						       </div>
						    </div>

						   
							<div class="form-group">
								<div class=" inputGroupContainer">
									<center><a href="alumni_search.php"><button type="button" class="btn btn-primary btn-group-lg" name="sub"><< Back</button></a> &nbsp;&nbsp;&nbsp;<button type="submit" class="btn btn-primary btn-group-lg" name="sub" onclick="window.print()">Print</button></center>
								</div>
							</div>

					</form>
					
				</div>
			</div>
 
			</div>


		    

		</div>
	</div>

<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>

 <script type="text/javascript">
 
   $(document).ready(function() 
   {
    	$('#reg_form').bootstrapValidator({
    		feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },

        fields: {
        	enrollmentno: {
                    validators: {
                        notEmpty: {
                        message: 'Please supply Enrollment'
                    	},
                    	regexp: {
                        regexp: /^[0-9]+$/,
                        message: 'Enrollment can only consist of digits'
                        },
                        stringLength: {
                        min: 8,
                        max: 8,
                        message: 'The digit of Enrollment must be between %s and %s'
                    },

                    }
                },

        }

     });
   }


 </script>


</body>
</html>



