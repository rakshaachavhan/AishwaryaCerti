<nav class="navbar navbar-inverse">
					<div class="container">
						
					<button type="button" data-target="#navbar-collapse-1" data-toggle="collapse" class="navbar-toggle">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					
					<div class="collapse navbar-collapse" id="navbar-collapse-1">
						<ul class="nav navbar-nav" >
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" style="color:white;">
							Profile<b class="caret"></b></a>
							<ul class="dropdown-menu">
							<li>
							   <a href="alumni_personal.php">Personal Details</a></li>
							 <li>
							   <a href="alumnireg.php">Alumni Details</a></li>
							   </ul> 
						</li>
						<li>
							<a href="alumni_company.php" style="color:white;">Company</a>
						</li>
						
						
						<li>
							<a href="alumni_others.php" style="color:white;">Other</a>
						</li>
						<li>
							<a href="alumni_fund.php" style="color:white;">Fund</a>
						</li>
						<li>
							<a href="alumni_capmusrecru.php" style="color:white;">Campus Recruitment</a>
						</li>
						<li>
							<a href="alumni_campus.php" style="color:white;">Campus</a>
						</li>
						<li>
							<a href="alumni_approvefund.php" style="color:white;">Approved Fund</a>
						</li>
						</ul>

						<ul class="nav navbar-nav navbar-right">
						<li>
							<a href="logout.php"  style="color:white;">LogOut</a>
						</li>
						</ul>

					</div>
					</div>
				</nav>