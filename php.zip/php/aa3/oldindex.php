<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap37/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bootstrapvalidator_0.5.2_css_bootstrapValidator.min.css">
  <script src="../bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
  <style type="text/css">
  <style type="text/css">
  
  .header
  {
  	background-color: white;
  }
  
  .menus1
  {
  	background-color: #e65651;
  	text-align: center;
  }
  .navbar-inverse
  {
  	background-color: #e65651;
  	border: none;
  }

  h1
  {
  	color: #e65651;;
  	font-size: 40px;
  	text-align: center;
  	margin-left: 0px;
  }
  .img1
  {
  	height: 130px;
  }

  .nav
  {
  	
  	font-weight: bolder;
  	font-style: white;
  	
  }
 .events ul
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    padding-bottom: 40px;
    
}
.events li
{
    padding: 0px;
    margin-bottom: 5px;
    font-weight: bold;
   color: white;

}

.panel-body
{
	
	background-color: #e65651;
	
	border: 2px solid white;
	
}
.content
{
	text-align: justify;
	padding-left: 10px;
	padding-top: 10px;
	background-color: white;
	


}
.footer
{
	text-align: center;
	background-color: #e65651;
	color: white;
	font-weight: bolder;
	padding-top: 3px;
	
	height: 30px;
	font-size: 18px;
 
}


  </style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12 header">
				<div class="col-md-2">
					<img src="images/jpg/logo.jpg" class="img1 img-responsive">
				</div >
				<div class="col-md-10">
					<span><h1>Development of an Online Repository  & Search Engine for  Alumni </h1></span>
				</div>
				
			</div>
				<div class="col-md-12 menus1">
					<?php
					include "navigation.php";
					?>
			    </div>
				
<div>
				<!-- Start WOWSlider.com BODY section -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="data1/images/jawaharlaldardainstituteofengineeringandtechnologyjdietyavatmal.jpg" alt="slider jquery" title id="wows1_0"/></li>
		<li><img src="data1/images/slide4.jpg" alt="slide-4" title id="wows1_1"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="jawaharlal-darda-institute-of-engineering-and-technology-jdiet-yavatmal"><span><img src="data1/tooltips/jawaharlaldardainstituteofengineeringandtechnologyjdietyavatmal.jpg" alt="jawaharlal-darda-institute-of-engineering-and-technology-jdiet-yavatmal"/>1</span></a>
		<a href="#" title="slide-4"><span><img src="data1/tooltips/slide4.jpg" alt="slide-4"/>2</span></a>
	</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">jquery carousel</a> by WOWSlider.com v8.8</div>
<div class="ws_shadow"></div>
</div>	
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
<!-- End WOWSlider.com BODY section -->
			</div>
		
			<div class="col-md-4 panel-body">
				
					<marquee direction="up" onmouseover="this.stop()" onmouseout="this.start()">
						<ul class="events nav">
							<li>Event</li>
							<li>Event</li>
							<li>Event</li>
							<li>Event</li>
							<li>Event</li>
							<li>Event</li>
							<li>Event</li>
							<li>Event</li>
							<li>Event</li>
							<li>Event</li>
							<li>Event</li>
						</ul>
					</marquee>
				
			</div>
			<div class="col-md-8 content">
				<img src="images/jpg/slide-7.jpg" class="img-responsive">
			</div>
			<div class="col-md-12 footer" >
				<p>Copyright &copy; abc. All rights are reserved</p>
			</div>
		</div>
	</div>
	<script src="bootstrap37/js/jquery.min.js"></script>
  <script src="bootstrap37/js/bootstrap.min.js"></script>
 <script src='bootstrapvalidator_0.5.2_js_bootstrapValidator.min.js'></script>


</body>
</html>