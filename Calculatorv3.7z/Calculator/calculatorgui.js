
   function addClick()
   {
		var str=document.getElementById('output').value;
		var pos1=str.indexOf("-");
	   	var pos2=str.indexOf("*");
		var pos3=str.indexOf("/");
		var num = document.getElementById('inputNo').value;  //getting the value from the input textbox to output textbox

		if(document.getElementById('output').value===""&&document.getElementById('inputNo').value!="")
		{
			if(!isNaN(num)) //isNaN function in javascript determines that given input is not-a-number.
			{
			document.getElementById('output').value=num;  //setting the value for output textbox.
			var val = document.getElementById('output').value;
			var res = val.concat(document.getElementById('btnadd').value);
			//alert(res);
			document.getElementById('output').value=res;
			document.getElementById('inputNo').value="";  //to empty the input textbox
			}
			else
			{
				alert("string not allowed");   //to show alert message if user gives wrong input.
			}

		}
		else if(document.getElementById('output').value!="" && pos1!=-1 )
		{
			
				var res = str.replace("-","+");
				document.getElementById('output').value=res
		}
		else if(document.getElementById('output').value!="" && pos2!=-1 )
		{
			
				var res = str.replace("*","+");
				document.getElementById('output').value=res
		}
		else
		{
			var res = str.replace("/","+");
				document.getElementById('output').value=res
		}

	}
	
	function subClick()
	{
		var str=document.getElementById('output').value;
		var pos1=str.indexOf("+");
	   	var pos2=str.indexOf("*");
		var pos3=str.indexOf("/");
		var num = document.getElementById('inputNo').value;  //getting the value from the input textbox to output textbox

		if(document.getElementById('output').value===""&&document.getElementById('inputNo').value!="")
		{
			if(!isNaN(num)) //isNaN function in javascript determines that given input is not-a-number.
			{
			document.getElementById('output').value=num;  //setting the value for output textbox.
			var val = document.getElementById('output').value;
			var res = val.concat(document.getElementById('btnsub').value);
			//alert(res);
			document.getElementById('output').value=res;
			document.getElementById('inputNo').value="";  //to empty the input textbox
			}
			else
			{
				alert("string not allowed");   //to show alert message if user gives wrong input.
			}

		}
		else if(document.getElementById('output').value!="" && pos1!=-1 )
		{
			
				var res = str.replace("+","-");
				document.getElementById('output').value=res
		}
		else if(document.getElementById('output').value!="" && pos2!=-1 )
		{
			
				var res = str.replace("*","-");
				document.getElementById('output').value=res
		}
		else
		{
			var res = str.replace("/","-");
				document.getElementById('output').value=res
		}
	}
	
	function mulClick()
	{
		var str=document.getElementById('output').value;
		var pos1=str.indexOf("+");
	   	var pos2=str.indexOf("-");
		var pos3=str.indexOf("/");
		var num = document.getElementById('inputNo').value;  //getting the value from the input textbox to output textbox

		if(document.getElementById('output').value===""&&document.getElementById('inputNo').value!="")
		{
			if(!isNaN(num)) //isNaN function in javascript determines that given input is not-a-number.
			{
			document.getElementById('output').value=num;  //setting the value for output textbox.
			var val = document.getElementById('output').value;
			var res = val.concat(document.getElementById('btnmul').value);
			//alert(res);
			document.getElementById('output').value=res;
			document.getElementById('inputNo').value="";  //to empty the input textbox
			}
			else
			{
				alert("string not allowed");   //to show alert message if user gives wrong input.
			}

		}
		else if(document.getElementById('output').value!="" && pos1!=-1 )
		{
			
				var res = str.replace("+","*");
				document.getElementById('output').value=res
		}
		else if(document.getElementById('output').value!="" && pos2!=-1 )
		{
			
				var res = str.replace("-","*");
				document.getElementById('output').value=res
		}
		else
		{
			var res = str.replace("/","*");
				document.getElementById('output').value=res
		}
	}
	
	
	function divClick()
	{
		var str=document.getElementById('output').value;
		var pos1=str.indexOf("+");
	   	var pos2=str.indexOf("*");
		var pos3=str.indexOf("-");
		var num = document.getElementById('inputNo').value;  //getting the value from the input textbox to output textbox

		if(document.getElementById('output').value===""&&document.getElementById('inputNo').value!="")
		{
			if(!isNaN(num)) //isNaN function in javascript determines that given input is not-a-number.
			{
			document.getElementById('output').value=num;  //setting the value for output textbox.
			var val = document.getElementById('output').value;
			var res = val.concat(document.getElementById('btndiv').value);
			//alert(res);
			document.getElementById('output').value=res;
			document.getElementById('inputNo').value="";  //to empty the input textbox
			}
			else
			{
				alert("string not allowed");   //to show alert message if user gives wrong input.
			}

		}
		else if(document.getElementById('output').value!="" && pos1!=-1 )
		{
			
				var res = str.replace("+","/");
				document.getElementById('output').value=res
		}
		else if(document.getElementById('output').value!="" && pos2!=-1 )
		{
			
				var res = str.replace("*","/");
				document.getElementById('output').value=res
		}
		else
		{
			var res = str.replace("-","/");
				document.getElementById('output').value=res
		}
	}
	
	function equalClick()
	{
		var str=document.getElementById('output').value
		var pos=str.indexOf("+");
		var num = document.getElementById('inputNo').value;  //getting the value from the input textbox to output textbox
	}

