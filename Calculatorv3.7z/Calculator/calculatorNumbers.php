<?php
/*class Numbers is abstract class which will set and return the values of first no and second no
It is declared as abstract so that it cannot be instantiated */
abstract class Calculator
{
	private $_firstNo; 
	
	//function to set the value of _firstNo 
	public function setFirstNo($fno)
	{
		$this->_firstNo=$fno;
	}
	
	//function to get the value of _firstNo
	public function getFirstNo()
	{
		return $this->_firstNo;
	}
		
	private $_secondNo;
	//function to set the value of _firstNo 
	public function setSecondNo($sno)
	{
		$this->_secondNo=$sno;
	}
	
	//function to get the value of _firstNo
	public function getSecondNo()
	{
		return $this->_secondNo;
	}
}
	
class Operations extends Calculator
{
	public function add()
	{
			
		$result=$this->getSecondNo()+$this->getFirstNo();
		return $result;
			
	}
		
			
	public function sub()
	{
			
		$result=$this->getSecondNo()-$this->getFirstNo();
		return $result;
			
	}
		
	public function mul()
	{
		$result=$this->getSecondNo()*$this->getFirstNo();
		return $result;
			
	}
		
	public function divide()
	{
		if($this->getFirstNo()!=0)
		{
			$result=$this->getSecondNo()/$this->getFirstNo();
			return $result;
		}
		else
		{
			echo "<script>alert('We cannot divide a no by 0')</script>";
		}	
	}
}
?>