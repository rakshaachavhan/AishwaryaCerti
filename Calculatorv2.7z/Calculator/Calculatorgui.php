<!--javascript function to set proper values in gui-->
<script>
   function addClick()
   {
		var num = document.getElementById('inputNo').value;  //getting the value from the input textbox to output textbox
	
		if(document.getElementById('output').value=="")  //This will set the value in output textbox if it will be empty.
		{
			if(!isNaN(num)) //isNaN function in javascript determines that given input is not-a-number.
			{
			document.getElementById('output').value=num;  //setting the value for output textbox.
			document.getElementById('inputNo').value="";  //to empty the input textbox
			}
			else
			{
				alert("string not allowed");   //to show alert message if user gives wrong input.
			}
			
		}

	}
 </script>
 
<?php
error_reporting(E_ALL);      //This function will report all the errors in the program.
ini_set('display_errors','On');  //This function will display all the errors on the screen.
ini_set('error_log','./guierrors.log');//This function will log the errors in guierrors.log file.
include "calculatorNumbers.php";  //to add ref for number class and operation class.

//To Perform Addition
if(isset($_POST['btnAdd'])) 
{
	
	$firstNum=$_POST['txtinputNo']; //Getting value  from input textbox.
	$secondNum=$_POST['txtoutput']; //Getting value from output textbox.
	$objAdd=new Operations();       //creating object of class Addition.
	$objAdd->setFirstNo($firstNum); //Setting the First No
	$objAdd->setSecondNo($secondNum); //Setting the Second No.
	if(($firstNum!=""&&$secondNum!="")) //Checks that textboxes are not empty.
	{
		if(is_numeric($firstNum)) //checks only numeric values are entered.
		{			
			$result=$objAdd->add();
			$secondNum=$result;	
		}			
		else
			echo "<Script>alert('Only numeric values accepted')</script>"; 
		
	}
	
}
/**All mention comments are same for the below functionalities**/

//To perform Subtraction.
if(isset($_POST['btnSubtract']))
{
	$firstNum=$_POST['txtinputNo'];
	$secondNum=$_POST['txtoutput'];
	$objSub=new Operations();
	$objSub->setFirstNo($firstNum);
	$objSub->setSecondNo($secondNum);
	if(($firstNum!=""&&$secondNum!=""))
	{
		if(is_numeric($firstNum))
		{
			$result=$objSub->sub();
			$secondNum=$result;
		}
		else
			echo "<Script>alert('Only numeric values accepted')</script>";
		
	}

	
		
}


//To perform Multipication
if(isset($_POST['btnMul']))
{
	$firstNum=$_POST['txtinputNo'];
	$secondNum=$_POST['txtoutput'];
	$objMul=new Operations();
	$objMul->setFirstNo($firstNum);
	$objMul->setSecondNo($secondNum);
	if(($firstNum!=""&&$secondNum!=""))
	{
		if(is_numeric($firstNum))
		{
			$result=$objMul->mul();
			$secondNum=$result;
		}
		else
			echo "<Script>alert('Only numeric values accepted')</script>";
		
	}
			
}

//To perform Division
if(isset($_POST['btnDiv']))
{
	$firstNum=$_POST['txtinputNo'];
	$secondNum=$_POST['txtoutput'];
	$objDiv=new Operations();
	$objDiv->setFirstNo($firstNum);
	$objDiv->setSecondNo($secondNum);
	
	if(($firstNum!=""&&$secondNum!=""))
	{
		if(is_numeric($firstNum))
		{
			$result=$objDiv->divide();
			$secondNum=$result;
		}
		else
		{
			echo "<Script>alert('Only numeric values accepted')</script>";
		}
		
	}
	
	
		
}


//To clear the both textboxes.
if(isset($_POST['btnClear']))
{
	$firstNum="";
	
	$secondNum="";
}
?>

<!--gui for calculator-->
<html>
<head>
<title>Calculator</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script type=text/javascript"></script>
  
  <style>
	.panel-body
	{
		background-color:black;
		
	}
	legend
	{
		font-size:25px;
		font-weight:bolder;
		color:green
	}
	.button
	{
		width:100%;
		font-weight:bolder;
		font-size:20px;
	}
	
	#image
	{
		//position:fixed;
		width:100px;
		height:90px;
		margin-left:-20px;
	}
	#output
	{
		background-color:black;
		border:none;
		color:white;
		width:100%;
		
	}
	
	.form-control
	{
		text-align:right;
		
	}
	
	
  
  </style>
</head>

<body>
	<div class="conatiner">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<div class="panel panel-body">
					<form class="form-horizontal" method="POST">
						<center><legend>Calculator</legend></center>
						
						<div class="form-group">
							<div class="col-md-12">
								<input type="text" class="form-control" name="txtoutput"  id="output" value="<?php echo @$secondNum;?>" readonly>
							</div>
						</div>
						
						
						<div class="form-group">
							<div class="col-md-12">
								<input type="text" class="form-control" name="txtinputNo"  id="inputNo" value="<?php echo @$firstNum;?>" >
							</div>
						</div>

						

							<div class="col-md-2">
								<input type="submit" value="+" class="btn btn-success  button" name="btnAdd" id="btnfirst"  onclick="addClick()">
							</div>
							
							<div class="col-md-2">
								<input type="submit" value="-" class="btn btn-success  button" name="btnSubtract" id="btnsub" onclick="addClick()">
							</div>
							
							<div class="col-md-2">
								<input type="submit" value="*" class="btn btn-success  button" name="btnMul" id="btnsub"  onclick="addClick()">
							</div>
							
							<div class="col-md-2">
								<input type="submit" value="/" class="btn btn-success  button" name="btnDiv" id="btnsub"  onclick="addClick()">
							</div>

							<div class="col-md-4">
								<input type="submit" value="Clear" class="btn btn-success  button" name="btnClear"  id="btnlast">
							</div>
						
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>