﻿
create table aish164277.Incident(
IncidentId int primary key Identity(100,1) not null,
Disease varchar(50),
DateOfFirstIncident datetime,
TotalCasesTillDate int,
StateOfIncident varchar(50),
City varchar(50),
Hospital varchar(50)
)
drop  table aish164277.Incident;

select * from aish164277.Incident

select * from aish164277.Incident where disease='H1N1(Swine Flu)' and DateOfFirstIncident  between '2016-01-01' AND '2017-01-01';

delete  from aish164277.Incident where incidentid=106

Select max(incidentid) from aish164277.Incident
 

insert into aish164277.Incident values('H1N1(Swine Flu)',GETDATE(),10,'Telangana','Hyderabad','Apollo Hospital')
insert into aish164277.Incident values('H1N1(Swine Flu)',2018-01-04,10,'Maharashtra','Mumbai','Lilavati Hospital')
insert into aish164277.Incident values('H1N1(Swine Flu)',2017-01-04,10,'Maharashtra','Mumbai','Lilavati Hospital')
insert into aish164277.Incident values('H1N1(Swine Flu)',2016-01-04,10,'Maharashtra','Mumbai','Lilavati Hospital')
insert into aish164277.Incident values('H1N1(Swine Flu)',2015-01-04,10,'Maharashtra','Mumbai','Lilavati Hospital')