﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


namespace Question1
{
    public partial class SearchIncident : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select * from aish164277.Incident where disease=@disease and DateOfFirstIncident  between @from AND @to", con);
            cmd.Parameters.AddWithValue("@disease", ddlDisease.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@from", txtFromDate.Text);
            cmd.Parameters.AddWithValue("@to", txtToDate.Text);
            con.Open();
            dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (dr.HasRows)
                dt.Load(dr);
            con.Close();
            gvShow.DataSource = dt;
            gvShow.DataBind();
        }
    }
}