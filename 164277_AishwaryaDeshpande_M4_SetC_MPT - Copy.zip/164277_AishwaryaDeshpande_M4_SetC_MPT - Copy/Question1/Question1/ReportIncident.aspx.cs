﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Question1
{
    public partial class ReportIncident : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        SqlCommand cmd = null;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                cmd = new SqlCommand("INSERT INTO aish164277.Incident VALUES(@disease,@dateofincident,@totalcases,@state,@city,@hospital)", con);
                cmd.Parameters.AddWithValue("@disease", ddlDisease.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@dateofincident", txtDateOfFirstIncident.Text);
                cmd.Parameters.AddWithValue("@totalcases", Convert.ToInt32( txtTotalCases.Text));
                cmd.Parameters.AddWithValue("@state", ddlStates.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@city", ddlCity.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@hospital", txtHospName.Text);
                con.Open();
                int recordaffected = cmd.ExecuteNonQuery();
                con.Close();
                if (recordaffected > 0)
                {

                    lblSaved.Text = "Incident has been reported Successfully";
                    con.Open();
                   
                    SqlCommand cmd = new SqlCommand("Select max(incidentid) from aish164277.Incident", con);
                    cmd.ExecuteScalar();
                    lblGenID.Text = "Incident Id:" + Convert.ToUInt32( cmd.ExecuteScalar());
                    con.Close();
                }


            
                else
                {
                    lblSaved.Text = "Incident has been reported Successfully";
                }
            }
            catch(SystemException ex)
            {
                throw ex;
            }
           


        }
    }
}
