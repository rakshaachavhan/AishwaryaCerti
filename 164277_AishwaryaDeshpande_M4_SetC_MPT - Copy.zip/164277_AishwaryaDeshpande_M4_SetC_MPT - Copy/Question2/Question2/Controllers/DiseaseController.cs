﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Question2.Models;

namespace Question2.Controllers
{
    public class DiseaseController : Controller
    {
        Training_24Oct18_PuneEntities context = new Training_24Oct18_PuneEntities();

        // GET: Disease
        public ActionResult Index()
        {
            //var query = context.Incidents.Where(s => s.DateOfFirstIncident.Value.Year == 2016 || s.DateOfFirstIncident.Value.Year == 2017);
            var query = from s in context.Incidents
                        where s.DateOfFirstIncident.Value.Year == 2016 || s.DateOfFirstIncident.Value.Year == 2017
                        select s;
            ViewBag.IncidentList = query.ToList();
            return View();
        }
    }
}