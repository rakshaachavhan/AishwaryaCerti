<script>
   function addClick()
   {
	var num = document.getElementById('inputNo').value;
	document.getElementById('output').value=num;
	
	
	
  }
  </script>
<?php
include "calculatorNumbers.php";

if(isset($_POST['btnSubmit']))
{
	$firstNum=$_POST['txtinputNo'];
	
	$secondNum=$_POST['txtoutput'];
	
	
	
	$objAdd=new Addition();
	
	$objAdd->setFirstNo($firstNum);
	
	$result=$objAdd->add($secondNum);
	
	echo $result;
	
	

}
?>

<!--gui for addition of two numbers-->
<html>
<head>
<title>Addition</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script type=text/javascript"></script>
  
  <style>
  
  
  .panel-body
  {
	  background-color:skyblue;
  }
  legend
  {
  font-size:25px;
  font-weight:bolder;
  color:green
  }
  #button
  {
  width:100px;
  }
  #image
  {
  //position:fixed;
  width:100px;
  height:90px;
  margin-left:-20px;
  }
  #output
  {
	 background-color:skyblue;
	 border:none;
	 color:black;
  }
  
  </style>
</head>

<body>
<div class="conatiner">
<div class="row">
<div class="col-md-3"></div>
<div class="col-md-6">
<div class="panel panel-body">
<form class="form-horizontal" method="POST">
<center><legend>Calculator</legend></center>
<div class="form-group">
<div class="col-md-12">
<input type="text" class="form-control" name="txtoutput"  id="output" value="<?php echo @$secondNum;?>">
</div>
</div>
<div class="form-group">
<div class="col-md-12">
<input type="text" class="form-control" name="txtinputNo"  id="inputNo" value="<?php echo @$firstNum;?>" >
</div>
</div>
<div class="col-md-12">
<div class="col-md-5"></div>
<div class="col-md-4">
<input type="submit" value="Add" class="btn btn-success btn-md" name="btnSubmit" id="button" onclick="addClick()">
</div>
<div class="col-md-4"></div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>