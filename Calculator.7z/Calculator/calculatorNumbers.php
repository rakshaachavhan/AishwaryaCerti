<?php
$count=0;
class Calculator
	{
		private $_firstNo; 
	
		//function to set the value of _firstNo 
		public function setFirstNo($fno)
		{
			if($fno!="")
				$this->_firstNo=$fno;
			else
			{
			
				throw new Exception("Provide the First Number<br>");
			}

		}
	
		//function to get the value of _firstNo
		public function getFirstNo()
		{
			return $this->_firstNo;
		}
	}
	
	class Addition extends Calculator
	{
		public function add($res)
		{
			$result=$res+$this->getFirstNo();
			return $result;
			
		}
	}
?>