﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Product p = null;
        ProductDAL productDAL = new ProductDAL();
        public MainWindow()
        {
            InitializeComponent();
        }

        public bool IsInputValid()
        {

            if (comboname.Text == string.Empty)
                return false;
            if (txtPrice.Text == string.Empty)
                return false;
            if (datepicker.Text == string.Empty)
                return false;

            return true;
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsInputValid())
                {


                    Product p = new Product()
                    {

                        ProductName = comboname.Text,
                        Price = Convert.ToDecimal(txtPrice.Text),
                        ExpDate = Convert.ToDateTime(datepicker.Text)

                    };
                    productDAL.Insert(p);
                    MessageBox.Show("Inserted");
                    PopulateUI();
                }
                else
                {
                    MessageBox.Show("Enter Data");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

               // p = (Product)comboname.SelectedItem;

                p.ProductName = comboname.Text;
                p.ExpDate = Convert.ToDateTime(datepicker.Text);
                p.Price = Convert.ToDecimal(txtPrice.Text);
               
                productDAL.Update(p);
                MessageBox.Show("Updated");
                PopulateUI();


            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btndelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Product p = (Product)comboname.SelectedItem;
                productDAL.Delete(p);
                MessageBox.Show("Deleted");
                PopulateUI();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        public void PopulateUI()
        {
            IEnumerable<Product> prods = productDAL.SelectAll();
            dgProducts.ItemsSource = prods;
            comboname.ItemsSource = prods;
            comboname.DisplayMemberPath = "ProductName";
        }

        private void Comboname_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Product p = (Product)comboname.SelectedItem;

            //MessageBox.Show(p.Id.ToString());
        }

        private void Btn_Edit_Click(object sender, RoutedEventArgs e)
        {
             p = (Product)comboname.SelectedItem;
        }
    }
}
