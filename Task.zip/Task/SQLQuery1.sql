﻿create schema aish164277;

Create table [aish164277].[Product]([Id] int Identity(1,1) Primary key not null ,[ProductName] varchar(20) null, [ExpDate] date null,[Price] decimal null); 

insert into aish164277.Product values('Pendrive','09-09-2018',100.0);
insert into aish164277.Product values('CPU','09-09-2018',2000.0);

select * from aish164277.Product;

 update [aish164277].[Product] set Price=2000 where Id=1; 

  delete from [aish164277].[Product] where id=1;

 

update [aish164277].[Product] set Price=@price,ExpDate=@expdate where ProductName=@pname;

create proc aish164277.USP_UpdateProduct1
@pname varchar(20),
@price decimal,
@expdate date,
@id int
as
update aish164277.Product set  ProductName=@pname,ExpDate=@expdate,Price=@price where Id=@id;

create proc aish164277.USP_delProd1
@id int
as
delete from aish164277.Product where Id=@id


create Proc aish164277.USP_InsertProducts1
@pname varchar(20),
@price decimal,
@expdate date
as
	insert into aish164277.Product values(@pname,@expdate,@price);
