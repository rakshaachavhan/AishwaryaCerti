<?php


class Addition extends Numbers
    {
      public $result;
      public function add()
            {
            	try
            	{
            		global $result;
              		$result=$this->getFirstNo()+$this->getSecondNo();
              		//return $result;
              		echo "Sum is : $result";
              		
            	}
            	catch(Exception $e)
            	{
            		echo $e;
            	}
            	
            }
    }

?>