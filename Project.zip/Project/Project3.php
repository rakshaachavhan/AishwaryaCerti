<?php
/**
 * 
 */

?>
<html>
<head>
	<title>Addition</title>
</head>

<body>
	<div style="width: 20%"></div>
	<div style="width: 60%">
		<form id="frmadd"  method="POST">
			<table>
				<tr>
					<td>
						<label>Enter First Number</label>
					</td>
					<td>
						<input type="text" name="txtFirstNumber" required="">
					</td>
				</tr>

				<tr>
					<td>
						<label>Enter Second Number</label>
					</td>
					<td>
						<input type="text" name="txtSecondNumber" required="">
					</td>
				</tr>

				
				

				

				

				<tr>
					<td colspan="2">
						<input type="submit" name="btnSubmit" value="Add">
					</td>
				</tr>


			</table>
			
		</form>
	</div>
	<div style="width: 20%"></div>
</body>
</html>




<?php
include 'Numbers.php';
include 'Addition.php';
try
{

 $x=0;

$y=0;
if (isset($_POST['btnSubmit']))
 {
	global $x,$y;
	$x=$_POST['txtFirstNumber'];
	$y=$_POST['txtSecondNumber'];





$objAdd=new Addition();
$objAdd->setFirstNo($x);
$objAdd->setSecondNo($y);
$objAdd->add();

}
}
catch(Exception $e)
{
	echo $e;
}
?>