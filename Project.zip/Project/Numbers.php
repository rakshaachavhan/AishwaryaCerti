<?php
class Numbers
{
  
  private $_firstNo;
  public function setFirstNo($fno)
    {
      if($fno!="")
      {
        $this->_firstNo=$fno;
      }
      else
      {
        throw new Exception("Please Provide First Number");
        
      }

    }
  public function getFirstNo()
    {
      return $this->_firstNo;
    }
  
  
  private $_secondNo;
  public function setSecondNo($sno)
    {
      if($sno!="")
      {
        $this->_secondNo=$sno;
      }
      else
      {
        throw new Exception("Enter Second Number");
        
        
      }
    }
  public function getSecondNo()
    {
      return $this->_secondNo;
    }
}
?>
