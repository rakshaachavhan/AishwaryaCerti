﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfDataBinding
{
    class Person
    {
        public int Id  { get; set; }

        public string FullName { get; set; }

        public DateTime DOB { get; set; }

        public string MobileNo { get; set; }

        public string state { get; set; }

        public static IEnumerable<Person> GetPeople() // GetPeople is DAL method
        {
            return new List<Person>
            {
                new Person{ Id=1, FullName="Aishwarya",DOB=DateTime.Now.AddYears(-21), MobileNo="8788269727",state="Mah" },
                new Person { Id = 2, FullName = "Aishwarya", DOB = DateTime.Now.AddYears(-21), MobileNo = "8788269727", state = "Mah" },
                new Person { Id = 3, FullName = "Aishwarya", DOB = DateTime.Now.AddYears(-21), MobileNo = "8788269727", state = "Mah" },
                new Person { Id = 4, FullName = "Aishwarya", DOB = DateTime.Now.AddYears(-21), MobileNo = "8788269727", state = "Mah" },
                new Person { Id = 5, FullName = "Aishwarya", DOB = DateTime.Now.AddYears(-21), MobileNo = "8788269727", state = "Mah" }
            };
        }
    }
}
