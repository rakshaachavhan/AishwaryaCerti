﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CodeFirstEntityDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        EmployeeDbContext dbContext = null;
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new EmployeeDbContext();
            
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employee279 emp = new Employee279();
                emp.Id = 1;
                emp.EmpName = "Raksha";
                //emp.DeptId = 20;
                emp.city = "Pune";

                dbContext.Employees.Add(emp);
                dbContext.SaveChanges();
                MessageBox.Show("inserted");
                PopulateUI();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        public void PopulateUI()
        {
            List<Employee279> empList = dbContext.Employees.ToList();
            dgEmployees.ItemsSource = empList;
        }
    }
}
