﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)

        {

            int num1, num2, sum;
            Console.WriteLine("Enter Num1:");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Num1:");
            num2 = Convert.ToInt32(Console.ReadLine());
            sum = num1 + num2;
            Console.WriteLine("{0} + {1} =>{2}",num1, num2, sum);

            for(int i=0;i<25;i++)
            {
                Console.WriteLine("index=>", i);
            }

            Console.WriteLine("Function Call Starting");
            Show();
            Console.WriteLine("Function Call Ended");
            Console.ReadKey();

             void Show()
            {
                List<string> cities = new List<string>();
                cities.Add("pune");
                cities.Add("mumbai");
                cities.Add("banglore");
                cities.Add("chennai");
               foreach( string var in cities)
                {
                    Console.WriteLine(var);
                }

            }
        }

        


    }


    
}
