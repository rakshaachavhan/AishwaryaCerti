﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace CodeFirst
{
    class EmployeeContext : DbContext
    {
        public EmployeeContext():base("name=cn1")
        {

        }

        public virtual  DbSet<Employee280> Employees { get; set; }
    }
}
